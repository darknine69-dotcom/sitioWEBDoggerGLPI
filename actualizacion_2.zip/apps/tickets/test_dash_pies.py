"""Gráficas del panel y papelera de reciclaje.

Reproduce el caso del técnico: solo tiene tickets resueltos/cerrados, así que
las series que cuentan únicamente abiertas salían en blanco aunque tuviera
datos.
"""
import json
import re
from datetime import timedelta

from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from apps.accounts.models import Usuario
from apps.tickets.models import Categoria, Ticket
from apps.tickets.views import _build_tecnico_dashboard


@override_settings(STORAGES={
    "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
    "staticfiles": {"BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage"},
})
class SmokeTestCase(TestCase):
    """Base de las pruebas del panel.

    El proyecto sirve los estáticos con el manifest de WhiteNoise, que exige
    `collectstatic`; sin este override, renderizar base.html revienta con
    "Missing staticfiles manifest entry".
    """


class DashPiesTest(SmokeTestCase):
    def setUp(self):
        self.tecnico = Usuario.objects.create_user(
            email="tec@x.com", password="x", nombre="Tec", rol=Usuario.Rol.TECNICO
        )
        self.client.force_login(self.tecnico)
        self.cat_a = Categoria.objects.create(grupo="SIESA", nombre="Facturación")
        self.cat_b = Categoria.objects.create(grupo="POS", nombre="Impresora")

    def _ticket(self, estado, prioridad, categoria, titulo="T"):
        t = Ticket.objects.create(
            titulo=titulo,
            descripcion="d",
            prioridad=prioridad,
            estado=estado,
            solicitante_nombre="User",
            categoria=categoria,
        )
        t.tecnico_asignado = self.tecnico
        t.save()
        return t

    def _dash(self):
        return json.loads(_build_tecnico_dashboard(self.tecnico.id))

    @staticmethod
    def _mapa(items):
        return {i["label"]: i["value"] for i in items}

    def test_solo_resueltos_no_deja_las_graficas_vacias(self):
        self._ticket(Ticket.Estado.RESUELTO, Ticket.Prioridad.BAJA, self.cat_b, "R1")
        self._ticket(Ticket.Estado.CERRADO, Ticket.Prioridad.ALTA, self.cat_a, "C1")
        d = self._dash()
        # por defecto (abiertas) no hay nada que mostrar
        self.assertEqual(d["pie_categoria"]["abiertas"], [])
        self.assertEqual(d["pie_prioridad"]["abiertas"], [])
        # pero "todas" ve los dos tickets
        cat = self._mapa(d["pie_categoria"]["todas"])
        self.assertEqual(sum(cat.values()), 2)
        self.assertIn("SIESA › Facturación", cat)
        self.assertIn("POS › Impresora", cat)
        pri = self._mapa(d["pie_prioridad"]["todas"])
        self.assertEqual(pri, {"Baja": 1, "Alta": 1})

    def test_pivote_cuenta_resuelta_por_marca_y_cerrada_por_estado(self):
        """Una resolución actual queda cerrada, pero conserva ambas métricas."""
        resuelta = self._ticket(
            Ticket.Estado.CERRADO, Ticket.Prioridad.ALTA, self.cat_a, "Resuelta"
        )
        from django.db.models import QuerySet
        QuerySet.update(Ticket.objects.filter(pk=resuelta.pk), fecha_resolucion=timezone.now())
        self._ticket(
            Ticket.Estado.CERRADO, Ticket.Prioridad.MEDIA, self.cat_a, "Cerrada"
        )

        filas = self._dash()["pivot"]["dimensiones"]["categoria"]["rows"]
        fila = next(f for f in filas if f["label"] == "SIESA › Facturación")
        self.assertEqual(fila["cerrado"], 2)
        self.assertEqual(fila["resueltos"], 1)
        self.assertTrue(next(t for t in fila["tickets"] if t["id"] == resuelta.pk)["resuelto"])

    def test_cada_ambito_solo_muestra_su_estado(self):
        self._ticket(Ticket.Estado.ABIERTO, Ticket.Prioridad.URGENTE, self.cat_a, "A1")
        self._ticket(Ticket.Estado.EN_PROGRESO, Ticket.Prioridad.ALTA, self.cat_a, "P1")
        self._ticket(Ticket.Estado.RESUELTO, Ticket.Prioridad.BAJA, self.cat_b, "R1")
        self._ticket(Ticket.Estado.CERRADO, Ticket.Prioridad.MEDIA, self.cat_b, "C1")
        d = self._dash()
        # abiertas = abierto + en progreso (2 tickets, misma categoría)
        abiertas = self._mapa(d["pie_categoria"]["abiertas"])
        self.assertEqual(abiertas, {"SIESA › Facturación": 2})
        for ambito, cat in (("en_progreso", "SIESA › Facturación"),
                            ("cerrados", "POS › Impresora")):
            self.assertEqual(self._mapa(d["pie_categoria"][ambito]), {cat: 1}, ambito)
        # "Resueltas" ya no agrupa estados: busca la marca de resolución. R1
        # está en estado "resuelto" (los antiguos), C1 se cerró sin marcar,
        # así que solo entra R1.
        self.assertEqual(
            self._mapa(d["pie_categoria"]["resueltos"]), {"POS › Impresora": 1}
        )
        self.assertEqual(d["pie_categoria"]["eliminados"], [])
        self.assertEqual(len(self._mapa(d["pie_categoria"]["todas"])), 2)  # 2 categorías
        # por prioridad cada estado cae en su nivel
        self.assertEqual(self._mapa(d["pie_prioridad"]["abiertas"]), {"Urgente": 1, "Alta": 1})
        self.assertEqual(self._mapa(d["pie_prioridad"]["cerrados"]), {"Media": 1})
        self.assertEqual(
            self._mapa(d["pie_prioridad"]["resueltos"]), {"Baja": 1}
        )

    def test_el_ambito_eliminados_solo_muestra_la_papelera(self):
        viva = self._ticket(Ticket.Estado.ABIERTO, Ticket.Prioridad.ALTA, self.cat_a, "Viva")
        muerta = self._ticket(Ticket.Estado.ABIERTO, Ticket.Prioridad.BAJA, self.cat_b, "Muerta")
        muerta.mandar_a_la_papelera(self.tecnico)
        d = self._dash()
        # el ticket de la papelera sale en "eliminadas" y en "todas", pero no
        # en los estados: ya no está en operación.
        self.assertEqual(self._mapa(d["pie_categoria"]["eliminados"]), {"POS › Impresora": 1})
        self.assertEqual(self._mapa(d["pie_categoria"]["abiertas"]), {"SIESA › Facturación": 1})
        self.assertEqual(len(self._mapa(d["pie_categoria"]["todas"])), 2)
        # el pivote y los KPIs nunca cuentan lo eliminado: la categoría del
        # ticket borrado ni siquiera aparece.
        filas = {f["label"]: f for f in d["pivot"]["dimensiones"]["categoria"]["rows"]}
        self.assertEqual(list(filas), ["SIESA › Facturación"])
        self.assertEqual(filas["SIESA › Facturación"]["total"], 1)
        self.assertEqual(d["papelera_total"], 1)
        self.assertFalse(viva.en_la_papelera)
        self.assertTrue(Ticket.objects.filter(pk=muerta.pk).exists() is False)
        self.assertTrue(Ticket.con_eliminados.filter(pk=muerta.pk).exists())

    def test_el_panel_ofrece_los_tres_desplegables(self):
        self._ticket(Ticket.Estado.RESUELTO, Ticket.Prioridad.BAJA, self.cat_b, "R1")
        url = reverse("tickets:panel_tecnico")
        resp = self.client.get(url, {"vista": "panel"})
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, 'id="wCatScope"')
        self.assertContains(resp, 'id="wPrioScope"')
        for titulo in ("Solicitudes por categoría",
                       "Solicitudes por prioridad", "Solicitudes por período",
                       "Solicitudes recibidas", "Solicitudes vencidas (ANS)"):
            self.assertContains(resp, titulo)
        self.assertContains(resp, 'id="pivotDimLabel"')
        self.assertContains(resp, 'id="wComp20"')
        # los tres desplegables ofrecen los seis ámbitos
        for valor in ("abiertas", "en_progreso", "resueltos", "cerrados", "eliminados", "todas"):
            self.assertContains(resp, f'value="{valor}"')
        for valor in ("recibidas", "completadas"):
            self.assertContains(resp, f'value="{valor}"')
        # y el JSON trae una serie por ámbito
        datos = json.loads(resp.context["dash_json"])
        for clave in ("abiertas", "en_progreso", "resueltos", "cerrados", "eliminados", "todas"):
            self.assertIn(clave, datos["pie_categoria"])
            self.assertIn(clave, datos["comparativo"])
        self.assertEqual(len(datos["comparativo"]["resueltos"]["ok"]), 20)


class DashSancionesAnsTest(SmokeTestCase):
    """`sla` debe traer las claves que panel-dash.js lee: vencidos / riesgo."""

    def setUp(self):
        self.tecnico = Usuario.objects.create_user(
            email="tec@x.com", password="x", nombre="Tec", rol=Usuario.Rol.TECNICO
        )

    def _ticket(self, estado, titulo, ans_horas=8, duracion_horas=None):
        """ans_horas vive en la Categoria (en Ticket es propiedad)."""
        cat = Categoria.objects.create(
            grupo="SIESA", nombre=f"Cat {titulo}", ans_horas=ans_horas
        )
        t = Ticket.objects.create(
            titulo=titulo,
            descripcion="d",
            prioridad=Ticket.Prioridad.MEDIA,
            estado=estado,
            solicitante_nombre="User",
            categoria=cat,
        )
        t.tecnico_asignado = self.tecnico
        t.save()
        ahora = timezone.now()
        from django.db.models import QuerySet
        inicio = ahora - timedelta(days=3)
        historico = {"fecha_creacion": inicio, "ans_inicio_original": inicio,
                     "ans_limite_original": inicio + timedelta(hours=ans_horas)}
        if duracion_horas is None:
            # abierto y con el limite ANS ya vencido
            QuerySet.update(Ticket.objects.filter(pk=t.pk), **historico)
        else:
            # historia: creado hace 3 dias, cerrado despues de `duracion_horas`
            historico["fecha_cierre"] = inicio + timedelta(hours=duracion_horas)
            QuerySet.update(Ticket.objects.filter(pk=t.pk), **historico)
        t.refresh_from_db()
        return t

    def _sla(self):
        datos = json.loads(_build_tecnico_dashboard(self.tecnico.id))
        return datos["sla"]["por_tecnico"]

    def test_las_claves_son_las_que_el_js_espera(self):
        self._ticket(Ticket.Estado.ABIERTO, "Vencido")
        filas = self._sla()
        self.assertEqual(len(filas), 1)
        # el JS lee r.vencidos y r.riesgo: si faltan, la grafica sale en blanco
        self.assertIn("vencidos", filas[0])
        self.assertIn("riesgo", filas[0])
        self.assertEqual(filas[0]["vencidos"], 1)
        self.assertEqual(filas[0]["riesgo"], 0)
        self.assertNotIn("por-vencer", filas[0])

    def test_resuelto_fuera_de_ans_es_sancion(self):
        # se cerro 48h despues con ANS de 8h: infraccion consumada
        self._ticket(Ticket.Estado.RESUELTO, "Tarde", ans_horas=8, duracion_horas=48)
        filas = self._sla()
        self.assertEqual(len(filas), 1)
        self.assertEqual(filas[0]["vencidos"], 1)

    def test_resuelto_dentro_de_ans_no_cuenta(self):
        self._ticket(Ticket.Estado.RESUELTO, "A tiempo", ans_horas=24, duracion_horas=2)
        self.assertEqual(self._sla(), [])


class PapeleraTest(SmokeTestCase):
    """El borrado es lógico: se puede restaurar y no se pierde nada."""

    def setUp(self):
        self.admin = Usuario.objects.create_user(
            email="ad@x.com", password="x", nombre="Ad", rol=Usuario.Rol.ADMIN
        )
        self.tecnico = Usuario.objects.create_user(
            email="tec@x.com", password="x", nombre="Tec", rol=Usuario.Rol.TECNICO
        )
        self.cat = Categoria.objects.create(grupo="SIESA", nombre="Impresora")
        self.ticket = Ticket.objects.create(
            titulo="Se va a la papelera",
            descripcion="d",
            prioridad=Ticket.Prioridad.MEDIA,
            estado=Ticket.Estado.ABIERTO,
            solicitante_nombre="User",
            solicitante_email="u@x.com",
            categoria=self.cat,
        )
        self.ticket.tecnico_asignado = self.tecnico
        self.ticket.save()

    def test_eliminar_manda_a_la_papelera_y_no_borra(self):
        self.client.force_login(self.admin)
        resp = self.client.post(reverse("tickets:eliminar", args=[self.ticket.pk]))
        self.assertEqual(resp.status_code, 302)
        # el ticket sigue existiendo, pero invisible para la operación
        self.assertTrue(Ticket.con_eliminados.filter(pk=self.ticket.pk).exists())
        self.assertFalse(Ticket.objects.filter(pk=self.ticket.pk).exists())
        t = Ticket.con_eliminados.get(pk=self.ticket.pk)
        self.assertIsNotNone(t.eliminado_en)
        self.assertEqual(t.eliminado_por, self.admin)

    def test_restaurar_lo_devuelve_a_la_operacion(self):
        self.ticket.mandar_a_la_papelera(self.admin)
        self.client.force_login(self.admin)
        self.client.post(reverse("tickets:restaurar", args=[self.ticket.pk]))
        self.assertTrue(Ticket.objects.filter(pk=self.ticket.pk).exists())
        t = Ticket.objects.get(pk=self.ticket.pk)
        self.assertIsNone(t.eliminado_en)

    def test_motivo_papelera_se_conserva_en_historial_al_restaurar(self):
        self.client.force_login(self.admin)
        self.client.post(reverse("tickets:eliminar", args=[self.ticket.pk]), {"motivo_eliminacion": "Solicitud duplicada"})
        self.client.post(reverse("tickets:restaurar", args=[self.ticket.pk]))
        comentario = self.ticket.comentarios.get()
        self.assertEqual(comentario.comentario, "Motivo de envío a la papelera: Solicitud duplicada")
        self.assertTrue(comentario.es_interno)
        self.assertEqual(comentario.usuario, self.admin)

    def test_purgar_es_el_unico_borrado_definitivo(self):
        self.ticket.mandar_a_la_papelera(self.admin)
        self.client.force_login(self.admin)
        self.client.post(reverse("tickets:purgar", args=[self.ticket.pk]))
        self.assertFalse(Ticket.con_eliminados.filter(pk=self.ticket.pk).exists())

    def test_la_papelera_la_ve_el_staff_y_no_el_punto_de_venta(self):
        """La comparten administrador y técnico: los dos gestionan tickets.

        El punto de venta no entra aquí — lo suyo es `mi_papelera`, que solo
        le muestra lo que él mismo canceló.
        """
        self.ticket.mandar_a_la_papelera(self.admin)
        url = reverse("tickets:papelera")

        self.client.force_login(self.tecnico)
        resp = self.client.get(url)
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, self.ticket.codigo)
        self.assertEqual(resp.context["total"], 1)

        self.client.force_login(self.admin)
        resp = self.client.get(url)
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, self.ticket.codigo)
        self.assertEqual(resp.context["total"], 1)

        punto = Usuario.objects.create_user(
            email="pv@x.com", password="x", nombre="Punto", rol=Usuario.Rol.USUARIO
        )
        self.client.force_login(punto)
        self.client.raise_request_exception = False
        self.assertEqual(self.client.get(url).status_code, 403)

    def test_el_ticket_eliminado_desaparece_de_la_lista_y_del_detalle(self):
        self.client.force_login(self.admin)
        self.ticket.mandar_a_la_papelera(self.admin)
        lista = self.client.get(reverse("tickets:lista"))
        self.assertNotContains(lista, self.ticket.codigo)
        self.assertEqual(
            self.client.get(reverse("tickets:detalle", args=[self.ticket.pk])).status_code, 404
        )

class CodigoTicketTest(SmokeTestCase):
    """El código es único en toda la base, papelera incluida."""

    def setUp(self):
        self.admin = Usuario.objects.create_user(
            email="adm@x.com", password="x", nombre="Adm", rol=Usuario.Rol.ADMIN
        )

    def _crear(self, titulo="T"):
        return Ticket.objects.create(
            titulo=titulo, descripcion="d",
            solicitante_nombre="User", solicitante_email="u@x.com",
        )

    def test_el_codigo_nunca_reutiliza_el_de_un_ticket_eliminado(self):
        primero = self._crear("Primero")
        segundo = self._crear("Segundo")
        primero.mandar_a_la_papelera(self.admin)

        # El vivo sigue marcando el máximo, así que el nuevo no puede chocar.
        tercero = self._crear("Tercero")

        codigos = set(Ticket.con_eliminados.values_list("codigo", flat=True))
        self.assertEqual(len(codigos), 3)
        self.assertNotEqual(tercero.codigo, primero.codigo)
        self.assertEqual(tercero.codigo, "DG-XX-0003")

    def test_se_puede_crear_despues_de_borrar_todo_el_historico(self):
        for i in range(3):
            self._crear(f"T{i}").mandar_a_la_papelera(self.admin)
        self.assertEqual(Ticket.objects.count(), 0)

        nuevo = self._crear("Nuevo")

        self.assertIsNotNone(nuevo.pk)
        self.assertEqual(nuevo.codigo, "DG-XX-0004")

    def test_codigo_con_iniciales_de_punto_y_acentos(self):
        ticket = Ticket.objects.create(
            titulo="T", descripcion="d", solicitante_nombre="User",
            solicitante_punto="Éxito Colombia",
        )
        self.assertEqual(ticket.codigo, "DG-EX-0001")

    def test_consecutivo_respeta_codigos_anteriores(self):
        Ticket.objects.create(codigo="HD-0051", titulo="Anterior", descripcion="d", solicitante_nombre="User")
        ticket = Ticket.objects.create(titulo="Nuevo", descripcion="d", solicitante_nombre="User", solicitante_punto="Norte")
        self.assertEqual(ticket.codigo, "DG-NO-0052")

    def test_consulta_publica_acepta_codigos_nuevos_y_anteriores(self):
        anterior = Ticket.objects.create(codigo="HD-0051", titulo="Anterior", descripcion="d", solicitante_nombre="User")
        nuevo = Ticket.objects.create(titulo="Nuevo", descripcion="d", solicitante_nombre="User", solicitante_punto="Norte")
        for ticket in (anterior, nuevo):
            with self.subTest(codigo=ticket.codigo):
                respuesta = self.client.get(reverse("tickets:consultar"), {"codigo": ticket.codigo.lower()})
                self.assertEqual(respuesta.context["ticket"].pk, ticket.pk)


class FiltroResueltasTest(SmokeTestCase):
    """Marcar resuelto cierra el ticket, y los filtros lo reflejan.

    Al resolver, el ticket queda cerrado y se registra la fecha de
    resolución. `estado` por sí solo no alcanza: un ticket se puede cerrar
    directo desde abierto o en progreso, y ese no cuenta como resuelto. Por
    eso el filtro de "Resueltas" busca la marca y no el estado.
    """

    def setUp(self):
        self.admin = Usuario.objects.create_user(
            email="adm@x.com", password="x", nombre="Adm", rol=Usuario.Rol.ADMIN
        )
        self.client.force_login(self.admin)
        self.cat = Categoria.objects.create(grupo="SIESA", nombre="General")

    def _ticket(self, estado, titulo="T", resuelta=False):
        t = Ticket.objects.create(
            titulo=titulo,
            descripcion="d",
            prioridad=Ticket.Prioridad.MEDIA,
            estado=estado,
            solicitante_nombre="User",
            categoria=self.cat,
        )
        if resuelta:
            from django.db.models import QuerySet
            QuerySet.update(Ticket.objects.filter(pk=t.pk), fecha_resolucion=timezone.now())
            t.refresh_from_db()
        return t

    def _listado(self, estado):
        r = self.client.get(reverse("tickets:lista"), {"estado": estado, "per_page": 0})
        self.assertEqual(r.status_code, 200)
        return r.content.decode()

    def test_lista_muestra_primero_el_ticket_mas_reciente(self):
        nuevo = self._ticket(
            Ticket.Estado.ABIERTO, Ticket.Prioridad.BAJA, "Nuevo"
        )
        antiguo_urgente = self._ticket(
            Ticket.Estado.ABIERTO, Ticket.Prioridad.URGENTE, "Antiguo urgente"
        )
        Ticket.objects.filter(pk=antiguo_urgente.pk).update(
            fecha_creacion=timezone.now() - timedelta(days=2)
        )

        respuesta = self.client.get(
            reverse("tickets:lista"), {"per_page": 0}
        )

        self.assertEqual(respuesta.status_code, 200)
        self.assertEqual(respuesta.context["tickets"][0].pk, nuevo.pk)

    def test_marcar_resuelto_cierra_el_ticket(self):
        t = self._ticket(Ticket.Estado.EN_PROGRESO, "ZK-Progreso")
        r = self.client.post(
            reverse("tickets:cambiar_estado", args=[t.pk]),
            {"estado": Ticket.Estado.RESUELTO, "next": "/panel/tickets/"},
        )
        self.assertEqual(r.status_code, 302)
        t.refresh_from_db()
        self.assertEqual(t.estado, Ticket.Estado.CERRADO)
        self.assertIsNotNone(t.fecha_resolucion, "debe quedar registrada la resolución")
        self.assertIsNotNone(t.fecha_cierre)
        self.assertTrue(t.fue_resuelto)
        self.assertTrue(t.esta_cerrado)

    def test_no_reabrir_conserva_la_marca_de_resolucion(self):
        t = self._ticket(Ticket.Estado.CERRADO, "ZK-Cerrada", resuelta=True)
        self.client.post(
            reverse("tickets:cambiar_estado", args=[t.pk]),
            {"estado": Ticket.Estado.ABIERTO, "next": "/panel/tickets/"},
        )
        t.refresh_from_db()
        self.assertIsNotNone(t.fecha_resolucion)
        self.assertTrue(t.fue_resuelto)
        self.assertEqual(t.estado, Ticket.Estado.CERRADO)

    def test_filtrar_por_resuelto_trae_solo_los_resueltos(self):
        # Este se resolvió: al resolverlo se cerró, así que cuenta.
        self._ticket(Ticket.Estado.CERRADO, "ZK-Resuelta", resuelta=True)
        # Este se cerró directo, sin pasar por "marcar resuelto".
        self._ticket(Ticket.Estado.CERRADO, "ZK-Solo-cerrada")
        self._ticket(Ticket.Estado.ABIERTO, "ZK-Abierta")

        html = self._listado(Ticket.Estado.RESUELTO)
        self.assertIn("ZK-Resuelta", html)
        self.assertNotIn("ZK-Solo-cerrada", html)
        self.assertNotIn("ZK-Abierta", html)

    def test_cerrado_trae_las_cerradas_sean_resueltas_o_no(self):
        self._ticket(Ticket.Estado.CERRADO, "ZK-Resuelta", resuelta=True)
        self._ticket(Ticket.Estado.CERRADO, "ZK-Solo-cerrada")

        html = self._listado(Ticket.Estado.CERRADO)
        self.assertIn("ZK-Resuelta", html)
        self.assertIn("ZK-Solo-cerrada", html)

    def test_el_chip_de_resueltas_cuadra_con_el_listado(self):
        self._ticket(Ticket.Estado.CERRADO, "ZK-Resuelta", resuelta=True)
        self._ticket(Ticket.Estado.CERRADO, "ZK-Solo-cerrada")
        self._ticket(Ticket.Estado.ABIERTO, "ZK-Abierta")

        html = self._listado(Ticket.Estado.RESUELTO)
        esperado = Ticket.objects.filter(fecha_resolucion__isnull=False).count()
        chip = re.search(r'dash-stat-value st-resueltos">(\d+)</span>', html)
        self.assertIsNotNone(chip, "no se encontro la tarjeta de resueltas")
        self.assertEqual(int(chip.group(1)), esperado)
        self.assertEqual(esperado, 1)

    def test_indicadores_con_diseno_del_panel(self):
        import re

        self._ticket(Ticket.Estado.ABIERTO, "ZK-Abierta")
        html = self.client.get(reverse("tickets:lista")).content.decode()
        clases = set(re.findall(r"dash-hov-[a-z-]+", html))
        for esperada in (
            "dash-hov-total", "dash-hov-abiertos", "dash-hov-progreso",
            "dash-hov-resueltos", "dash-hov-cerrados", "dash-hov-sla-no",
        ):
            self.assertIn(esperada, clases)
        self.assertNotIn("stat-chip", html)

    def test_en_resueltas_salen_los_dos_distintivos(self):
        # En el filtro de resueltas sale solo "Resuelto" (ya no van pegados).
        self._ticket(Ticket.Estado.CERRADO, "ZK-Resuelta", resuelta=True)
        html = self._listado(Ticket.Estado.RESUELTO)
        self.assertEqual(html.count("status-pill status-resuelto"), 2)  # tabla y tarjetas
        self.assertNotIn("status-pill status-cerrado", html)

    def test_en_cerradas_solo_sale_el_distintivo_cerrado(self):
        # Aunque se haya resuelto, en el filtro de cerradas solo se ve
        # "Cerrado": es lo que se está mirando en esa lista.
        self._ticket(Ticket.Estado.CERRADO, "ZK-Resuelta", resuelta=True)
        self._ticket(Ticket.Estado.CERRADO, "ZK-Solo-cerrada")
        html = self._listado(Ticket.Estado.CERRADO)
        self.assertNotIn("status-pill status-resuelto", html)
        self.assertEqual(html.count("status-pill status-cerrado"), 4)  # tabla y tarjetas

    def test_una_abierta_conserva_su_unico_distintivo(self):
        self._ticket(Ticket.Estado.ABIERTO, "ZK-Abierta")
        html = self._listado(Ticket.Estado.ABIERTO)
        self.assertIn("status-pill status-abierto", html)
        self.assertNotIn("status-pill status-resuelto", html)
        self.assertNotIn("status-pill status-cerrado", html)

    def test_cierre_directo_no_muestra_resuelto_sin_filtro(self):
        self._ticket(Ticket.Estado.CERRADO, "Solo cerrado")
        html = self.client.get(reverse("tickets:lista"), {"per_page": 0}).content.decode()
        self.assertIn("status-pill status-cerrado", html)
        self.assertNotIn("status-pill status-resuelto", html)

    def test_los_mensajes_de_confirmacion_avisan_la_accion(self):
        """Al cambiar de estado se avisa qué va a pasar antes de hacerlo."""
        html = self.client.get(reverse("tickets:lista")).content.decode()
        self.assertIn("Se activará el trabajo del técnico", html)
        self.assertIn("se cerrará", html)
        self.assertIn("¿Continuar?", html)

    def test_el_comentario_de_la_plantilla_no_se_imprime(self):
        """Un {# #} de varias lineas no lo reconoce Django y se veria en pantalla."""
        self._ticket(Ticket.Estado.ABIERTO, "ZK-Abierta")
        html = self._listado(Ticket.Estado.ABIERTO)
        self.assertNotIn("{#", html)
        self.assertNotIn("#}", html)

    def test_detalle_con_actividad_abierta_y_seguimiento_unido(self):
        ticket = self._ticket(Ticket.Estado.ABIERTO, "ZK-Abierta")
        html = self.client.get(
            reverse("tickets:detalle", args=[ticket.pk])
        ).content.decode()
        self.assertIn('id="td-followup-list"', html)
        self.assertIn(".td-followup-list { max-height:150px; overflow-y:auto", html)
        self.assertIn('aria-label="Seguimientos del ticket; desplázate para ver más"', html)
        self.assertIn("Agregar seguimiento", html)
        self.assertIn('name="action" value="comentario"', html)
        self.assertNotIn("corp-notif-toggle", html)

    def test_graficos_con_titulos_hover_y_colores(self):
        from django.contrib.staticfiles import finders

        with open(finders.find("js/panel-dash.js"), encoding="utf-8") as f:
            js = f.read()
        self.assertIn("chart-refresh-btn", js)
        self.assertIn('Recargar el gráfico', js)
        # Tipos en colores, no en gris.
        self.assertIn('fill="#D62B1F"', js)
        self.assertIn('stroke="#2563EB"', js)
        with open(finders.find("css/dogger-theme.css"), encoding="utf-8") as f:
            css = f.read()
        self.assertIn(".chart-card .dash-head-tools", css)
        self.assertIn("hover: none", css)
        self.assertIn("justify-content: center;", css)
        self.assertIn("repeat(auto-fit, minmax(150px, 1fr))", css)

    def test_tecnicos_en_tarjetas_con_foto_y_semaforo(self):
        import json

        from django.contrib.staticfiles import finders

        self._ticket(Ticket.Estado.ABIERTO, "ZK-Abierta")
        datos = json.loads(self.client.get(
            reverse("tickets:panel_tecnico"), {"vista": "panel"}).context["dash_json"])
        filas = datos["pivot"]["dimensiones"]["tecnico"]["rows"]
        self.assertTrue(filas)
        self.assertIn("foto", filas[0])
        self.assertIn("clave", filas[0])
        with open(finders.find("js/panel-dash.js"), encoding="utf-8") as f:
            js = f.read()
        self.assertNotIn("renderPivotCards", js)
        self.assertIn("pivot-lead", js)

    def test_ventanita_compacta_y_unificada(self):
        from django.contrib.staticfiles import finders

        html = self.client.get(
            reverse("tickets:panel_tecnico"), {"vista": "panel"}).content.decode()
        # Sin CSS duplicado en plantillas: una sola fuente global.
        self.assertNotIn(".pivot-pop-ticket {", html)
        with open(finders.find("css/dogger-theme.css"), encoding="utf-8") as f:
            css = f.read()
        self.assertIn(".pivot-pop {", css)
        self.assertIn("width: 248px", css)
        self.assertIn("font-family: var(--font-corp)", css)
        self.assertIn("position: fixed", css)
