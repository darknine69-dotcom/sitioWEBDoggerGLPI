from django import forms
from django.conf import settings
from django.contrib.auth import get_user_model
import re
import warnings
from pathlib import Path
from PIL import Image, UnidentifiedImageError

from .models import Categoria, CategoriaGrupo, Ticket, TicketComentario
from .sugerencia_categoria import sugerir_categoria

User = get_user_model()

EMAIL_STRICT = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9\-]+(\.[A-Za-z0-9\-]+)*\.[A-Za-z]{2,}$")
EMAIL_STRICT_MSG = "Ingresa un correo válido, por ejemplo: nombre@dogger.com.co"

ALLOWED_CONTENT_TYPES = {
    "image/png",
    "image/jpeg",
    "image/jpg",
    "image/gif",
    "image/webp",
    "application/pdf",
}

def validar_contenido_adjunto(archivo, solo_imagen=False):
    """Comprueba el contenido y normaliza el MIME, sin confiar en el cliente."""
    extension = Path(archivo.name).suffix.lower()
    permitidas = {".png": "PNG", ".jpg": "JPEG", ".jpeg": "JPEG", ".gif": "GIF", ".webp": "WEBP"}
    try:
        archivo.seek(0)
        if extension == ".pdf" and not solo_imagen:
            if archivo.read(5) != b"%PDF-":
                raise forms.ValidationError("El archivo no es un PDF válido.")
            archivo.seek(max(0, archivo.size - 2048))
            if b"%%EOF" not in archivo.read(2048):
                raise forms.ValidationError("El PDF está incompleto o no es válido.")
            archivo.content_type = "application/pdf"
            return
        if extension not in permitidas:
            raise forms.ValidationError("Formato de archivo no permitido.")
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(archivo) as imagen:
                if imagen.format != permitidas[extension]:
                    raise forms.ValidationError("La extensión no coincide con el contenido de la imagen.")
                imagen.verify()
        archivo.content_type = "image/" + {"JPEG": "jpeg", "PNG": "png", "GIF": "gif", "WEBP": "webp"}[permitidas[extension]]
    except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError, Image.DecompressionBombWarning):
        raise forms.ValidationError("La imagen no es válida o es demasiado grande.")
    finally:
        archivo.seek(0)


def categorias_agrupadas():
    """
    Choices agrupadas por categoría principal para <optgroup>:
    [( 'Grupo', [Categoria, ...] ), ...]
    """
    cats = Categoria.objects.filter(activo=True).order_by("grupo", "nombre")
    grupos: dict[str, list[Categoria]] = {}
    for c in cats:
        grupos.setdefault(c.grupo, []).append(c)
    return [(grupo, subs) for grupo, subs in grupos.items()]


class MultipleFileInput(forms.ClearableFileInput):
    allow_multiple_selected = True


class MultipleFileField(forms.FileField):
    def __init__(self, *args, **kwargs):
        kwargs.setdefault("widget", MultipleFileInput())
        super().__init__(*args, **kwargs)

    def clean(self, data, initial=None):
        single = super().clean
        if isinstance(data, (list, tuple)):
            return [single(d, initial) for d in data]
        return [single(data, initial)]


class GroupedModelChoiceIterator(forms.models.ModelChoiceIterator):
    """Iterador que genera <optgroup> a partir de choices agrupadas."""

    def __iter__(self):
        if self.field.empty_label is not None:
            yield ("", self.field.empty_label)
        for grupo, subs in categorias_agrupadas():
            yield (grupo, [self.choice(sub) for sub in subs])


class GroupedCategoriaChoiceField(forms.ModelChoiceField):
    iterator = GroupedModelChoiceIterator

    def label_from_instance(self, obj):
        return obj.nombre


def _campo_categoria(**kwargs):
    campo = GroupedCategoriaChoiceField(
        queryset=Categoria.objects.filter(activo=True), **kwargs
    )
    return campo


class TicketForm(forms.ModelForm):
    adjuntos = MultipleFileField(
        required=False,
        label="Capturas / archivos",
        help_text="PNG, JPG, WEBP, GIF o PDF · max. 5 · 8 MB c/u",
    )

    class Meta:
        model = Ticket
        labels = {"titulo": "Asunto"}
        fields = [
            "titulo",
            "categoria",
            "solicitante_punto",
            "modo",
            "descripcion",
            "solicitante_nombre",
            "solicitante_email",
            "adjuntos",
        ]
        widgets = {
            "titulo": forms.TextInput(
                attrs={
                    "placeholder": "Ej: no imprime la factura / SIESA Access lento",
                    "maxlength": 150,
                    "required": "required",
                    "title": "Es obligatorio escribir un título.",
                }
            ),
            "descripcion": forms.Textarea(
                attrs={
                    "rows": 4,
                    "placeholder": "Describe el problema. Incluye punto de venta, PC (ej. PC-P1 PC5) o modulo SIESA si aplica...",
                    "required": "required",
                    "title": "Es obligatorio describir el problema.",
                }
            ),
            "solicitante_nombre": forms.TextInput(attrs={"placeholder": "Tu nombre completo"}),
            "solicitante_email": forms.EmailInput(attrs={"placeholder": "correo@dogger.com.co"}),
            "solicitante_punto": forms.TextInput(
                attrs={"placeholder": "Ej: Envigado Caja 3 · PC-P1 · Server Principal"}
            ),
        }

    def __init__(
        self,
        *args,
        permitir_modo=False,
        categoria_automatica=False,
        categoria_preseleccionada=False,
        **kwargs,
    ):
        self._modo_fijo = None
        # Las cuentas solicitantes no clasifican el incidente: Dogger lo hace
        # a partir del asunto y la descripción para conservar una asignación
        # consistente. El staff sigue teniendo el selector disponible.
        self._categoria_automatica = categoria_automatica
        # Una categoría elegida desde el catálogo es una decisión explícita
        # del solicitante. No debe ocultarse ni ser sustituida por la
        # clasificación textual al enviar el formulario.
        self._categoria_preseleccionada = categoria_preseleccionada
        super().__init__(*args, **kwargs)
        self.fields["categoria"] = _campo_categoria(required=False)
        self.fields["categoria"].empty_label = "— Categoría en análisis automático —"
        if self._categoria_automatica and not self._categoria_preseleccionada:
            self.fields["categoria"].widget.attrs.update(
                {
                    "disabled": "disabled",
                    "aria-disabled": "true",
                    "class": "categoria-automatica",
                    "title": "Dogger asigna esta categoría automáticamente.",
                }
            )
        self.fields["solicitante_email"].required = False
        self.fields["solicitante_punto"].required = False
        if not permitir_modo:
            self.fields.pop("modo")
            self._modo_fijo = Ticket.Modo.WEB
        else:
            # La plantilla no dibuja este campo, asi que nunca viaja en el POST.
            # Si se dejara obligatorio, todo alta desde el panel devolveria
            # "Este campo es obligatorio" sin que el usuario pueda corregirlo.
            self.fields["modo"].required = False
            self.fields["modo"].initial = Ticket.Modo.WEB

    def clean_adjuntos(self):
        files = self.cleaned_data.get("adjuntos") or []
        files = [f for f in files if f]
        max_files = settings.DOGGER.get("max_adjuntos", 5)
        max_mb = settings.DOGGER.get("max_adjunto_mb", 8)
        max_bytes = max_mb * 1024 * 1024
        if len(files) > max_files:
            raise forms.ValidationError(f"Maximo {max_files} archivos por ticket.")
        for f in files:
            if f.size > max_bytes:
                raise forms.ValidationError(f'"{f.name}" supera el limite de {max_mb} MB.')
            validar_contenido_adjunto(f)
        return files

    def clean(self):
        cleaned = super().clean()
        if "modo" in cleaned:
            cleaned["modo"] = cleaned.get("modo") or Ticket.Modo.WEB
        if (
            (self._categoria_automatica and not self._categoria_preseleccionada)
            or not cleaned.get("categoria")
        ):
            sugerida = sugerir_categoria(
                titulo=cleaned.get("titulo", ""),
                descripcion=cleaned.get("descripcion", ""),
            )
            # Aunque alguien modifique el HTML del navegador, una cuenta
            # solicitante no puede forzar otra categoría en el POST.
            cleaned["categoria"] = sugerida
        return cleaned

    def save(self, commit=True):
        ticket = super().save(commit=False)
        if self._modo_fijo:
            ticket.modo = self._modo_fijo
        # Auto-asignar prioridad según ANS de la categoría
        cat = ticket.categoria
        if cat and hasattr(cat, "prioridad_default"):
            ticket.prioridad = cat.prioridad_default
        if commit:
            ticket.save()
        return ticket


class TicketEdicionForm(forms.ModelForm):
    """Edición del ticket por su solicitante mientras está abierto."""

    class Meta:
        model = Ticket
        fields = ["titulo", "prioridad", "categoria", "descripcion", "solicitante_punto"]
        widgets = {
            "titulo": forms.TextInput(attrs={"maxlength": 150}),
            "descripcion": forms.Textarea(attrs={"rows": 4}),
            "solicitante_punto": forms.TextInput(
                attrs={"placeholder": "Ej: Envigado Caja 3 · PC-P1 · Server Principal"}
            ),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["categoria"] = _campo_categoria(required=False)
        self.fields["categoria"].empty_label = "— Selecciona categoria —"


class CategoriaForm(forms.ModelForm):
    class Meta:
        model = Categoria
        fields = [
            "grupo",
            "nombre",
            "descripcion",
            "prioridad_default",
            "ans_horas",
            "glpi_category_id",
            "tecnico_default",
        ]
        widgets = {
            "grupo": forms.TextInput(
                attrs={"list": "lista-grupos", "placeholder": "Ej: SIESA ERP"}
            ),
            "nombre": forms.TextInput(attrs={"placeholder": "Ej: Facturación electrónica"}),
            "descripcion": forms.Textarea(
                attrs={
                    "rows": 2,
                    "placeholder": "Describe qué casos corresponden a esta subcategoría",
                }
            ),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        grupos = set(CategoriaGrupo.objects.values_list("nombre", flat=True))
        grupos.update(Categoria.objects.values_list("grupo", flat=True).distinct())
        opciones_grupo = sorted(grupos, key=str.casefold)
        self.fields["grupo"] = forms.ChoiceField(
            label="Categoría principal",
            choices=[("", "— Selecciona una categoría principal —")]
            + [(grupo, grupo) for grupo in opciones_grupo],
        )
        self.fields["tecnico_default"].queryset = User.objects.filter(
            activo=True, rol__in=["admin", "tecnico"]
        ).order_by("nombre")
        self.fields["tecnico_default"].required = False
        self.fields["glpi_category_id"].required = False


class CategoriaGrupoForm(forms.ModelForm):
    class Meta:
        model = CategoriaGrupo
        fields = ["nombre"]
        widgets = {
            "nombre": forms.TextInput(
                attrs={"placeholder": "Ej: Infraestructura", "maxlength": 50}
            ),
        }

    def clean_nombre(self):
        nombre = self.cleaned_data["nombre"].strip()
        if CategoriaGrupo.objects.filter(nombre__iexact=nombre).exists():
            raise forms.ValidationError("Ya existe una categoría principal con ese nombre.")
        if Categoria.objects.filter(grupo__iexact=nombre).exists():
            raise forms.ValidationError(
                "Ese nombre ya está en uso por un grupo con subcategorías."
            )
        return nombre


class UsuarioPanelForm(forms.Form):
    """Alta/edición de cuentas desde el panel del administrador."""

    ROL_CHOICES = [
        ("usuario", "Usuario"),
        ("tecnico", "Técnico"),
        ("observador", "Observador"),
        ("admin", "Administrador"),
    ]

    nombre = forms.CharField(max_length=100)
    email = forms.EmailField()
    rol = forms.ChoiceField(choices=ROL_CHOICES)
    glpi_user_id = forms.IntegerField(required=False, min_value=1)
    activo = forms.BooleanField(required=False, initial=True)
    # La casilla que el administrador enciende para que la propia persona pueda
    # cambiar de rol desde su barra superior. Nada la marca sola: quien decide
    # es el administrador desde esta ficha.
    cambio_rol_habilitado = forms.BooleanField(required=False, initial=False)
    telefono = forms.CharField(required=False, max_length=20)
    ubicacion = forms.CharField(required=False, max_length=120)
    password1 = forms.CharField(
        required=False,
        widget=forms.PasswordInput,
        label="Contraseña (vacía = sin cambios)",
    )

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()
        if not EMAIL_STRICT.match(email):
            raise forms.ValidationError(EMAIL_STRICT_MSG)
        return email


class ConsultaTicketForm(forms.Form):
    codigo = forms.CharField(
        max_length=12,
        label="Codigo del ticket",
        widget=forms.TextInput(attrs={"placeholder": "DG-EN-0001 o HD-0001", "style": "text-transform:uppercase"}),
    )


class ComentarioForm(forms.ModelForm):
    class Meta:
        model = TicketComentario
        fields = ["comentario", "es_interno"]
        widgets = {
            "comentario": forms.Textarea(attrs={"rows": 3, "placeholder": "Escribe un seguimiento, respuesta o novedad..."}),
        }


class AsignarTecnicoForm(forms.Form):
    tecnico = forms.ModelChoiceField(
        queryset=User.objects.none(),
        required=False,
        empty_label="— Sin asignar —",
        label="Tecnico asignado",
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["tecnico"].queryset = User.objects.filter(
            activo=True, rol__in=["admin", "tecnico"]
        ).order_by("nombre")
