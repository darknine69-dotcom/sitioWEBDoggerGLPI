import uuid
import re
import unicodedata
from datetime import timedelta
from pathlib import Path

from django.conf import settings
from django.db import IntegrityError, models, transaction
from django.db.models import Count, Q
from django.utils import timezone

from .sla import horas_por_prioridad, formatear_duracion
from .cifrado import CampoCifrado


class TareaDiferida(models.Model):
    """Trabajo de correo o GLPI persistido hasta su procesamiento."""
    class Estado(models.TextChoices):
        PENDIENTE = "pendiente", "Pendiente"
        PROCESANDO = "procesando", "Procesando"
        COMPLETADA = "completada", "Completada"
        FALLIDA = "fallida", "Fallida"
        REVISAR = "revisar", "Resultado desconocido"

    tipo = models.CharField(max_length=30)
    datos = CampoCifrado()
    estado = models.CharField(max_length=16, choices=Estado.choices, default=Estado.PENDIENTE)
    intentos = models.PositiveIntegerField(default=0)
    disponible_en = models.DateTimeField(default=timezone.now)
    reservado_en = models.DateTimeField(null=True, blank=True)
    creado_en = models.DateTimeField(auto_now_add=True)
    actualizado_en = models.DateTimeField(auto_now=True)
    ultimo_error = models.CharField(max_length=120, blank=True, default="")

    class Meta:
        indexes = [models.Index(fields=["estado", "disponible_en"], name="tarea_estado_disponible_idx")]


class ConfiguracionAutoasignacion(models.Model):
    """Configuración opt-in; la migración no activa el motor automáticamente."""
    activa = models.BooleanField(default=False)
    peso_urgente = models.PositiveIntegerField(default=5)
    peso_alta = models.PositiveIntegerField(default=3)
    peso_media = models.PositiveIntegerField(default=2)
    peso_baja = models.PositiveIntegerField(default=1)
    margen_puntos = models.PositiveSmallIntegerField(default=20)
    secuencia = models.PositiveBigIntegerField(default=0)


class Categoria(models.Model):
    """
    Categorias alineadas a la infraestructura Dogger (STATU QUO):
    SIESA ERP/Web, POS, red/firewall, servidores, correo, endpoints, etc.
    """
    grupo = models.CharField("Grupo", max_length=50)
    nombre = models.CharField("Nombre", max_length=80)
    descripcion = models.TextField(
        "Qué significa esta subcategoría",
        blank=True,
        default="",
        help_text="Explica qué problemas incluye y cuándo se debe elegir.",
    )
    activo = models.BooleanField(default=True)
    prioridad_default = models.CharField(
        "Prioridad por defecto (ANS)",
        max_length=20,
        choices=[("baja", "Baja"), ("media", "Media"), ("alta", "Alta"), ("urgente", "Urgente")],
        default="media",
        help_text="Prioridad que se asigna automáticamente según el ANS de esta categoría",
    )
    ans_horas = models.PositiveIntegerField(
        "Horas ANS",
        default=24,
        help_text="Tiempo máximo (horas) para resolver tickets de esta categoría. Si no se define, se usa el valor base de la prioridad.",
    )
    glpi_category_id = models.PositiveIntegerField(
        "ID categoria GLPI", null=True, blank=True
    )
    tecnico_default = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="categorias_asignadas",
        db_column="TecnicoDefaultId",
        verbose_name="Técnico por defecto",
        help_text="Se asigna automáticamente a los tickets nuevos de esta categoría",
    )

    class Meta:
        db_table = "Categorias"
        verbose_name = "Categoria"
        verbose_name_plural = "Categorias"
        unique_together = [("grupo", "nombre")]
        ordering = ["grupo", "nombre"]

    def __str__(self):
        return f"{self.nombre} ({self.grupo})"

    @classmethod
    def arbol(cls):
        """
        Agrupa las categorías por 'grupo' (categoría principal encapsulando
        subcategorías relacionadas), con conteo de tickets por cada una.
        """
        from django.db.models import Count as _Count

        cats = (
            cls.objects.filter(activo=True)
            .annotate(tickets_count=_Count("tickets"))
            .order_by("grupo", "nombre")
        )
        arbol = {}
        for c in cats:
            arbol.setdefault(c.grupo, []).append(c)
        return [
            {"grupo": grupo, "subcategorias": subs, "total": sum(s.tickets_count for s in subs)}
            for grupo, subs in arbol.items()
        ]


class CategoriaGrupo(models.Model):
    nombre = models.CharField("Categoría principal", max_length=50, unique=True)

    class Meta:
        db_table = "CategoriaGrupos"
        verbose_name = "Categoría principal"
        verbose_name_plural = "Categorías principales"
        ordering = ["nombre"]

    def __str__(self):
        return self.nombre


class TicketQuerySet(models.QuerySet):
    def update(self, **kwargs):
        protegidos = {"estado", "fecha_resolucion", "fecha_cierre", "ans_inicio_original",
                      "ans_limite_original", "ans_duracion_original", "ans_prioridad_original",
                      "ans_categoria_original", "ans_categoria_original_id", "ans_fuente_original",
                      "ans_verificacion", "ans_version_ajuste"}
        if protegidos.intersection(kwargs):
            raise ValueError("Los campos protegidos requieren el servicio transaccional ANS.")
        return super().update(**kwargs)

    def _actualizar_estado_ans(self, estado):
        """Uso interno: el servicio debe registrar el evento en la misma transacción."""
        return super().update(estado=estado)

    def _reservar_version_ajuste(self, version):
        return super().update(ans_version_ajuste=version)

    def _establecer_instantanea_inicial(self, valores):
        if set(valores) != {"ans_inicio_original", "ans_limite_original", "ans_duracion_original",
                            "ans_prioridad_original", "ans_categoria_original", "ans_categoria_original_id",
                            "ans_fuente_original", "ans_verificacion"}:
            raise ValueError("Instantánea inicial incompleta")
        return super(TicketQuerySet, self.filter(ans_limite_original__isnull=True)).update(**valores)

    def bulk_create(self, objs, *args, **kwargs):
        # Django omite save() en bulk_create: no permitir tickets sin plazo.
        raise NotImplementedError("Crea los tickets individualmente para conservar su ANS.")


class TicketActivosManager(models.Manager.from_queryset(TicketQuerySet)):
    """Por defecto NO se ven los tickets enviados a la papelera.

    Todas las vistas, el dashboard, los reportes y la sincronización con GLPI
    usan `Ticket.objects`, así que un ticket eliminado no se cuela en ningún
    listado ni en los KPI. Para la papelera está `Ticket.con_eliminados`.
    """

    def get_queryset(self):
        return super().get_queryset().filter(eliminado_en__isnull=True)


class TicketConEliminadosManager(models.Manager.from_queryset(TicketQuerySet)):
    """Acceso sin filtrar, para la papelera y las gráficas "eliminadas"."""


class Ticket(models.Model):
    class Prioridad(models.TextChoices):
        BAJA = "baja", "Baja"
        MEDIA = "media", "Media"
        ALTA = "alta", "Alta"
        URGENTE = "urgente", "Urgente"

    class Estado(models.TextChoices):
        ABIERTO = "abierto", "Abierto"
        EN_PROGRESO = "en-progreso", "En progreso"
        RESUELTO = "resuelto", "Resuelto"
        CERRADO = "cerrado", "Cerrado"

    class Modo(models.TextChoices):
        WEB = "web", "Web Form"
        EMAIL = "email", "E-Mail"
        TELEFONO = "telefono", "Phone Call"
        IMPORTADO = "importado", "Importado GLPI"

    codigo = models.CharField("Codigo", max_length=12, unique=True, editable=False)
    titulo = models.CharField("Titulo", max_length=150)
    descripcion = models.TextField("Descripcion")
    prioridad = models.CharField(
        max_length=10,
        choices=Prioridad.choices,
        default=Prioridad.MEDIA,
    )
    categoria = models.ForeignKey(
        Categoria,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="tickets",
        db_column="CategoriaId",
    )
    estado = models.CharField(
        max_length=15,
        choices=Estado.choices,
        default=Estado.ABIERTO,
    )
    solicitante_nombre = models.CharField("Solicitante", max_length=100)
    solicitante_email = models.EmailField("Correo", max_length=150, blank=True, null=True)
    solicitante_punto = models.CharField(
        "Punto / sede / equipo",
        max_length=80,
        blank=True,
        null=True,
    )
    modo = models.CharField(
        "Modo de ingreso",
        max_length=20,
        choices=Modo.choices,
        default=Modo.WEB,
        help_text="Canal por el que ingresó la solicitud (portal, correo o llamada).",
    )
    tecnico_asignado = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="tickets_asignados",
        db_column="TecnicoAsignadoId",
    )
    fecha_asignacion_tecnico = models.DateTimeField(null=True, blank=True)
    asignacion_automatica = models.BooleanField(
        "Asignación automática",
        default=False,
        help_text="True cuando el técnico se asignó por regla de categoría",
    )
    asignacion_manual_protegida = models.BooleanField(
        default=False, editable=False,
        help_text="Impide que el motor anule una decisión manual, incluso si deja el ticket sin técnico.",
    )
    glpi_id = models.PositiveIntegerField("ID GLPI", null=True, blank=True, db_index=True)
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    fecha_actualizacion = models.DateTimeField(auto_now=True)
    fecha_cierre = models.DateTimeField(null=True, blank=True)
    # Cuándo se marcó resuelto. Al resolver, el ticket queda cerrado, así que
    # `estado` por sí solo no dice si hubo un "marcar resuelto" de por medio:
    # un ticket se puede cerrar directamente desde abierto o en progreso. Este
    # campo es lo que permite mostrar el distintivo "Resuelto" con verdad y
    # filtrar por "Resueltas" sin incluir los que solo se cerraron.
    fecha_resolucion = models.DateTimeField(null=True, blank=True)
    ans_inicio_original = models.DateTimeField(null=True, blank=True, editable=False)
    ans_limite_original = models.DateTimeField(null=True, blank=True, editable=False)
    ans_duracion_original = models.PositiveIntegerField(null=True, blank=True, editable=False)
    ans_prioridad_original = models.CharField(max_length=10, null=True, blank=True, editable=False)
    ans_categoria_original = models.CharField(max_length=180, null=True, blank=True, editable=False)
    ans_categoria_original_id = models.PositiveIntegerField(null=True, blank=True, editable=False)
    ans_fuente_original = models.CharField(max_length=20, null=True, blank=True, editable=False)
    ans_verificacion = models.CharField(max_length=20, default="desconocido", editable=False, choices=[("verificado", "Verificado"), ("reconstruido", "Reconstruido"), ("desconocido", "Desconocido")])
    ans_version_ajuste = models.PositiveIntegerField(default=0, editable=False)
    # --- ANS: cuándo se avisó por última vez de que el ticket iba a vencer ---
    # Un solo aviso por ticket. Ni el cron ni el panel vuelven a mandar nada
    # mientras esta marca exista, así el técnico, el usuario y el observador
    # no reciben el mismo correo cada vez que alguien mira el tablero.
    ans_alertado_en = models.DateTimeField(
        "Aviso ANS enviado", null=True, blank=True, db_index=True
    )
    # --- Papelera: el borrado es lógico, se puede restaurar ---
    eliminado_en = models.DateTimeField(
        "Eliminado", null=True, blank=True, db_index=True
    )
    eliminado_por = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="tickets_eliminados",
        db_column="EliminadoPorId",
        verbose_name="Eliminado por",
    )

    objects = TicketActivosManager()
    con_eliminados = TicketConEliminadosManager()

    class Meta:
        db_table = "Tickets"
        verbose_name = "Ticket"
        verbose_name_plural = "Tickets"
        ordering = ["-fecha_creacion"]
        indexes = [
            models.Index(fields=["estado"], name="IX_Tickets_Estado"),
            models.Index(fields=["prioridad"], name="IX_Tickets_Prioridad"),
            models.Index(fields=["fecha_creacion"], name="IX_Tickets_Fecha"),
            # Filtros calientes: panel propio, listas y chat por solicitante
            # o por técnico casi siempre combinados con estado.
            models.Index(fields=["solicitante_email", "estado"], name="IX_Tickets_SolEst"),
            models.Index(fields=["tecnico_asignado", "estado"], name="IX_Tickets_TecEst"),
            models.Index(fields=["solicitante_punto"], name="IX_Tickets_Punto"),
        ]

    @classmethod
    def en_papelera(cls):
        """Tickets enviados a la papelera (excluidos de `objects`)."""
        return cls.con_eliminados.filter(eliminado_en__isnull=False)

    @property
    def en_la_papelera(self):
        return self.eliminado_en is not None

    def mandar_a_la_papelera(self, usuario=None):
        """Borrado lógico: no toca adjuntos ni GLPI, se puede restaurar."""
        self.eliminado_en = timezone.now()
        self.eliminado_por = usuario if getattr(usuario, "pk", None) else None
        self.save(update_fields=["eliminado_en", "eliminado_por", "fecha_actualizacion"])

    def restaurar(self):
        self.eliminado_en = None
        self.eliminado_por = None
        self.save(update_fields=["eliminado_en", "eliminado_por", "fecha_actualizacion"])

    def __str__(self):
        return f"{self.codigo} — {self.titulo}"

    @property
    def fue_resuelto(self):
        """True si en algún momento se marcó resuelto.

        Al resolver, el ticket se cierra, así que `estado` no lo dice: hace
        falta la marca de `fecha_resolucion`. Los tickets antiguos que siguen
        en estado "resuelto" también cuentan.
        """
        return bool(self.fecha_resolucion) or self.estado == self.Estado.RESUELTO

    @property
    def esta_cerrado(self):
        return self.estado == self.Estado.CERRADO

    @property
    def fecha_finalizacion(self):
        """Primera marca terminal: resolución o cierre directo."""
        fechas = [fecha for fecha in (self.fecha_resolucion, self.fecha_cierre) if fecha]
        return min(fechas) if fechas else None

    def save(self, *args, **kwargs):
        nuevo = self._state.adding
        if not nuevo:
            campos = kwargs.get("update_fields")
            protegidos = {"estado", "fecha_resolucion", "fecha_cierre", "ans_inicio_original",
                          "ans_limite_original", "ans_duracion_original", "ans_prioridad_original",
                          "ans_categoria_original", "ans_categoria_original_id", "ans_fuente_original",
                          "ans_verificacion", "ans_version_ajuste"}
            a_revisar = protegidos if campos is None else protegidos.intersection(campos)
            a_revisar -= self.get_deferred_fields()
            if self.pk and a_revisar:
                anterior = type(self).con_eliminados.using(kwargs.get("using") or self._state.db).filter(pk=self.pk).values(*a_revisar).first()
                if anterior:
                    cambios = {nombre for nombre in a_revisar if getattr(self, nombre) != anterior[nombre]}
                    instantaneas = cambios - {"estado", "fecha_resolucion", "fecha_cierre"}
                    if instantaneas:
                        raise ValueError("La instantánea ANS no puede modificarse mediante save().")
                    if cambios and not getattr(self, "_ans_transicion_autorizada", False):
                        raise ValueError("Los cambios de estado o fechas de cierre requieren el servicio ANS.")
            return self._guardar_compatibilidad(*args, **kwargs)
        with transaction.atomic(using=kwargs.get("using")):
            self._guardar_compatibilidad(*args, **kwargs)
            if self.fecha_creacion and self.ans_limite_original is None:
                categoria = self.categoria if self.categoria_id else None
                horas = (categoria.ans_horas if categoria and categoria.ans_horas
                         else horas_por_prioridad(self.prioridad))
                valores = {
                    "ans_inicio_original": self.fecha_creacion,
                    "ans_limite_original": self.fecha_creacion + timedelta(hours=horas),
                    "ans_duracion_original": horas,
                    "ans_prioridad_original": self.prioridad,
                    "ans_categoria_original": str(categoria) if categoria else None,
                    "ans_categoria_original_id": self.categoria_id,
                    "ans_fuente_original": "categoria" if categoria and categoria.ans_horas else "prioridad",
                    "ans_verificacion": "verificado",
                }
                type(self).con_eliminados.using(self._state.db).filter(pk=self.pk)._establecer_instantanea_inicial(valores)
                for nombre, valor in valores.items():
                    setattr(self, nombre, valor)

    def _guardar_compatibilidad(self, *args, **kwargs):
        campos = kwargs.get("update_fields")
        if campos is None or "tecnico_asignado" in campos or "tecnico_asignado_id" in campos:
            anterior = None
            if self.pk:
                anterior = type(self).con_eliminados.filter(pk=self.pk).values_list("tecnico_asignado_id", flat=True).first()
            if anterior != self.tecnico_asignado_id:
                self.fecha_asignacion_tecnico = timezone.now() if self.tecnico_asignado_id else None
                if campos is not None:
                    kwargs["update_fields"] = set(campos) | {"fecha_asignacion_tecnico"}
        codigo_generado = not self.codigo
        if codigo_generado:
            self.codigo = self._generar_codigo()
        if self._state.adding or getattr(self, "_ans_transicion_autorizada", False):
            if self.estado in (self.Estado.RESUELTO, self.Estado.CERRADO) and not self.fecha_cierre:
                self.fecha_cierre = timezone.now()
            if self.estado in (self.Estado.ABIERTO, self.Estado.EN_PROGRESO):
                self.fecha_cierre = None
                self.fecha_resolucion = None
            if self.estado == self.Estado.RESUELTO and not self.fecha_resolucion:
                self.fecha_resolucion = timezone.now()
        try:
            with transaction.atomic(using=kwargs.get("using")):
                super().save(*args, **kwargs)
        except IntegrityError:
            es_insert = not self.pk or kwargs.get("force_insert")
            if es_insert and codigo_generado and type(self).con_eliminados.filter(codigo=self.codigo).exists():
                # Colisión de código (p. ej. por concurrencia o porque otro
                # ticket usa el código): se avanza hasta encontrar uno libre.
                for _ in range(20):
                    self.codigo = self._generar_codigo()
                    kwargs["force_insert"] = True
                    try:
                        with transaction.atomic(using=kwargs.get("using")):
                            super().save(*args, **kwargs)
                        break
                    except IntegrityError:
                        if not type(self).con_eliminados.filter(codigo=self.codigo).exists():
                            raise
                        continue
                else:
                    raise
            else:
                raise

    def _generar_codigo(self):
        """Código DG con iniciales del punto y consecutivo del historial completo."""
        punto = unicodedata.normalize("NFKD", self.solicitante_punto or "")
        letras = "".join(c for c in punto.upper() if "A" <= c <= "Z")
        iniciales = letras[:2] if len(letras) >= 2 else "XX"
        historico = type(self).con_eliminados.all()
        mayor = 0
        for codigo in historico.values_list("codigo", flat=True).iterator():
            match = re.fullmatch(r"(?:HD|DG-[A-Z]{2})-(\d+)", codigo or "", re.IGNORECASE)
            if match:
                mayor = max(mayor, int(match.group(1)))
        numero = max(mayor + 1, historico.count() + 1)
        if numero > 999999:
            raise ValueError("El consecutivo de tickets superó la capacidad del código.")
        return f"DG-{iniciales}-{numero:04d}"

    @property
    def adjuntos_pendientes_glpi(self) -> bool:
        """True si hay adjuntos que aún no se han subido a GLPI."""
        if not self.pk:
            return False
        return self.adjuntos.filter(sincronizado_glpi=False).exists()

    # ------------------------------------------------------------------
    # ANS: tiempos objetivo de resolución según prioridad de la categoría
    # ------------------------------------------------------------------
    @property
    def ans_horas(self) -> int:
        if self.ans_duracion_original is not None:
            return self.ans_duracion_original
        if self.categoria_id and self.categoria and self.categoria.ans_horas:
            return self.categoria.ans_horas
        return horas_por_prioridad(self.prioridad)

    @property
    def fecha_limite_ans(self):
        if self.pk and self.ans_version_ajuste:
            ajuste = self.ajustes_ans.order_by("-version").first()
            if ajuste:
                return ajuste.limite_nuevo
        if self.ans_limite_original is not None:
            return self.ans_limite_original
        if not self.fecha_creacion:
            return None
        return self.fecha_creacion + timedelta(hours=self.ans_horas)

    @property
    def info_ans(self):
        """
        Tupla (estado, texto, detalle) para mostrar el ANS del ticket.

        estado: 'ok' | 'por-vencer' | 'vencido' | 'resuelto' | None
          - abiertos/en progreso: tiempo restante para el límite (o vencido).
          - resuelto/cerrado: tiempo tomado en resolverse.
        """
        estado, texto, detalle, _limite, _aviso = self.datos_ans
        return (estado, texto, detalle)

    @property
    def datos_ans(self):
        """
        Lo mismo que `info_ans`, y además las dos fechas que el cronómetro del
        navegador necesita para seguir corriendo sin recargar la página:

          limite: segundos epoch del vencimiento del ANS.
          aviso:  segundos epoch a partir del cual el ANS pasa a "por vencer".

        Los dos los decide aquí el servidor con la misma regla para todos, así
        la etiqueta y el cronómetro nunca se contradicen.
        """
        return self.datos_ans_desde_resultado()

    def datos_ans_desde_resultado(self, resultado=None):
        """Adaptador de presentación compatible; puede reutilizar un cálculo por lote."""
        from apps.tickets.services.motor_ans import calcular_ans

        if self.estado in (self.Estado.RESUELTO, self.Estado.CERRADO):
            if self.fecha_finalizacion and self.fecha_creacion:
                duracion = self.fecha_finalizacion - self.fecha_creacion
                return ("resuelto", f"Resuelto en {formatear_duracion(duracion)}", None, None, None)
            return ("resuelto", "Resuelto", None, None, None)
        if not self.fecha_creacion or not self.ans_horas:
            return (None, "Sin ANS", None, None, None)
        resultado = resultado or calcular_ans(self, permitir_provisional=True)
        if resultado.estado == "sin_informacion":
            return (None, "Sin ANS", None, None, None)
        limite = resultado.limite
        detalle = f"Límite {limite:%d/%m %H:%M} · ANS {self.ans_horas}h · {self.get_prioridad_display()}"
        limite_ts = int(limite.timestamp())
        if resultado.estado == "vencido":
            return (
                "vencido",
                "Vencido",
                detalle,
                limite_ts,
                limite_ts,
            )
        restante = resultado.restante
        # La alerta se abre exactamente en las dos últimas horas. La última
        # hora queda incluida, sin anticipar el aviso por porcentajes ANS.
        aviso_dt = limite - timedelta(hours=2)
        estado = "por-vencer" if resultado.estado == "por_vencer" else "ok"
        return (
            estado,
            f"Faltan {formatear_duracion(restante)}",
            detalle,
            limite_ts,
            int(aviso_dt.timestamp()),
        )

    @classmethod
    def estadisticas(cls):
        return cls.objects.aggregate(
            total=Count("id"),
            abiertos=Count("id", filter=Q(estado=cls.Estado.ABIERTO)),
            en_progreso=Count("id", filter=Q(estado=cls.Estado.EN_PROGRESO)),
            resueltos=Count("id", filter=Q(estado=cls.Estado.RESUELTO)),
            cerrados=Count("id", filter=Q(estado=cls.Estado.CERRADO)),
        )

    @classmethod
    def tiempo_promedio_resolucion_horas(cls, queryset=None):
        """
        KPI: promedio entre creación y la primera resolución o cierre.
        Retorna string legible o None.
        """
        qs = queryset if queryset is not None else cls.objects.all()
        cerrados = qs.filter(
            Q(fecha_resolucion__isnull=False) | Q(fecha_cierre__isnull=False),
        ).values_list("fecha_creacion", "fecha_resolucion", "fecha_cierre")
        if not cerrados:
            return None
        total_horas = 0.0
        n = 0
        for creacion, resuelto_en, cerrado_en in cerrados:
            cierre = min(fecha for fecha in (resuelto_en, cerrado_en) if fecha)
            if not creacion or cierre < creacion:
                continue
            delta = cierre - creacion
            total_horas += delta.total_seconds() / 3600
            n += 1
        if not n:
            return None
        promedio = total_horas / n
        if promedio < 1:
            return f"{int(promedio * 60)}min"
        elif promedio < 24:
            return f"{promedio:.1f}h"
        else:
            dias = promedio / 24
            return f"{dias:.1f}d"


def adjunto_upload_to(instance, filename):
    ext = Path(filename).suffix.lower() or ".bin"
    codigo = instance.ticket.codigo if instance.ticket_id else "tmp"
    return f"adjuntos/{codigo}/{uuid.uuid4().hex}{ext}"


class TicketAjusteANS(models.Model):
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name="ajustes_ans")
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT)
    limite_anterior = models.DateTimeField(null=True, blank=True)
    limite_nuevo = models.DateTimeField()
    motivo = models.TextField()
    creado_en = models.DateTimeField(default=timezone.now)
    clave = models.CharField(max_length=64, unique=True)
    version = models.PositiveIntegerField()

    class Meta:
        constraints = [models.UniqueConstraint(fields=["ticket", "version"], name="uq_ans_ajuste_version")]


class TicketTransicionANS(models.Model):
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name="transiciones_ans")
    estado_anterior = models.CharField(max_length=15)
    estado_nuevo = models.CharField(max_length=15)
    ocurrido_en = models.DateTimeField(default=timezone.now)
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True)
    ciclo = models.PositiveIntegerField(default=1)
    tipo = models.CharField(max_length=20, choices=[("resolucion", "Resolución"), ("cierre", "Cierre"), ("reapertura", "Reapertura"), ("estado", "Estado")])

    class Meta:
        ordering = ["ocurrido_en", "pk"]


class TicketAdjunto(models.Model):
    ticket = models.ForeignKey(
        Ticket,
        on_delete=models.CASCADE,
        related_name="adjuntos",
        db_column="TicketId",
    )
    nombre_original = models.CharField(max_length=255)
    archivo = models.FileField(upload_to=adjunto_upload_to, max_length=500)
    mime_type = models.CharField(max_length=100)
    tamano_bytes = models.PositiveIntegerField()
    subido_por = models.CharField(max_length=100, blank=True, null=True)
    fecha_subida = models.DateTimeField(auto_now_add=True)
    sincronizado_glpi = models.BooleanField(
        default=False,
        help_text="True cuando el archivo ya fue subido a GLPI como documento del ticket",
    )

    class Meta:
        db_table = "TicketAdjuntos"
        verbose_name = "Adjunto"
        verbose_name_plural = "Adjuntos"
        ordering = ["fecha_subida"]

    def __str__(self):
        return self.nombre_original

    @property
    def es_imagen(self):
        return (self.mime_type or "").startswith("image/")


class TicketComentario(models.Model):
    ticket = models.ForeignKey(
        Ticket,
        on_delete=models.CASCADE,
        related_name="comentarios",
        db_column="TicketId",
    )
    usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="comentarios",
        db_column="UsuarioId",
    )
    autor_nombre = models.CharField(max_length=100, blank=True, default="")
    comentario = models.TextField()
    es_interno = models.BooleanField(
        default=False,
        help_text="Si es True, solo lo ve el staff",
    )
    # Los mensajes de "presionar al técnico" guardan aquí que lo son. El
    # comentario de por sí es uno más del hilo, y sin esta marca no había
    # forma de contarlos ni de separarlos en el panel de monitoreo del
    # técnico, que quiere ver aparte la presión que recibe.
    es_presion = models.BooleanField(
        "Mensaje de presión",
        default=False,
        help_text="Si está activo, el mensaje fue escrito desde el botón de "
        "presionar al técnico (observador o punto de venta).",
    )
    fecha = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "TicketComentarios"
        verbose_name = "Comentario"
        verbose_name_plural = "Comentarios"
        ordering = ["fecha"]
        indexes = [
            # Hilo del chat: comentarios de un ticket en orden.
            models.Index(fields=["ticket", "fecha"], name="IX_Com_TicketFecha"),
        ]

    def __str__(self):
        return f"Comentario en {self.ticket.codigo}"


class MensajeCorporativo(models.Model):
    """Chat corporativo: técnicos, admins y observadores.

    Sin ticket: lo que se habla aquí es coordinación interna (pasar un
    caso, avisar una caída) y nunca lo ve el usuario final. Solo texto,
    sin adjuntos ni GLPI. Sin destinatario es la sala general; con
    destinatario es un directo entre dos personas del staff.
    """

    usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="mensajes_corporativos",
        db_column="UsuarioId",
    )
    destinatario = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="directos_corporativos",
        db_column="DestinatarioId",
        help_text="Vacío = sala general; con valor = directo entre dos.",
    )
    autor_nombre = models.CharField(max_length=100, blank=True, default="")
    texto = models.TextField(db_column="Texto")
    fecha = models.DateTimeField(auto_now_add=True, db_column="Fecha")

    class Meta:
        db_table = "ChatCorporativo"
        verbose_name = "Mensaje corporativo"
        verbose_name_plural = "Sala corporativa"
        ordering = ["fecha"]
        indexes = [
            # Sala (destinatario nulo) y directos por pareja.
            models.Index(fields=["destinatario", "id"], name="IX_Corp_DestId"),
        ]

    def __str__(self):
        return f"Corporativo de {self.autor_nombre or '—'}"


class GlpiEvento(models.Model):
    """
    Bitácora de eventos recibidos desde el webhook de GLPI.
    Alimenta el panel de 'Actividad reciente' del dashboard.
    """
    class Tipo(models.TextChoices):
        CAMBIO_ESTADO = "cambio-estado", "Cambio de estado"
        SEGUIMIENTO = "seguimiento", "Nuevo seguimiento"
        OTRO = "otro", "Otro"

    ticket = models.ForeignKey(
        Ticket,
        on_delete=models.CASCADE,
        related_name="eventos_glpi",
        null=True,
        blank=True,
        db_column="TicketId",
    )
    tipo = models.CharField(max_length=20, choices=Tipo.choices, default=Tipo.OTRO)
    descripcion = models.CharField(max_length=255)
    payload_bruto = models.JSONField(null=True, blank=True)
    fecha = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "GlpiEventos"
        verbose_name = "Evento GLPI"
        verbose_name_plural = "Eventos GLPI"
        ordering = ["-fecha"]
        indexes = [
            models.Index(fields=["-fecha"], name="IX_GlpiEventos_Fecha"),
        ]

    def __str__(self):
        return f"{self.get_tipo_display()} · {self.descripcion}"


class TicketVinculo(models.Model):
    """
    Relación entre solicitudes de la mesa de ayuda.
    - 'combinar': las solicitudes secundarias pasan a gestionarse bajo la principal.
    - 'vincular': las segundarias quedan en una nueva relación visible bajo la principal.
    """

    class Tipo(models.TextChoices):
        COMBINAR = "combinar", "Combinar"
        VINCULAR = "vincular", "Vincular"

    ticket_principal = models.ForeignKey(
        Ticket,
        on_delete=models.CASCADE,
        related_name="vinculos_principales",
        db_column="TicketPrincipalId",
        verbose_name="Solicitud principal",
    )
    ticket_secundario = models.ForeignKey(
        Ticket,
        on_delete=models.CASCADE,
        related_name="vinculos_secundarios",
        db_column="TicketSecundarioId",
        verbose_name="Solicitud secundaria",
    )
    tipo = models.CharField(
        "Tipo de relación",
        max_length=20,
        choices=Tipo.choices,
        default=Tipo.VINCULAR,
    )
    comentario = models.TextField("Comentario", blank=True, default="")
    creado_por = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="vinculos_creados",
        db_column="CreadoPorId",
        verbose_name="Creado por",
    )
    fecha = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "TicketVinculos"
        verbose_name = "Vínculo de solicitud"
        verbose_name_plural = "Vínculos de solicitudes"
        ordering = ["fecha"]
        unique_together = [("ticket_principal", "ticket_secundario", "tipo")]
        indexes = [
            models.Index(fields=["ticket_secundario"], name="IX_TicketVinculos_Sec"),
            models.Index(fields=["ticket_principal"], name="IX_TicketVinculos_Prin"),
        ]

    def __str__(self):
        return f"{self.ticket_secundario.codigo} bajo {self.ticket_principal.codigo} ({self.get_tipo_display()})"


class ConfigSitio(models.Model):
    """Configuración de la página editable desde el panel (pestaña "Página",
    solo administradores). Fila única (pk=1). Controla qué botones de redes
    sociales se muestran en las vistas de usuario y sus enlaces; los valores
    iniciales se toman de settings.DOGGER.
    """

    pagina_mostrar_redes = models.BooleanField(
        "Mostrar sección de redes sociales", default=True
    )
    correo_activo = models.BooleanField("Mostrar botón de correo", default=True)
    correo_soporte = models.EmailField(
        "Correo de soporte", max_length=254, blank=True, default=""
    )
    whatsapp_activo = models.BooleanField("Mostrar botón de WhatsApp", default=True)
    whatsapp_numero = models.CharField(
        "Número de WhatsApp", max_length=20, blank=True, default="3103716129"
    )
    tiktok_activo = models.BooleanField("Mostrar botón de TikTok", default=True)
    tiktok_url = models.CharField("URL de TikTok", max_length=250, blank=True, default="")
    instagram_activo = models.BooleanField("Mostrar botón de Instagram", default=True)
    instagram_url = models.CharField(
        "URL de Instagram", max_length=250, blank=True, default=""
    )
    facebook_activo = models.BooleanField("Mostrar botón de Facebook", default=True)
    facebook_url = models.CharField(
        "URL de Facebook", max_length=250, blank=True, default=""
    )
    teams_activo = models.BooleanField("Mostrar botón de Teams", default=True)
    teams_url = models.CharField(
        "URL de Teams", max_length=250, blank=True, default=""
    )
    horario_detalle = models.JSONField("Horario de atención publicado", null=True, blank=True, default=None)
    limites_inactividad = models.JSONField("Límites de inactividad en horas", default=dict, blank=True)
    escalamiento_inactividad = models.JSONField("Escalamiento de inactividad", default=dict, blank=True)
    panel_mostrar_actividad_glpi = models.BooleanField(
        "Mostrar actividad de GLPI en los paneles",
        default=False,
        help_text="Si está apagada, el bloque «Actividad reciente GLPI» no aparece en el panel de nadie.",
    )
    glpi_habilitado = models.BooleanField(
        "GLPI habilitado",
        null=True, blank=True, default=None,
        help_text="Vacío = manda el .env (GLPI_ENABLED).",
    )
    glpi_base_url = models.CharField(
        "URL base de GLPI", max_length=250, blank=True, default="",
        help_text="Vacía = manda el .env (GLPI_BASE_URL).",
    )
    glpi_app_token = CampoCifrado(
        "App token", blank=True, default="",
        help_text="Vacío = manda el .env (GLPI_APP_TOKEN). Se guarda cifrado.",
    )
    glpi_user_token = CampoCifrado(
        "User token", blank=True, default="",
        help_text="Vacío = manda el .env (GLPI_USER_TOKEN). Se guarda cifrado.",
    )
    glpi_timeout = models.PositiveIntegerField(
        "Timeout (s)", null=True, blank=True, default=None,
        help_text="Vacío = manda el .env (GLPI_TIMEOUT).",
    )
    fecha_actualizacion = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "ConfigSitio"
        verbose_name = "Configuración de la página"
        verbose_name_plural = "Configuración de la página"

    @classmethod
    def cargar(cls):
        from django.conf import settings as dj_settings
        D = dj_settings.DOGGER
        return cls.objects.get_or_create(pk=1, defaults={
            "correo_soporte": D.get("correo_soporte", ""),
            "whatsapp_numero": D.get("whatsapp_soporte", "3103716129"),
            "tiktok_url": D.get("tiktok", ""),
            "instagram_url": D.get("instagram", ""),
            "facebook_url": D.get("facebook", ""),
        })[0]

    @classmethod
    def glpi_efectivo(cls):
        """Conexión GLPI efectiva: el .env manda, el panel lo ajusta.

        Cada campo vacío en el panel deja el valor del .env
        (GLPI_ENABLED, GLPI_BASE_URL, GLPI_APP_TOKEN, GLPI_USER_TOKEN,
        GLPI_TIMEOUT). Devuelve el dict más de dónde salió cada dato.
        """
        from django.conf import settings as dj_settings

        base = dict(getattr(dj_settings, "GLPI", {}) or {})
        fuente = {k: ".env" for k in
                  ("enabled", "base_url", "app_token", "user_token", "timeout")}
        try:
            cfg = cls.objects.filter(pk=1).first()
        except Exception:  # noqa: BLE001 - sin tabla vale el .env
            cfg = None
        if cfg is not None:
            if cfg.glpi_habilitado is not None:
                base["enabled"] = bool(cfg.glpi_habilitado)
                fuente["enabled"] = "panel"
            for campo, llave in (("glpi_base_url", "base_url"),
                                 ("glpi_app_token", "app_token"),
                                 ("glpi_user_token", "user_token")):
                valor = (getattr(cfg, campo, "") or "").strip()
                if valor:
                    base[llave] = valor
                    fuente[llave] = "panel"
            if cfg.glpi_timeout:
                base["timeout"] = int(cfg.glpi_timeout)
                fuente["timeout"] = "panel"
        return {"config": base, "fuente": fuente}

    def __str__(self):
        return "Configuración de la página"


class CalificacionTecnico(models.Model):
    """Pulgar arriba o abajo de un usuario hacia un técnico.

    Hay dos alcances:

    * General (`ticket` vacío): el voto al técnico como persona, el que se
      hace desde el modal de Mi panel. Cada persona vota una sola vez a cada
      técnico, así el contador no se infla voteando muchas veces.
    * Por ticket (`ticket` puesto): la opinión sobre un ticket concreto ya
      resuelto, la que se hace desde el detalle del ticket. Una persona puede
      opinar en tickets distintos, porque cada ticket es un trabajo distinto.

    En los dos casos, volver a votar lo mismo quita el voto y cambiar de
    opinión lo reemplaza.
    """

    class Valor(models.IntegerChoices):
        ME_GUSTA = 1, "Me gusta"
        NO_ME_GUSTA = -1, "No me gusta"

    tecnico = models.ForeignKey(
        "accounts.Usuario",
        on_delete=models.CASCADE,
        related_name="calificaciones_recibidas",
        verbose_name="Técnico",
    )
    usuario = models.ForeignKey(
        "accounts.Usuario",
        on_delete=models.CASCADE,
        related_name="calificaciones_hechas",
        verbose_name="Calificado por",
    )
    ticket = models.ForeignKey(
        "tickets.Ticket",
        on_delete=models.CASCADE,
        related_name="calificaciones_tecnicos",
        null=True,
        blank=True,
        verbose_name="Ticket",
        help_text="Vacío cuando el voto es al técnico en general, no a un ticket.",
    )
    valor = models.SmallIntegerField("Voto", choices=Valor.choices)
    fecha = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "CalificacionesTecnicos"
        verbose_name = "Calificación de técnico"
        verbose_name_plural = "Calificaciones de técnicos"
        ordering = ["-fecha"]
        constraints = [
            # Una sola opinión por persona y técnico, y una sola por ticket.
            # En SQL Server (que es la base de producción) los nulos se
            # consideran iguales en un índice único, así que esta misma regla
            # también deja un solo voto general por persona y técnico.
            models.UniqueConstraint(
                fields=["tecnico", "usuario", "ticket"],
                name="uq_calificacion_tecnico_usuario_ticket",
            )
        ]

    def __str__(self):
        return f"{self.usuario} → {self.tecnico}: {self.get_valor_display()}"

    @classmethod
    def registrar(cls, tecnico, usuario, valor, ticket=None):
        """Guarda el voto: alterna entre me gusta / no me gusta / neutro.

        Con `ticket` se vota ese trabajo; sin él, al técnico en general. Los
        dos alcances no se pisan: votar el ticket no borra el voto general.
        """
        filtro = {"tecnico": tecnico, "usuario": usuario}
        if ticket is None:
            filtro["ticket__isnull"] = True
        else:
            filtro["ticket"] = ticket
        existente = cls.objects.filter(**filtro).first()
        if existente is None:
            if valor == 0:
                return 0
            return cls.objects.create(
                tecnico=tecnico, usuario=usuario, ticket=ticket, valor=valor
            ).valor
        if existente.valor == valor or valor == 0:
            existente.delete()
            return 0
        existente.valor = valor
        existente.save(update_fields=["valor", "fecha"])
        return valor

    @classmethod
    def registrar_ticket_una_vez(cls, tecnico, usuario, ticket, valor):
        """Registra la única calificación permitida para un ticket.

        A diferencia del voto general, una calificación de un trabajo no se
        alterna ni se reemplaza: el usuario deja su opinión una sola vez y el
        botón no vuelve a ofrecerse al recargar el detalle.
        """
        filtro = {"tecnico": tecnico, "usuario": usuario, "ticket": ticket}
        try:
            # La restricción única del modelo es el respaldo ante dos clics
            # concurrentes; get_or_create deja el segundo como una lectura.
            with transaction.atomic():
                voto, creado = cls.objects.get_or_create(
                    **filtro, defaults={"valor": valor}
                )
        except IntegrityError:
            # Otro POST ganó la carrera justo antes del INSERT. Su opinión es
            # la que queda y se responde de forma idempotente, no con un 500.
            voto = cls.objects.get(**filtro)
            creado = False
        return voto.valor, creado

    @classmethod
    def conteos(cls, tecnico, usuario=None, ticket=None):
        """Me gusta / no me gusta / mi voto, en el alcance pedido.

        Sin `ticket` cuenta los votos generales; con `ticket`, los de ese
        ticket. El panel del técnico (sin argumentos de usuario) suma los dos
        alcances, que es lo que la gente espera ver en su contador.
        """
        qs = cls.objects.filter(tecnico=tecnico)
        if ticket is None:
            qs = qs.filter(ticket__isnull=True)
        else:
            qs = qs.filter(ticket=ticket)
        if usuario is not None:
            qs = qs.filter(usuario=usuario)
        me_gusta = qs.filter(valor=cls.Valor.ME_GUSTA).count()
        no_me_gusta = qs.filter(valor=cls.Valor.NO_ME_GUSTA).count()
        mi_voto = 0
        if usuario is not None:
            mi_voto = qs.filter(usuario=usuario).values_list("valor", flat=True).first() or 0
        return {
            "me_gusta": me_gusta,
            "no_me_gusta": no_me_gusta,
            "total_votos": me_gusta + no_me_gusta,
            "mi_voto": mi_voto,
        }

    @classmethod
    def aprobacion_por_resueltos(cls, tecnico):
        """Barra de aprobación: votos atados a tickets ya resueltos.

        Solo cuentan los trabajos cerrados, que es lo que la persona califica
        de verdad; el voto general al técnico no se mezcla aquí para que la
        barra no se mueva con opiniones que no son de un ticket.
        """
        qs = cls.objects.filter(tecnico=tecnico, ticket__isnull=False).filter(
            Q(ticket__estado=Ticket.Estado.RESUELTO)
            | Q(ticket__estado=Ticket.Estado.CERRADO)
            | Q(ticket__fecha_resolucion__isnull=False)
        )
        me_gusta = qs.filter(valor=cls.Valor.ME_GUSTA).count()
        no_me_gusta = qs.filter(valor=cls.Valor.NO_ME_GUSTA).count()
        total = me_gusta + no_me_gusta
        resueltos = Ticket.objects.filter(tecnico_asignado=tecnico).filter(
            Q(fecha_resolucion__isnull=False)
            | Q(estado=Ticket.Estado.RESUELTO)
            | Q(estado=Ticket.Estado.CERRADO)
        ).count()
        return {
            "me_gusta": me_gusta,
            "no_me_gusta": no_me_gusta,
            "total": total,
            "porcentaje": round(me_gusta * 100 / total) if total else 0,
            "aprobacion": round(me_gusta * 100 / total) if total else 0,
            "resueltos": resueltos,
            "cobertura": min(100, round(total * 100 / resueltos)) if resueltos else None,
        }


# =====================================================================
# Módulo del observador: puntos/zones, lista personal y monitoreo
# =====================================================================
class Punto(models.Model):
    """Punto o zona física que se monitorea (sucursal, caja, piso, etc.).

    El catálogo se arma a partir de los puntos que ya existen en los tickets
    (`solicitante_punto`) y en la ubicación de los usuarios, de modo que el
    observador ve exactamente las mismas zonas que ve el resto de la mesa.
    """

    nombre = models.CharField("Punto o zona", max_length=80, unique=True)
    activo = models.BooleanField(default=True)

    class Meta:
        db_table = "Puntos"
        verbose_name = "Punto o zona"
        verbose_name_plural = "Puntos o zonas"
        ordering = ["nombre"]

    def __str__(self):
        return self.nombre

    @classmethod
    def sincronizar(cls):
        """Crea/activa los puntos que ya existen en tickets y usuarios.

        Se ignoran los vacíos y los que dicen "N/A", que es como se guarda el
        punto cuando el ticket se reporta sin ubicación.
        """
        nombres = set()
        for valores in (
            Ticket.objects.values_list("solicitante_punto", flat=True),
            cls._usuarios_puntos(),
        ):
            for bruto in valores:
                limpio = (bruto or "").strip()
                if not limpio:
                    continue
                if limpio.upper() in {"N/A", "NA", "-", "NONE"}:
                    continue
                nombres.add(limpio[:80])

        for nombre in sorted(nombres):
            cls.objects.update_or_create(nombre=nombre, defaults={"activo": True})
        return nombres

    @staticmethod
    def _usuarios_puntos():
        from django.contrib.auth import get_user_model

        return (
            get_user_model()
            .objects.values_list("ubicacion", flat=True)
            .exclude(ubicacion="")
        )


class ObservadorPunto(models.Model):
    """Un punto o zona que tiene asignada un observador concreto."""

    observador = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="puntos_asignados",
        db_column="ObservadorId",
        verbose_name="Observador",
    )
    punto = models.ForeignKey(
        Punto,
        on_delete=models.CASCADE,
        related_name="observadores",
        db_column="PuntoId",
        verbose_name="Punto o zona",
    )
    fecha_asignacion = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "ObservadorPuntos"
        verbose_name = "Punto asignado al observador"
        verbose_name_plural = "Puntos asignados a observadores"
        unique_together = [("observador", "punto")]
        ordering = ["punto__nombre"]

    def __str__(self):
        return f"{self.observador} → {self.punto}"


class ZonaObservador(models.Model):
    """Zona propia del observador para agrupar a las personas que sigue.

    No es un punto operativo (esos los asigna el administrador con
    ObservadorPunto): es una carpeta con nombre —"Sede norte", "Clientes
    VIP"— donde el observador agrupa elementos de su lista para seguirles
    los tickets y las respuestas de los técnicos.
    """

    observador = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="zonas_observador",
        db_column="ObservadorId",
        verbose_name="Observador",
    )
    nombre = models.CharField(
        "Nombre de la zona", max_length=80, db_column="Nombre"
    )
    color = models.CharField(
        "Color de la carpeta", max_length=7, blank=True, default="",
        db_column="Color",
        help_text="Color que eligió el observador para su carpeta (hex).",
    )
    creado_en = models.DateTimeField(auto_now_add=True, db_column="CreadoEn")
    version_sistema = models.CharField(
        "Versión del sistema", max_length=30, blank=True, default="",
        db_column="VersionSistema",
        help_text="Versión asociada a la zona, la define el administrador.",
    )
    notif_correo = models.BooleanField(
        "Notificaciones por correo", default=True, db_column="NotifCorreo",
    )
    notif_popup = models.BooleanField(
        "Notificaciones emergentes", default=True, db_column="NotifPopup",
    )
    sup_version = models.CharField(
        "Windows del supervisor", max_length=30, blank=True, default="",
        db_column="SupVersion",
        help_text="Windows del equipo del supervisor, se actualiza cuando actúa en la zona.",
    )
    sup_ip = models.CharField(
        "IP del supervisor", max_length=45, blank=True, default="",
        db_column="SupIp",
        help_text="IP del supervisor, se actualiza cuando actúa en la zona.",
    )
    perm_exportar = models.BooleanField(
        "Exportar auditoría", default=True, db_column="PermExportar",
    )
    perm_historial = models.BooleanField(
        "Consultar historial", default=True, db_column="PermHistorial",
    )
    alertas_ans = models.BooleanField(
        "Alertas ANS", default=False, db_column="AlertasAns",
        help_text="Resalta la zona cuando hay urgentes abiertos.",
    )

    class Meta:
        db_table = "ZonasObservador"
        verbose_name = "Zona del observador"
        verbose_name_plural = "Zonas de los observadores"
        unique_together = [("observador", "nombre")]
        ordering = ["nombre"]

    def __str__(self):
        return f"{self.observador} · {self.nombre}"


class ElementoMiLista(models.Model):
    """Elemento que el observador agregó a su panel personal.

    Puede ser una persona, un punto o ambos: al agregar un ticket se guardan
    los dos para que la ficha muestre el punto y también la persona.
    """

    TIPO_USUARIO = "usuario"
    TIPO_PUNTO = "punto"
    TIPO_CHOICES = (
        (TIPO_USUARIO, "Usuario"),
        (TIPO_PUNTO, "Punto"),
    )

    observador = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="mi_lista",
        db_column="ObservadorId",
        verbose_name="Observador",
    )
    tipo = models.CharField(
        max_length=10, choices=TIPO_CHOICES, default=TIPO_USUARIO, db_column="Tipo"
    )
    usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="+",
        db_column="UsuarioId",
        verbose_name="Usuario",
    )
    usuario_email = models.CharField(
        "Correo de la persona observada",
        max_length=150,
        blank=True,
        default="",
        db_column="UsuarioEmail",
        help_text="Se guarda aunque la persona no tenga usuario registrado.",
    )
    punto = models.ForeignKey(
        Punto,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="+",
        db_column="PuntoId",
        verbose_name="Punto o zona",
    )
    zona = models.ForeignKey(
        ZonaObservador,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="elementos",
        db_column="ZonaObservadorId",
        verbose_name="Zona del observador",
        help_text="Carpeta propia del observador para agrupar a quien sigue.",
    )
    nota = models.CharField("Nota", max_length=200, blank=True, default="", db_column="Nota")
    creado_en = models.DateTimeField(auto_now_add=True, db_column="CreadoEn")

    class Meta:
        db_table = "ElementosMiLista"
        verbose_name = "Elemento de la lista del observador"
        verbose_name_plural = "Elementos de la lista de los observadores"
        ordering = ["-creado_en", "-id"]
        constraints = [
            models.UniqueConstraint(
                fields=["observador", "usuario"],
                condition=models.Q(usuario__isnull=False),
                name="uq_milista_obs_usuario",
            ),
            models.UniqueConstraint(
                fields=["observador", "punto"],
                condition=models.Q(punto__isnull=False),
                name="uq_milista_obs_punto",
            ),
            models.UniqueConstraint(
                fields=["observador", "usuario_email"],
                condition=models.Q(usuario_email__gt=""),
                name="uq_milista_obs_email",
            ),
        ]

    def __str__(self):
        if self.usuario_id and self.punto_id:
            return f"{self.observador} → {self.usuario} @ {self.punto}"
        return f"{self.observador} → {self.usuario or self.punto}"


class MonitoreoAuditoria(models.Model):
    """Registro de cambios del monitoreo corporativo.

    Cada vez que el administrador (o el propio supervisor) crea, renombra
    o elimina una zona, o mete/saca cuentas y puntos, queda aquí quién lo
    hizo, sobre qué supervisor/zona y cuándo. Es lo que alimenta el
    registro visible del tablero del administrador.
    """

    CREAR_ZONA = "crear_zona"
    RENOMBRAR_ZONA = "renombrar_zona"
    ELIMINAR_ZONA = "eliminar_zona"
    AGREGAR_MIEMBRO = "agregar_miembro"
    QUITAR_MIEMBRO = "quitar_miembro"
    ASIGNAR_PUNTO = "asignar_punto"
    QUITAR_PUNTO = "quitar_punto"
    AGREGAR_LISTA = "agregar_lista"
    QUITAR_LISTA = "quitar_lista"
    ALERTAS_ANS = "alertas_ans"
    ACCION_CHOICES = (
        (CREAR_ZONA, "Zona creada"),
        (RENOMBRAR_ZONA, "Zona renombrada"),
        (ELIMINAR_ZONA, "Zona eliminada"),
        (AGREGAR_MIEMBRO, "Cuenta agregada a zona"),
        (QUITAR_MIEMBRO, "Cuenta sacada de zona"),
        (ASIGNAR_PUNTO, "Punto asignado"),
        (QUITAR_PUNTO, "Punto quitado"),
        (AGREGAR_LISTA, "Cuenta agregada a la lista"),
        (QUITAR_LISTA, "Cuenta sacada de la lista"),
        (ALERTAS_ANS, "Alertas ANS"),
    )

    actor = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="+",
        db_column="ActorId",
        verbose_name="Quién lo hizo",
    )
    observador = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="+",
        db_column="ObservadorId",
        verbose_name="Supervisor afectado",
    )
    zona_nombre = models.CharField(
        "Zona", max_length=80, blank=True, default="", db_column="Zona"
    )
    accion = models.CharField(
        "Acción", max_length=20, choices=ACCION_CHOICES, db_column="Accion"
    )
    detalle = models.CharField(
        "Detalle", max_length=200, blank=True, default="", db_column="Detalle"
    )
    cuenta = models.CharField(
        "Cuenta afectada", max_length=150, blank=True, default="",
        db_column="Cuenta",
        help_text="Correo o nombre involucrado, cuando aplica.",
    )
    ip_origen = models.CharField(
        "IP de origen", max_length=45, blank=True, default="",
        db_column="IpOrigen",
    )
    resultado = models.CharField(
        "Resultado", max_length=10, blank=True, default="exito",
        db_column="Resultado",
        help_text="exito, error o pendiente.",
    )
    motivo = models.CharField(
        "Motivo", max_length=200, blank=True, default="",
        db_column="Motivo",
    )
    version_sistema = models.CharField(
        "Versión", max_length=30, blank=True, default="",
        db_column="VersionSistema",
    )
    comentarios = models.TextField(
        "Comentarios", blank=True, default="",
        db_column="Comentarios",
    )
    fecha = models.DateTimeField(auto_now_add=True, db_column="Fecha")

    class Meta:
        db_table = "MonitoreoAuditoria"
        verbose_name = "Auditoría de monitoreo"
        verbose_name_plural = "Auditoría de monitoreo"
        ordering = ["-fecha", "-id"]

    def __str__(self):
        return f"{self.get_accion_display()} · {self.zona_nombre}"

    @property
    def clase_accion(self):
        """Color del badge según lo que pasó: suma, resta o ajuste."""
        if self.accion in (self.CREAR_ZONA, self.AGREGAR_MIEMBRO,
                           self.AGREGAR_LISTA, self.ASIGNAR_PUNTO):
            return "ok"
        if self.accion in (self.ELIMINAR_ZONA, self.QUITAR_MIEMBRO,
                           self.QUITAR_LISTA, self.QUITAR_PUNTO):
            return "no"
        return "info"


class PerfilAutoasignacion(models.Model):
    tecnico = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="perfil_autoasignacion")
    habilitado = models.BooleanField(default=False)
    cobertura_general = models.BooleanField(default=False, help_text="Permite atender cualquier punto; desactivar para limitar a los puntos seleccionados.")
    capacidad = models.PositiveIntegerField(default=1)
    orden_rotacion = models.PositiveBigIntegerField(default=0)
    categorias = models.ManyToManyField(Categoria, blank=True, related_name="perfiles_autoasignacion")
    puntos_cobertura = models.ManyToManyField(Punto, blank=True, related_name="perfiles_autoasignacion")
    cuentas_cobertura = models.ManyToManyField(settings.AUTH_USER_MODEL, blank=True, related_name="perfiles_cobertura_autoasignacion")

    class Meta:
        constraints = [models.CheckConstraint(condition=Q(capacidad__gt=0), name="autoasig_capacidad_positiva")]


class DecisionAutoasignacion(models.Model):
    ticket = models.ForeignKey(Ticket, on_delete=models.PROTECT, related_name="decisiones_autoasignacion")
    tecnico = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True, blank=True)
    fecha = models.DateTimeField(default=timezone.now)
    motivo = models.CharField(max_length=60)
    carga = models.PositiveIntegerField(null=True, blank=True)
    capacidad = models.PositiveIntegerField(null=True, blank=True)
    prioridad = models.CharField(max_length=20)
    categoria_nombre = models.CharField(max_length=160, blank=True, default="")

    class Meta:
        ordering = ["-fecha", "-pk"]
