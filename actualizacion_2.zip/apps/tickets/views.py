import json
import secrets
import string
from collections import Counter
from datetime import date, datetime, timedelta
from types import SimpleNamespace
import logging
import re

from django.contrib import messages
from django.contrib.auth import get_user_model, login as auth_login
from django.core.exceptions import PermissionDenied, ValidationError
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required
from django.db import IntegrityError, transaction
from django.db.models import CharField, Count, F, Min, Prefetch, Q, Value
from django.http import FileResponse, Http404, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render, reverse
from django.template.loader import render_to_string
from django.utils import timezone
from django.utils.http import url_has_allowed_host_and_scheme
from django.utils.dateformat import DateFormat
from django.views.decorators.http import require_POST

PRESETS_MIS = [
    ("pendientes", "Solicitudes pendientes"),
    ("abiertas", "Mis solicitudes abiertas"),
    ("todas", "Todas las solicitudes"),
    ("completadas", "Mis solicitudes completadas"),
    ("espera", "Mis solicitudes en espera"),
    ("no-asignadas", "Solicitudes no asignadas"),
    ("vencen-hoy", "Solicitudes que vencen hoy"),
    ("vencidas", "Solicitudes vencidas"),
    ("creadas-hoy", "Solicitudes creadas hoy"),
]
RANGOS_MIS = [
    ("7", "Últimos 7 días"),
    ("15", "Últimos 15 días"),
    ("30", "Los 30 últimos días"),
    ("60", "Últimos 60 días"),
    ("90", "Últimos 90 días"),
    ("180", "Últimos 180 días"),
    ("365", "Últimos 365 días"),
    ("", "Todo el tiempo"),
]

from apps.accounts.models import Usuario
from apps.accounts.routing import landing_por_rol
from .decorators import (
    admin_required,
    sin_observador,
    staff_required,
    user_required,
)
from .exports import generar_excel_reportes, generar_excel_tickets
from .forms import (
    AsignarTecnicoForm,
    CategoriaForm,
    CategoriaGrupoForm,
    ComentarioForm,
    ConsultaTicketForm,
    TicketEdicionForm,
    TicketForm,
    UsuarioPanelForm,
)
from .context_processors import _tipos_por_revisar
from .services.motor_ans import calcular_ans, evaluar_lote
from .services.autoasignacion_transaccional import asignar_manual, coordinacion_asignacion, escritura_coordinada
from .models import (
    Categoria,
    CategoriaGrupo,
    ElementoMiLista,
    GlpiEvento,
    Ticket,
    TicketAdjunto,
    TicketComentario,
    TicketVinculo,
    ZonaObservador,
)
from .notifications import notificar_comentario, notificar_ticket_actualizado, notificar_ticket_creado
from .sla import formatear_duracion, horas_por_prioridad, orden_prioridad_annotation
from .services.glpi_client import (
    GlpiClient,
    GlpiError,
    configuracion_efectiva as configuracion_glpi,
    esta_activo as esta_activo_glpi,
    sync_adjuntos_to_glpi,
    sync_asignacion_to_glpi,
    sync_edicion_to_glpi,
    sync_estado_to_glpi,
    sync_followup_to_glpi,
    sync_ticket_to_glpi,
)
from .sugerencia_categoria import claves_para_json, que_cubre, que_cubre_grupo
from .services.tecnicos import mapeados_del_tecnico, puede_calificar


# Opciones del selector "Filas". El 6 es el predeterminado en todas las vistas.
PER_PAGE_OPCIONES = {6, 5, 9, 10, 20, 50, 0}
PER_PAGE_DEFECTO = 6

logger = logging.getLogger(__name__)
User = get_user_model()

COLORES_ESTADO = {
    "abierto": "#D62B1F",
    "en-progreso": "#F2A900",
    "resuelto": "#2F7D4F",
    "cerrado": "#6B6259",
}
COLORES_PRIORIDAD = {
    "urgente": "#D62B1F",
    "alta": "#F26522",
    "media": "#F2A900",
    "baja": "#6B9E78",
}


def _cargas_activas(usuarios_ids):
    """Carga de trabajo por técnico: tickets abiertos o en progreso asignados."""
    filas = (
        Ticket.objects.filter(
            tecnico_asignado_id__in=list(usuarios_ids),
            estado__in=(Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO),
        )
        .values("tecnico_asignado_id")
        .annotate(carga=Count("id"))
    )
    return {r["tecnico_asignado_id"]: r["carga"] for r in filas}


def _tecnicos_disponibles_para_formulario():
    """Vista previa de disponibilidad para quien crea un ticket.

    La asignación definitiva se recalcula al guardar; esta lista solo explica
    quiénes están disponibles con la carga que existe en este momento.
    """
    tecnicos = list(
        User.objects.filter(
            activo=True,
            is_active=True,
            rol__in=(User.Rol.TECNICO, User.Rol.ADMIN),
        ).order_by("pk")
    )
    cargas = _cargas_activas([tecnico.pk for tecnico in tecnicos])
    return [
        {
            "id": tecnico.pk,
            "nombre": tecnico.nombre or tecnico.email,
            "iniciales": tecnico.iniciales,
            "avatar": _avatar_url_simple(tecnico),
            "carga": cargas.get(tecnico.pk, 0),
        }
        for tecnico in sorted(tecnicos, key=lambda tecnico: (cargas.get(tecnico.pk, 0), tecnico.pk))
    ]


def _auto_asignar_tecnico(ticket) -> bool:
    """Invoca el único motor sobre el ticket ya guardado, sin alterar asignaciones manuales."""
    if ticket.tecnico_asignado_id or not ticket.categoria_id:
        return False
    from .services.autoasignacion_transaccional import asignar_ticket

    try:
        decision = asignar_ticket(ticket.pk, using=ticket._state.db or "default")
    except Exception:
        # La creación local no debe perderse por un fallo de autoasignación.
        logger.exception("No se pudo autoasignar el ticket %s", ticket.pk)
        return False
    if decision and decision.candidato:
        ticket.refresh_from_db(fields=["tecnico_asignado", "asignacion_automatica"])
        return True
    return False


@require_POST
def descartar_ticket_aviso(request):
    """El usuario cerró la ventana de 'Ticket creado': limpiar el aviso de sesión."""
    request.session.pop("ticket_creado_info", None)
    return JsonResponse({"ok": True})


def _sincronizar_ticket_nuevo(request, ticket, files):
    """
    Sincroniza un ticket recién creado hacia GLPI y sube sus adjuntos.
    Informa al usuario el resultado sin bloquear el flujo local.
    """
    try:
        glpi_id = sync_ticket_to_glpi(ticket)
    except GlpiError as exc:
        messages.warning(
            request,
            f"El ticket {ticket.codigo} quedó guardado, pero no se pudo registrar "
            f"en GLPI: {exc}. Se reintentará con 'sync_glpi_pendientes'.",
        )
        return
    if not glpi_id:
        return

    messages.info(request, f"También registrado en GLPI #{glpi_id}")
    if files:
        try:
            n = sync_adjuntos_to_glpi(ticket)
            if n:
                messages.info(request, f"{n} adjunto(s) subido(s) a GLPI.")
        except GlpiError as exc:
            messages.warning(request, f"No se pudieron subir los adjuntos a GLPI: {exc}")


def _build_chart_context(tickets):
    """Gráficas y ANS a partir de una iterable de tickets (sin eventos GLPI)."""
    pri_counts = Counter(t.prioridad for t in tickets)
    total = max(len(tickets), 1)
    priority_labels = ("urgente", "alta", "media", "baja")
    max_priority_count = max((pri_counts.get(k, 0) for k in priority_labels), default=0)
    priority_bars = [
        {
            "label": k,
            "count": pri_counts.get(k, 0),
            "pct": round(pri_counts.get(k, 0) / total * 100),
            "fill_pct": 0 if max_priority_count == 0 else round((pri_counts.get(k, 0) / max_priority_count) * 100),
            "color": COLORES_PRIORIDAD.get(k, "#F2A900"),
        }
        for k in priority_labels
    ]
    cat_counts = Counter(
        (t.categoria.nombre if t.categoria else "Sin categoria") for t in tickets
    )
    max_category_count = max(cat_counts.values(), default=0)
    category_bars = [
        {
            "label": k,
            "count": v,
            "pct": round(v / total * 100),
            "fill_pct": 0 if max_category_count == 0 else round((v / max_category_count) * 100),
        }
        for k, v in cat_counts.most_common(8)
    ]

    estado_labels = ("abierto", "en-progreso", "resuelto", "cerrado")
    estado_display = dict(Ticket.Estado.choices)
    estado_counts = Counter(t.estado for t in tickets)
    total_estados = max(sum(estado_counts.values()), 1)
    max_estado_count = max((estado_counts.get(k, 0) for k in estado_labels), default=0)
    estado_bars = [
        {
            "label": estado_display.get(k, k),
            "slug": k,
            "count": estado_counts.get(k, 0),
            "pct": round(estado_counts.get(k, 0) / total_estados * 100),
            "fill_pct": 0 if max_estado_count == 0 else round((estado_counts.get(k, 0) / max_estado_count) * 100),
            "color": COLORES_ESTADO.get(k, "#6B6259"),
        }
        for k in estado_labels
    ]
    donut_segments = [
        {"v": estado_counts.get(k, 0), "c": COLORES_ESTADO.get(k, "#6B6259")}
        for k in estado_labels
        if estado_counts.get(k, 0) > 0
    ]

    tecnico_counts = Counter(
        (t.tecnico_asignado.nombre if t.tecnico_asignado else "Sin asignar") for t in tickets
    )
    max_tecnico_count = max(tecnico_counts.values(), default=0)
    tecnico_bars = [
        {
            "label": k,
            "count": v,
            "fill_pct": 0 if max_tecnico_count == 0 else round(v / max_tecnico_count * 100),
        }
        for k, v in tecnico_counts.most_common(8)
    ]

    # Tickets por solicitante (para gráfico de usuarios)
    user_counts = Counter(
        (t.solicitante_nombre or t.solicitante_email or "Anónimo") for t in tickets
    )
    max_user_count = max(user_counts.values(), default=0)
    user_bars = [
        {
            "label": k,
            "count": v,
            "fill_pct": 0 if max_user_count == 0 else round((v / max_user_count) * 100),
        }
        for k, v in user_counts.most_common(10)
    ]

    # Cumplimiento ANS entre los tickets abiertos/en progreso
    resultados_ans = evaluar_lote(tickets, permitir_provisional=True)
    ans_vencidos = ans_por_vencer = ans_ok = 0
    for t in tickets:
        estado = resultados_ans[t.pk].estado
        if estado == "vencido":
            ans_vencidos += 1
        elif estado == "por_vencer":
            ans_por_vencer += 1
        elif estado == "vigente":
            ans_ok += 1
    ans_total = max(ans_vencidos + ans_por_vencer + ans_ok, 1)
    ans_stats = {
        "vencidos": ans_vencidos,
        "por_vencer": ans_por_vencer,
        "ok": ans_ok,
        "pct_ok": round(ans_ok / ans_total * 100),
        "bar_vencidos": round(ans_vencidos / ans_total * 100),
        "bar_por_vencer": round(ans_por_vencer / ans_total * 100),
        "bar_ok": round(ans_ok / ans_total * 100),
    }

    return {
        "priority_bars": priority_bars,
        "category_bars": category_bars,
        "estado_bars": estado_bars,
        "tecnico_bars": tecnico_bars,
        "user_bars": user_bars,
        "ans_stats": ans_stats,
        "donut_segments": json.dumps(donut_segments),
    }


# ---------------------------------------------------------------------------
# Dashboard global del Panel Técnico (6 widgets)
# ---------------------------------------------------------------------------

COLORES_MODO = {
    "web": "#2A6FDB",
    "email": "#2F7D4F",
    "telefono": "#B7791F",
    "no-asignado": "#8A8A86",
}

COLORES_SERIE = {
    "entrante": "#2563EB",
    "completado": "#2F7D4F",
    "vencido": "#D62B1F",
    "riesgo": "#F2A900",
}

_LABEL_MODO = {
    "web": "Web Form",
    "email": "E-Mail",
    "telefono": "Phone Call",
}


_DIAS_SEMANA = ("Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom")

# --- Ámbitos de los desplegables de las tarjetas --------------------------
# Son la fuente única: los usan el JSON del dashboard, el HTML y el JS.
# Las etiquetas van en femenino porque lo que se cuenta son "solicitudes".
# (clave, etiqueta, estados que agrupa; "todas" y "eliminados" se tratan
#  aparte porque no son simplemente un estado).
_ALCANCES_TORTAS = (
    ("abiertas", "Abiertas", (Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO)),
    ("en_progreso", "En progreso", (Ticket.Estado.EN_PROGRESO,)),
    # "Resueltas" junta lo ya terminado: resueltas y cerradas.
    # "Resueltas" ya no es un estado guardado sino la marca de resolución,
    # así que no agrupa estados: se resuelve aparte en `_filtrar_estado`.
    ("resueltos", "Resueltas", ()),
    ("cerrados", "Cerradas", (Ticket.Estado.CERRADO,)),
    ("eliminados", "Eliminadas", ()),
    ("todas", "Todas", ()),
)

# El comparativo de 20 días añade "recibidas"/"completadas" a los mismos
# ámbitos.
_ALCANCES_20_DIAS = (
    ("recibidas", "Recibidas"),
    ("completadas", "Completadas"),
) + tuple((k, e) for k, e, _ in _ALCANCES_TORTAS)


def _serie_dias(inicio, fin, con_dia=False):
    """Lista de etiquetas por día entre dos fechas (día de semana + día o d/m)."""
    dias = []
    for i in range((fin - inicio).days + 1):
        d = inicio + timedelta(days=i)
        if con_dia:
            dias.append(f"{d.day}/{d.month:02d}")
        else:
            dias.append(f"{_DIAS_SEMANA[d.weekday()]} {d.day}")
    return dias


def _agrupar_vencidos(tickets, dimension):
    """Cuenta tickets por dimensión según estado ANS (vencido / por vencer).

    Cada vencimiento se trata como una SANCIÓN: vencidos es el número de
    infracciones y riesgo las advertencias por vencerse pronto.

    Los tickets ya resueltos/cerrados también cuentan como sanción si se
    tardaron más de `ans_horas` en resolverse. Antes solo se miraban los
    abiertos, así que un técnico que ya resolvió todo tenía la gráfica
    vacía aunque hubiera incumplido el ANS (y en contra de lo que sí cuenta
    el comparativo de 20 días, que mira `fecha_cierre`).
    """
    tickets = list(tickets)
    guardados = [ticket for ticket in tickets if not ticket._state.adding]
    ahora = timezone.now()
    resultados = evaluar_lote(guardados, ahora=ahora, permitir_provisional=True) if guardados else {}
    agg = {}
    for t in tickets:
        clave, label = dimension(t)
        resultado = resultados[t.pk] if not t._state.adding else calcular_ans(t, ahora=ahora, permitir_provisional=True)
        if t.estado in (Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO):
            estado_ans = resultado.estado
            if estado_ans not in ("vencido", "por_vencer"):
                continue
            if clave not in agg:
                agg[clave] = {"label": label, "vencidos": 0, "riesgo": 0}
            # "por-vencer" es advertencia (riesgo), "vencido" es infracción.
            # Antes se escribía en las claves equivocadas ("por-vencer" y
            # "riesgo"), así que el JS leía `vencidos` como undefined y la
            # gráfica salía en blanco.
            agg[clave]["riesgo" if estado_ans == "por_vencer" else "vencidos"] += 1
        elif t.estado in (Ticket.Estado.RESUELTO, Ticket.Estado.CERRADO):
            if resultado.estado != "incumplido":
                continue  # resolvió dentro del ANS
            if clave not in agg:
                agg[clave] = {"label": label, "vencidos": 0, "riesgo": 0}
            agg[clave]["vencidos"] += 1
    return [v for v in agg.values()]


def _build_tecnico_dashboard(
    tecnico_id=None, consulta=None, incluir_pivot=True, puntos_pivot=None,
    incluir_detalle_pivot=True,
):
    """
    Datos JSON para el rediseño del Panel Técnico.

    Incluye: tabla dinámica pivote, gráficos modales (modo/prioridad, con
    cambio de tipo), serie de solicitudes por rango, SLA por dimensión y
    comparativos de los últimos 20 días.

    Si se indica un técnico, el dashboard se limita a SUS solicitudes. Si
    se pasa `consulta`, el tablero se acota a los tickets de esa mirada —la
    del observador, que solo ve sus puntos— y la papelera sale vacía: los
    tickets eliminados ya no son de nadie.
    """
    if consulta is not None:
        qs = consulta.select_related("categoria", "tecnico_asignado")
    else:
        qs = Ticket.objects.select_related("categoria", "tecnico_asignado")
        if tecnico_id:
            qs = qs.filter(tecnico_asignado_id=tecnico_id)
    tickets = list(qs.order_by("fecha_creacion"))
    # Los tickets de la papelera se cargan aparte: siguen fuera de todos los
    # KPI (pivote, línea, SLA, contadores) y solo aparecen si el usuario pide
    # expresamente el ámbito "Eliminados" o "Todas".
    if consulta is not None:
        papelera = []
    else:
        qs_pap = Ticket.con_eliminados.filter(eliminado_en__isnull=False)
        if tecnico_id:
            qs_pap = qs_pap.filter(tecnico_asignado_id=tecnico_id)
        papelera = list(qs_pap.order_by("fecha_creacion"))
    tickets_abiertas = tickets + papelera
    estados_ans = evaluar_lote(tickets_abiertas, permitir_provisional=True)
    abiertos = [
        t
        for t in tickets
        if t.estado in (Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO)
    ]
    hoy = timezone.now().date()

    def _por_alcance(alcance, base=None, con_papelera=True):
        """Tickets del ámbito pedido (abiertas, en progreso, ..., eliminados, todas)."""
        base = tickets if base is None else base
        if alcance == "eliminados":
            return list(papelera)
        if alcance == "todas":
            return base + list(papelera) if con_papelera else base
        if alcance == "resueltos":
            # Resuelto ya no es un estado guardado: se busca la marca.
            return [t for t in base if t.fecha_resolucion or t.estado == Ticket.Estado.RESUELTO]
        estados = dict((k, e) for k, _, e in _ALCANCES_TORTAS)[alcance]
        return [t for t in base if t.estado in estados]

    # --- Tabla dinámica pivote -------------------------------------------
    def _pivot(
        dimension, sort_key=None, limite=40, base=None, semillas=None,
        incluir_detalle=None,
    ):
        if incluir_detalle is None:
            incluir_detalle = incluir_detalle_pivot
        rows = {}

        def _fila(clave, label):
            return {
                "clave": clave, "label": label, "abrir": 0, "espera": 0,
                "vencido": 0, "riesgo": 0, "cerrado": 0, "resueltos": 0,
                "total": 0, "categorias": [], "_cats": set(), "tickets": [],
            }

        for clave, label in semillas or ():
            rows[clave] = _fila(clave, label)
        for t in tickets if base is None else base:
            clave, label = dimension(t)
            fila = rows.setdefault(clave, _fila(clave, label))
            fila["total"] += 1
            if t.estado == Ticket.Estado.ABIERTO:
                fila["abrir"] += 1
            elif t.estado == Ticket.Estado.EN_PROGRESO:
                fila["espera"] += 1
            elif t.estado == Ticket.Estado.CERRADO:
                fila["cerrado"] += 1
            # "Resuelta" no es el estado actual de una solicitud nueva:
            # al resolverla se guarda como cerrada y se conserva esta marca.
            # Las columnas son dimensiones distintas, por lo que una misma
            # solicitud puede ser Cerrada y Resuelta a la vez.
            if t.fue_resuelto:
                fila["resueltos"] += 1
            ans = estados_ans[t.pk].estado
            # El pivote resumido por punto no incluye filas de detalle, pero
            # sí tiene que contar el ANS vencido y por vencer.
            if t.estado in (Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO):
                if ans == "vencido":
                    fila["vencido"] += 1
                elif ans == "por_vencer":
                    fila["riesgo"] += 1
            if incluir_detalle and t.estado in (Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO):
                cat = "Sin categoría"
                if t.categoria_id:
                    cat = f"{t.categoria.grupo or ''} › {t.categoria.nombre or ''}".strip(" ›") or "Sin categoría"
                if cat not in fila["_cats"] and len(fila["_cats"]) < 8:
                    fila["_cats"].add(cat)
            if incluir_detalle and len(fila["tickets"]) < limite:
                fila["tickets"].append(
                    {
                        "id": t.pk,
                        "codigo": t.codigo,
                        "titulo": t.titulo,
                        "estado": t.estado,
                        "resuelto": t.fue_resuelto,
                        "vencido": ans == "vencido"
                        and t.estado in (Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO),
                    }
                )
        lista = list(rows.values())
        for r in lista:
            r["categorias"] = sorted(r.pop("_cats"))
            r["tickets"] = sorted(r["tickets"], key=lambda x: -x["id"])
        if sort_key:
            lista.sort(key=sort_key)
        return lista

    def dim_tecnico(t):
        if t.tecnico_asignado_id:
            return (t.tecnico_asignado_id, t.tecnico_asignado.nombre)
        return ("__sin", "No asignado")

    def dim_prioridad(t):
        return (t.prioridad, t.get_prioridad_display())

    def dim_modo(t):
        modo = "no-asignado"
        if t.modo in _LABEL_MODO:
            modo = t.modo
        return (modo, _LABEL_MODO.get(modo, "No asignado"))

    def dim_grupo(t):
        if t.categoria_id:
            return (t.categoria.grupo, t.categoria.grupo)
        return ("__sin", "Sin categoría")

    def dim_categoria(t):
        if t.categoria_id:
            grupo = t.categoria.grupo or ""
            nombre = t.categoria.nombre or ""
            return (t.categoria_id, f"{grupo} › {nombre}".strip(" ›"))
        return ("__sin", "Sin categoría")

    def dim_punto(t):
        nombre = (t.solicitante_punto or "").strip()
        return (nombre.casefold(), nombre or "Sin punto")

    # El pivote de puntos debe salir del mismo conjunto que alimenta el
    # tablero. Antes hacía una consulta nueva a Ticket por nombre de punto;
    # eso podía sumar casos de otra vista/zona y ya no cuadraba con los KPI.
    # Normalizamos solo para emparejar mayúsculas y espacios, sin ampliar el
    # alcance que ya decidió `consulta`.
    puntos_pivot = [
        nombre.strip() for nombre in (puntos_pivot or ()) if nombre and nombre.strip()
    ]
    if not puntos_pivot:
        puntos_pivot = sorted(
            {
                (t.solicitante_punto or "").strip()
                for t in tickets
                if (t.solicitante_punto or "").strip()
            },
            key=str.casefold,
        )
    puntos_clave = {nombre.casefold() for nombre in puntos_pivot}
    puntos_tickets = [
        t for t in tickets
        if (t.solicitante_punto or "").strip().casefold() in puntos_clave
    ]

    pivot = {
        "dimensiones": {
            "tecnico": {
                "label": "Técnico",
                "rows": sorted(_pivot(dim_tecnico), key=lambda r: r["label"].lower()),
            },            "prioridad": {
                "label": "Prioridad",
                "rows": sorted(
                    _pivot(dim_prioridad),
                    key=lambda r: ("urgente", "alta", "media", "baja").index(r["label"].lower())
                    if r["label"].lower() in ("urgente", "alta", "media", "baja")
                    else 99,
                ),
            },
            "modo": {
                "label": "Modo de ingreso",
                "rows": sorted(
                    _pivot(dim_modo),
                    key=lambda r: ("web form", "e-mail", "phone call", "no asignado").index(r["label"].lower())
                    if r["label"].lower() in ("web form", "e-mail", "phone call", "no asignado")
                    else 99,
                ),
            },
            "grupo": {
                "label": "Grupo",
                "rows": _pivot(dim_grupo, sort_key=lambda r: r["label"].lower()),
            },
            "categoria": {
                "label": "Categoría",
                "rows": _pivot(dim_categoria, sort_key=lambda r: r["label"].lower()),
            },
            "punto": {
                "label": "Punto de venta",
                "aggregate_only": True,
                "rows": _pivot(
                    dim_punto,
                    sort_key=lambda r: r["label"].casefold(),
                    base=puntos_tickets,
                    semillas=[(nombre.casefold(), nombre) for nombre in puntos_pivot],
                    incluir_detalle=False,
                ),
            },
        },
        "columnas": ["abrir", "espera", "vencido", "cerrado", "resueltos"],
    }
    # Foto de cada técnico para sus tarjetas (vacía = inicial con icono).
    try:
        ids_tec = [
            r["clave"] for r in pivot["dimensiones"]["tecnico"]["rows"]
            if str(r.get("clave", "")).isdigit()
        ]
        fotos = {}
        for u in User.objects.filter(pk__in=ids_tec):
            try:
                fotos[u.pk] = u.avatar.url if u.avatar else ""
            except Exception:  # noqa: BLE001 - sin foto no se rompe el panel
                fotos[u.pk] = ""
        for r in pivot["dimensiones"]["tecnico"]["rows"]:
            r["foto"] = fotos.get(r["clave"], "")
    except Exception:  # noqa: BLE001 - sin fotos igual hay tarjetas
        pass

    # --- Pie: modo / prioridad (solo abiertos) ---------------------------
    def _pie(acc, colores, etiquetas):
        return [
            {"label": etiquetas.get(k, k), "value": v, "color": colores.get(k, "#8A8A86")}
            for k, v in acc.items()
            if v > 0
        ]

    etiquetas_modo = dict(_LABEL_MODO, **{"no-asignado": "No asignado"})
    modo_counts = Counter(dim_modo(t)[0] for t in abiertos)
    pie_modo = _pie(  # orden fijo: web, email, telefono, no asignado
        {k: modo_counts.get(k, 0) for k in ("web", "email", "telefono", "no-asignado")},
        COLORES_MODO,
        etiquetas_modo,
    )
    etiquetas_prioridad = dict(Ticket.Prioridad.choices)

    # --- Pie: categoría y prioridad, una serie por cada ámbito ------------
    _PAL_CAT = ["#2563EB", "#2F7D4F", "#F2A900", "#B7791F", "#8A8A86", "#6B6259", "#D62B1F", "#7C4DFF"]

    def _pie_categoria(lista):
        acc = {}
        for t in lista:
            cid, clabel = dim_categoria(t)
            fila = acc.setdefault(cid, {"label": clabel, "n": 0})
            fila["n"] += 1
        items = sorted(acc.values(), key=lambda r: (-r["n"], r["label"].lower()))
        return [
            {"label": it["label"], "value": it["n"], "color": _PAL_CAT[i % len(_PAL_CAT)]}
            for i, it in enumerate(items)
        ]

    def _pie_prioridad(lista):
        prio = Counter(t.prioridad for t in lista)
        return _pie(  # orden fijo: urgente, alta, media, baja
            {k: prio.get(k, 0) for k in ("urgente", "alta", "media", "baja")},
            COLORES_PRIORIDAD,
            etiquetas_prioridad,
        )

    # Un diccionario por ámbito: {abiertas: [...], en_progreso: [...], ...}.
    # Así el desplegable del HTML no hace falta ir a pedir nada: el JS solo
    # cambia de clave, y un técnico con todo resuelto ve datos igual.
    pie_prioridad_por_alcance = {
        clave: _pie_prioridad(_por_alcance(clave)) for clave, _, _ in _ALCANCES_TORTAS
    }
    pie_categoria_por_alcance = {
        clave: _pie_categoria(_por_alcance(clave)) for clave, _, _ in _ALCANCES_TORTAS
    }

    # --- Serie de solicitudes por rango ----------------------------------
    def _rango(rango):
        if rango == "ultima_semana":
            inicio, fin = hoy - timedelta(days=6), hoy
        elif rango == "30_dias":
            inicio, fin = hoy - timedelta(days=29), hoy
        elif rango == "90_dias":
            inicio, fin = hoy - timedelta(days=89), hoy
        elif rango == "esta_semana":
            inicio, fin = hoy - timedelta(days=hoy.weekday()), hoy
        elif rango == "este_mes":
            inicio, fin = hoy.replace(day=1), hoy
        else:  # ultimo_mes
            fin = hoy.replace(day=1) - timedelta(days=1)
            inicio = fin.replace(day=1)

        con_dia = rango in ("este_mes", "ultimo_mes", "30_dias", "90_dias")
        etiquetas = _serie_dias(inicio, fin, con_dia=con_dia)

        dias = {}
        d = inicio
        while d <= fin:
            dias[d] = {"entrante": 0, "completado": 0, "vencido": 0}
            d += timedelta(days=1)

        for t in tickets:
            d = _key_fecha(t.fecha_creacion)
            if d in dias:
                dias[d]["entrante"] += 1
            if t.estado in (Ticket.Estado.RESUELTO, Ticket.Estado.CERRADO) and t.fecha_cierre:
                dc = _key_fecha(t.fecha_cierre)
                if dc in dias:
                    dias[dc]["completado"] += 1
            if d in dias and estados_ans[t.pk].estado == "vencido":
                dias[d]["vencido"] += 1

        ordenadas = sorted(dias)
        return {
            "labels": etiquetas,
            "entrante": [dias[k]["entrante"] for k in ordenadas],
            "completado": [dias[k]["completado"] for k in ordenadas],
            "vencido": [dias[k]["vencido"] for k in ordenadas],
        }

    linea = {
        k: _rango(k)
        for k in ("ultima_semana", "30_dias", "90_dias", "esta_semana", "este_mes", "ultimo_mes")
    }

    # --- SLA por dimensión ------------------------------------------------
    sla = {
        "por_tecnico": _agrupar_vencidos(tickets, dim_tecnico),
        "por_prioridad": _agrupar_vencidos(tickets, dim_prioridad),
        "por_categoria": _agrupar_vencidos(tickets, dim_categoria),
        "por_grupo": _agrupar_vencidos(tickets, dim_grupo),
    }

    # --- Comparativos últimos 20 días -------------------------------------
    def _comparativo(fecha_t):  # recibe lista (t, flag brecha)
        inicio = hoy - timedelta(days=19)
        etiquetas = []
        ok, brecha = [], []
        for i in range(20):
            d = inicio + timedelta(days=i)
            etiquetas.append(DateFormat(d).format("d/m"))
            ok.append(0)
            brecha.append(0)
        for d, es_brecha in fecha_t:
            if inicio <= d <= hoy:
                i = (d - inicio).days
                (brecha if es_brecha else ok)[i] += 1
        return {"labels": etiquetas, "ok": ok, "brecha": brecha}

    def _brecha_abierta(t):
        """Un ticket abierto cuenta como brecha si ya venció su ANS."""
        return estados_ans[t.pk].estado == "vencido"

    def _brecha_cerrada(t):
        """Resuelto/cerrado: breach si tardó más de `ans_horas`."""
        resultado = estados_ans[t.pk]
        return None if resultado.estado == "sin_informacion" else resultado.estado == "incumplido"

    recibidas = []
    for t in tickets:
        if t.fecha_creacion:
            recibidas.append((_key_fecha(t.fecha_creacion), estados_ans[t.pk].estado == "vencido"))

    completadas = []
    for t in tickets:
        if t.estado in (Ticket.Estado.RESUELTO, Ticket.Estado.CERRADO) and t.fecha_cierre:
            brecha = _brecha_cerrada(t)
            if brecha is not None:
                completadas.append((_key_fecha(t.fecha_cierre), brecha))

    # Un ámbito por estado. La fecha que manda es "cuándo pasó a ese estado":
    #   - abiertas / en progreso  -> día de creación (siguen sin cerrar)
    #   - resueltos / cerrados    -> día de cierre
    #   - eliminados              -> día en que se mandaron a la papelera
    # En "todas" cada ticket cuenta UNA sola vez, en su propio momento, para
    # que la suma de la tarjeta cuadre con el total.
    def _pares_del_ambito(clave):
        pares = []
        if clave == "eliminados":
            for t in papelera:
                if t.eliminado_en:
                    pares.append(
                        (_key_fecha(t.eliminado_en), _brecha_cerrada(t) or _brecha_abierta(t))
                    )
            return pares
        if clave == "todas":
            for t in tickets_abiertas:
                if t.en_la_papelera:
                    if t.eliminado_en:
                        pares.append(
                            (_key_fecha(t.eliminado_en), _brecha_cerrada(t) or _brecha_abierta(t))
                        )
                elif t.estado in (Ticket.Estado.RESUELTO, Ticket.Estado.CERRADO) and t.fecha_cierre:
                    pares.append((_key_fecha(t.fecha_cierre), _brecha_cerrada(t)))
                elif t.fecha_creacion:
                    pares.append((_key_fecha(t.fecha_creacion), _brecha_abierta(t)))
            return pares
        for t in _por_alcance(clave, con_papelera=False):
            if clave in ("abiertas", "en_progreso"):
                if t.fecha_creacion:
                    pares.append((_key_fecha(t.fecha_creacion), _brecha_abierta(t)))
            elif t.fecha_cierre:
                pares.append((_key_fecha(t.fecha_cierre), _brecha_cerrada(t)))
        return pares

    comparativo = {
        "recibidas": _comparativo(recibidas),
        "completadas": _comparativo(completadas),
    }
    for clave, etiqueta, _ in _ALCANCES_TORTAS:
        comparativo[clave] = _comparativo(_pares_del_ambito(clave))

    return json.dumps(
        {
            "pivot": pivot if incluir_pivot else None,
            "pie_modo": pie_modo,
            "pie_prioridad": pie_prioridad_por_alcance,
            "pie_categoria": pie_categoria_por_alcance,
            "linea": linea,
            "colores_serie": COLORES_SERIE,
            "sla": sla,
            "comparativo": comparativo,
            "etiquetas_20dias": {k: e for k, e in _ALCANCES_20_DIAS},
            "papelera_total": len(papelera),
        },
        ensure_ascii=False,
    )


def _key_fecha(fecha):
    return fecha.date() if hasattr(fecha, "date") else fecha


def _calificacion_de(tecnico):
    """Resumen de los pulgares que ha recibido un técnico.

    Va en su propio panel para que vea cómo lo está calificando la gente:
    cuántos "me gusta", cuántos "no me gusta" y el balance.
    """
    from apps.tickets.models import CalificacionTecnico

    me_gusta, no_me_gusta = 0, 0
    try:
        me_gusta = CalificacionTecnico.objects.filter(
            tecnico=tecnico, valor=CalificacionTecnico.Valor.ME_GUSTA
        ).count()
        no_me_gusta = CalificacionTecnico.objects.filter(
            tecnico=tecnico, valor=CalificacionTecnico.Valor.NO_ME_GUSTA
        ).count()
    except Exception:
        pass
    total = me_gusta + no_me_gusta
    try:
        resueltos = Ticket.objects.filter(tecnico_asignado=tecnico).filter(
            Q(fecha_resolucion__isnull=False)
            | Q(estado=Ticket.Estado.RESUELTO)
            | Q(estado=Ticket.Estado.CERRADO)
        ).count()
    except Exception:
        resueltos = 0
    tickets_calificados = CalificacionTecnico.objects.filter(
        tecnico=tecnico, ticket__tecnico_asignado=tecnico,
    ).filter(
        Q(ticket__fecha_resolucion__isnull=False)
        | Q(ticket__estado=Ticket.Estado.RESUELTO)
        | Q(ticket__estado=Ticket.Estado.CERRADO)
    ).values("ticket_id").distinct().count()
    cobertura = round(tickets_calificados * 100 / resueltos) if resueltos else None
    aprobacion = round(me_gusta * 100 / total) if total else None
    return {
        "me_gusta": me_gusta,
        "no_me_gusta": no_me_gusta,
        "total": total,
        "balance": me_gusta - no_me_gusta,
        "resueltos": resueltos,
        "cobertura": cobertura,
        "tickets_calificados": tickets_calificados,
        "aprobacion": aprobacion,
        "porcentaje": aprobacion,
    }



def _actividad_punto_venta(eventos):
    """Da presentación a la bitácora GLPI sin alterar sus registros."""
    hoy = timezone.localdate()
    filas = []
    for evento in eventos:
        descripcion = (evento.descripcion or "Actualización registrada").strip()
        codigo = evento.ticket.codigo if evento.ticket_id else ""
        prefijo = f"{codigo}:" if codigo else ""
        texto = descripcion[len(prefijo):].strip() if prefijo and descripcion.startswith(prefijo) else descripcion
        clave = texto.lower()
        if "vencido" in clave:
            icono, tono = "i-alert", "expired"
        elif "resuelto" in clave or "cerrado" in clave:
            icono, tono = "i-check-circle", "success"
        elif evento.tipo == GlpiEvento.Tipo.CAMBIO_ESTADO:
            icono, tono = "i-refresh", "update"
        elif "técnico" in clave or "tecnico" in clave:
            icono, tono = "i-message", "reply"
        elif "nueva solicitud" in clave or "ticket creado" in clave:
            icono, tono = "i-plus", "new"
        else:
            icono, tono = "i-message", "message"
        fecha_local = timezone.localtime(evento.fecha)
        if fecha_local.date() == hoy:
            fecha_label = f"Hoy, {fecha_local:%H:%M}"
        elif fecha_local.date() == hoy - timedelta(days=1):
            fecha_label = f"Ayer, {fecha_local:%H:%M}"
        else:
            fecha_label = f"{fecha_local:%d/%m/%Y, %H:%M}"
        filas.append({
            "ticket": evento.ticket,
            "codigo": codigo,
            "texto": texto,
            "icono": icono,
            "tono": tono,
            "fecha_label": fecha_label,
        })
    return filas


def _eventos_panel_punto(usuario):
    """Combina la bitácora con fechas reales de creación y papelera propias."""
    if not usuario.email:
        return []
    eventos = list(GlpiEvento.objects.select_related("ticket").filter(
        ticket__solicitante_email=usuario.email
    ).order_by("-fecha", "-pk")[:30])
    propios = Ticket.con_eliminados.filter(solicitante_email=usuario.email)
    for ticket in propios.order_by("-fecha_creacion")[:30]:
        eventos.append(SimpleNamespace(ticket=ticket, ticket_id=ticket.pk,
            tipo=GlpiEvento.Tipo.OTRO, descripcion="Nueva solicitud creada", fecha=ticket.fecha_creacion))
    for ticket in propios.filter(eliminado_en__isnull=False).order_by("-eliminado_en")[:30]:
        eventos.append(SimpleNamespace(ticket=ticket, ticket_id=ticket.pk,
            tipo=GlpiEvento.Tipo.OTRO, descripcion="Solicitud enviada a la papelera", fecha=ticket.eliminado_en))
    ahora = timezone.now()
    tickets_ans = list(propios.select_related("categoria"))
    resultados_ans = evaluar_lote(tickets_ans, ahora=ahora, permitir_provisional=True)
    for ticket in tickets_ans:
        resultado = resultados_ans[ticket.pk]
        limite = resultado.limite
        if (resultado.estado in ("vencido", "incumplido") and limite
                and (not ticket.eliminado_en or ticket.eliminado_en > limite)):
            eventos.append(SimpleNamespace(ticket=ticket, ticket_id=ticket.pk,
                tipo=GlpiEvento.Tipo.OTRO, descripcion="Ticket vencido (ANS)", fecha=limite))
    eventos.sort(key=lambda evento: evento.fecha, reverse=True)
    filas = _actividad_punto_venta(eventos[:30])
    for fila in filas:
        if fila["ticket"] and fila["ticket"].eliminado_en:
            fila["ticket"] = None
    return filas


def _build_dashboard_context(request, tickets):
    chart_context = _build_chart_context(tickets)
    eventos_qs = GlpiEvento.objects.select_related("ticket").order_by("-fecha")
    # En Mi panel la actividad es privada: solo eventos de las solicitudes
    # del punto de venta autenticado. El dashboard administrativo conserva
    # su visión global.
    if getattr(request.user, "rol", "") == Usuario.Rol.USUARIO:
        eventos_qs = eventos_qs.filter(ticket__solicitante_email=request.user.email)
    pp_glpi = _resolve_per_page(request, "per_page_glpi", PER_PAGE_DEFECTO)
    page_number = request.GET.get("page_glpi", 1)
    paginator = Paginator(eventos_qs, pp_glpi)
    eventos_glpi_page = paginator.get_page(page_number)
    chart_context.update({
        "eventos_glpi": eventos_glpi_page.object_list,
        "actividad_punto_venta": _eventos_panel_punto(request.user) if getattr(request.user, "rol", "") == Usuario.Rol.USUARIO else _actividad_punto_venta(eventos_glpi_page.object_list[:5]),
        "eventos_glpi_page": eventos_glpi_page,
        "per_page_glpi": pp_glpi,
        "querystring_glpi": _params_sin_page(request, "page_glpi"),
    })
    return chart_context


def _punto_venta_panel_datos(usuario, zona_context):
    """Datos de presentación del panel del punto de venta, sin ampliar alcance."""
    tickets = list(Ticket.objects.select_related("categoria", "tecnico_asignado").filter(
        solicitante_email=usuario.email
    ).order_by("fecha_creacion"))
    resultados_ans = evaluar_lote(tickets, permitir_provisional=True)
    # Las series cubren las siete fechas reales más recientes con actividad.
    # Así no se muestra un gráfico vacío cuando los tickets son anteriores
    # a la semana actual.
    dias = sorted({timezone.localtime(t.fecha_creacion).date() for t in tickets})[-7:]

    def contar(clave, fecha):
        if clave == "solicitudes":
            return sum(timezone.localtime(t.fecha_creacion).date() == fecha for t in tickets)
        estados = {
            "abiertas": (Ticket.Estado.ABIERTO,),
            "progreso": (Ticket.Estado.EN_PROGRESO,),
            "resueltas": (Ticket.Estado.RESUELTO, Ticket.Estado.CERRADO),
        }
        return sum(t.estado in estados[clave] and timezone.localtime(t.fecha_creacion).date() == fecha for t in tickets)

    estados = {
        "abiertos": sum(t.estado == Ticket.Estado.ABIERTO for t in tickets),
        "progreso": sum(t.estado == Ticket.Estado.EN_PROGRESO for t in tickets),
        "resueltos": sum(t.fue_resuelto for t in tickets),
        "resueltos_estado": sum(t.estado == Ticket.Estado.RESUELTO for t in tickets),
        "cerrados": sum(t.estado in (Ticket.Estado.CERRADO, Ticket.Estado.RESUELTO) for t in tickets),
        "cerrados_estado": sum(t.estado == Ticket.Estado.CERRADO for t in tickets),
        "vencidos": sum(resultados_ans[t.pk].estado == "vencido" for t in tickets),
    }
    definiciones = (
        ("solicitudes", "Solicitudes", len(tickets), "i-ticket", "red", "incluye cerradas", "?"),
        ("abiertas", "Abiertas", estados["abiertos"], "i-alert", "rose", "en espera", "?estado=abierto"),
        ("progreso", "En progreso", estados["progreso"], "i-wrench", "orange", "siendo atendidas", "?estado=en-progreso"),
        ("resueltas", "Resueltas", estados["resueltos"], "i-check-circle", "green", "resueltas", "?estado=resuelto"),
    )
    kpis = [{"key": clave, "titulo": titulo, "valor": valor, "icono": icono,
             "tono": tono, "detalle": detalle, "url": url,
            "serie": [contar(clave, dia) for dia in dias]}
            for clave, titulo, valor, icono, tono, detalle, url in definiciones]
    categorias = Counter(t.categoria.nombre if t.categoria else "Sin categoría" for t in tickets)
    puntos = Counter(t.solicitante_punto or "Sin punto" for t in tickets)
    categorias_por_estado = {}
    for estado in ("", Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO,
                   Ticket.Estado.RESUELTO, Ticket.Estado.CERRADO):
        filtrados = tickets if not estado else [t for t in tickets if t.estado == estado]
        conteo = Counter(t.categoria.nombre if t.categoria else "Sin categoría" for t in filtrados)
        categorias_por_estado[estado or "todos"] = [
            {"nombre": nombre, "total": total}
            for nombre, total in conteo.most_common(6)
        ]

    # Todas las curvas parten de fechas almacenadas. Los ceros entre fechas
    # son ausencia real de actividad, no datos de ejemplo.
    fechas_actividad = {
        timezone.localtime(t.fecha_creacion).date() for t in tickets if t.fecha_creacion
    }
    for t in tickets:
        fin = t.fecha_resolucion or t.fecha_finalizacion
        if fin:
            fechas_actividad.add(timezone.localtime(fin).date())
    dias_periodo = sorted(fechas_actividad)[-7:]

    def por_dia(fecha_attr, fecha):
        return sum(
            1 for t in tickets
            if getattr(t, fecha_attr, None)
            and timezone.localtime(getattr(t, fecha_attr)).date() == fecha
        )

    completados = [
        sum(
            1 for t in tickets
            if (t.fecha_resolucion or t.fecha_finalizacion)
            and timezone.localtime(t.fecha_resolucion or t.fecha_finalizacion).date() == dia
        )
        for dia in dias_periodo
    ]
    vencidos_periodo = [
        sum(
            1 for t in tickets
            if resultados_ans[t.pk].limite
            and timezone.localtime(resultados_ans[t.pk].limite).date() == dia
            and resultados_ans[t.pk].estado in ("vencido", "incumplido")
        )
        for dia in dias_periodo
    ]

    # El botón solo se ofrece cuando realmente necesita seguimiento: ANS
    # vencido o dentro de las dos últimas horas, y con técnico asignado.
    presionables = []
    for t in tickets:
        estado_ans, texto_ans, _detalle, _limite, _aviso = t.datos_ans_desde_resultado(resultados_ans[t.pk])
        if (
            t.estado in (Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO)
            and t.tecnico_asignado_id
            and estado_ans in ("por-vencer", "vencido")
        ):
            presionables.append({
                "pk": t.pk,
                "codigo": t.codigo,
                "titulo": t.titulo,
                "categoria": t.categoria.nombre if t.categoria else "Sin categoría",
                "prioridad": t.get_prioridad_display(),
                "prioridad_clase": t.prioridad,
                "ans_estado": estado_ans,
                "ans_texto": texto_ans,
                "limite": resultados_ans[t.pk].limite,
                "tecnico": t.tecnico_asignado.nombre,
            })
    presionables.sort(key=lambda item: item["limite"] or timezone.now())
    return {
        "kpis": kpis,
        "total": len(tickets),
        "estados": estados,
        "etiquetas": [dia.strftime("%d/%m") for dia in dias],
        "categorias": [{"nombre": nombre, "total": total} for nombre, total in categorias.most_common(6)],
        "categorias_por_estado": categorias_por_estado,
        "puntos": [{"nombre": nombre, "total": total} for nombre, total in puntos.most_common(6)],
        "periodo": {
            "etiquetas": [dia.strftime("%d/%m") for dia in dias_periodo],
            "entrantes": [por_dia("fecha_creacion", dia) for dia in dias_periodo],
            "completados": completados,
            "vencidos": vencidos_periodo,
        },
        "presionables": presionables,
        "ranking": sorted(zona_context["zona_seguimiento_dashboard"]["zonas"], key=lambda z: -z["total"]),
    }


def paginate_recent_tickets(request, queryset, page_param="page_recientes", per_page=5, per_page_param="per_page_recientes"):
    pp = _resolve_per_page(request, per_page_param, per_page)
    if pp == 0:
        pp = queryset.count() or 1
    paginator = Paginator(
        queryset.annotate(
            _prioridad_orden=orden_prioridad_annotation()
        ).order_by("-fecha_creacion", "_prioridad_orden", "-pk"),
        pp,
    )
    page_number = request.GET.get(page_param, 1)
    page_obj = paginator.get_page(page_number)
    return page_obj


def _parse_fecha_reporte(valor):
    if not valor:
        return None
    try:
        return date.fromisoformat(valor)
    except (ValueError, TypeError):
        return None


def _reportes_filtros(request):
    """Aplica los filtros del panel corporativo y retorna (f, qs)."""
    qs = Ticket.objects.select_related("categoria", "tecnico_asignado")
    desde = _parse_fecha_reporte(request.GET.get("desde"))
    hasta = _parse_fecha_reporte(request.GET.get("hasta"))
    categoria = request.GET.get("categoria", "").strip()
    prioridad = request.GET.get("prioridad", "").strip()
    tecnico = request.GET.get("tecnico", "").strip()
    usuario = request.GET.get("usuario", "").strip()

    if desde:
        qs = qs.filter(fecha_creacion__date__gte=desde)
    if hasta:
        qs = qs.filter(fecha_creacion__date__lte=hasta)
    if categoria.isdigit():
        qs = qs.filter(categoria_id=categoria)
    if prioridad in dict(Ticket.Prioridad.choices):
        qs = qs.filter(prioridad=prioridad)
    if tecnico.isdigit():
        qs = qs.filter(tecnico_asignado_id=tecnico)
    if usuario:
        qs = qs.filter(
            Q(solicitante_email__icontains=usuario) | Q(solicitante_nombre__icontains=usuario)
        )

    trozos = []
    if desde:
        trozos.append(f"desde {desde:%d/%m/%Y}")
    if hasta:
        trozos.append(f"hasta {hasta:%d/%m/%Y}")
    if categoria.isdigit():
        cat = Categoria.objects.filter(pk=categoria).values_list("nombre", flat=True).first()
        if cat:
            trozos.append(f"categoría {cat}")
    if prioridad in dict(Ticket.Prioridad.choices):
        trozos.append(f"prioridad {prioridad}")
    if tecnico.isdigit():
        nombre_tec = User.objects.filter(pk=tecnico).values_list("nombre", flat=True).first()
        if nombre_tec:
            trozos.append(f"técnico {nombre_tec}")
    if usuario:
        trozos.append(f"usuario «{usuario}»")

    return {
        "desde": desde,
        "hasta": hasta,
        "categoria": categoria,
        "prioridad": prioridad,
        "tecnico": tecnico,
        "usuario": usuario,
        "filtros_txt": ", ".join(trozos) or "Sin filtros",
    }, qs


def _reportes_metricas_kpis(tickets):
    tickets = list(tickets)
    guardados = [ticket for ticket in tickets if not ticket._state.adding]
    resultados_ans = evaluar_lote(guardados) if guardados else {}
    abiertos = en_progreso = resueltos = cerrados = 0
    vencidos = sla_ok = sla_no = 0
    horas_resolucion = 0.0
    cierres_con_tiempo = 0
    for t in tickets:
        if t.estado == Ticket.Estado.ABIERTO:
            abiertos += 1
        elif t.estado == Ticket.Estado.EN_PROGRESO:
            en_progreso += 1
        if t.fue_resuelto:
            resueltos += 1
        if t.estado in (Ticket.Estado.RESUELTO, Ticket.Estado.CERRADO):
            cerrados += 1
        resultado = resultados_ans.get(t.pk) if not t._state.adding else calcular_ans(t)
        estado_ans = resultado.estado
        if estado_ans in ("vencido", "incumplido"):
            vencidos += 1
            sla_no += 1
        elif estado_ans in ("vigente", "por_vencer", "cumplido"):
            sla_ok += 1
        if t.fecha_finalizacion and t.fecha_creacion:
            horas = (t.fecha_finalizacion - t.fecha_creacion).total_seconds() / 3600.0
            if horas >= 0:
                horas_resolucion += horas
                cierres_con_tiempo += 1
    total = len(tickets)
    base_sla = sla_ok + sla_no
    return {
        "total": total,
        "abiertos": abiertos,
        "en_progreso": en_progreso,
        "resueltos": resueltos,
        "cerrados": cerrados,
        "resueltos_cerrados": cerrados,
        "vencidos": vencidos,
        "sla_ok": sla_ok,
        "sla_no": sla_no,
        "pct_sla": round(sla_ok / base_sla * 100) if base_sla else 0,
        "prom_h": round(horas_resolucion / cierres_con_tiempo, 2) if cierres_con_tiempo else None,
        "pct_resueltos": round(resueltos / total * 100) if total else 0,
    }


def _reportes_metricas_tecnicos(tickets):
    abiertos_estados = (Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO)
    grupos = {}
    for t in tickets:
        tecnico = t.tecnico_asignado
        nombre = tecnico.nombre if tecnico else "Sin asignar"
        clave = str(tecnico.pk) if tecnico else "sin_asignar"
        g = grupos.setdefault(
            clave,
            {"nombre": nombre, "pk": tecnico.pk if tecnico else None,
             "avatar": tecnico.avatar if tecnico and tecnico.avatar else None,
             "activo": bool(tecnico and tecnico.activo), "sin_asignar": not bool(tecnico),
             "asignados": 0, "resueltos": 0, "en_curso": 0, "horas": 0.0, "n_cerrados": 0},
        )
        g["asignados"] += 1
        if t.estado in abiertos_estados:
            g["en_curso"] += 1
        if t.fue_resuelto:
            g["resueltos"] += 1
        if t.fecha_finalizacion and t.fecha_creacion:
            horas = (t.fecha_finalizacion - t.fecha_creacion).total_seconds() / 3600.0
            if horas >= 0:
                g["horas"] += horas
                g["n_cerrados"] += 1
    filas = []
    for g in grupos.values():
        filas.append(
            {
                "nombre": g["nombre"],
                "pk": g["pk"],
                "avatar": g["avatar"],
                "activo": g["activo"],
                "sin_asignar": g["sin_asignar"],
                "asignados": g["asignados"],
                "resueltos": g["resueltos"],
                "en_curso": g["en_curso"],
                "prom_h": round(g["horas"] / g["n_cerrados"], 2) if g["n_cerrados"] else None,
                "pct_resueltos": round(g["resueltos"] / g["asignados"] * 100) if g["asignados"] else 0,
            }
        )
    filas.sort(key=lambda r: r["asignados"], reverse=True)
    return filas


def _reportes_metricas_usuarios(tickets):
    from django.db.models.functions import Lower

    grupos = {}
    tickets_vistos = set()
    for t in tickets:
        if t.pk is not None:
            if t.pk in tickets_vistos:
                continue
            tickets_vistos.add(t.pk)
        nombre = t.solicitante_nombre or t.solicitante_email or "Anónimo"
        correo = (t.solicitante_email or "").strip()
        clave = ("correo", correo.lower()) if correo else ("nombre", nombre.strip().casefold())
        g = grupos.setdefault(
            clave,
            {
                "nombre": nombre,
                "email": correo,
                "creados": 0,
                "abiertos": 0,
                "resueltos": 0,
                "cerrados": 0,
                "horas": 0.0,
                "n_cerrados": 0,
                "ultimo_estado": "",
                "ultimo_fecha": None,
            },
        )
        g["creados"] += 1
        if t.estado == Ticket.Estado.ABIERTO:
            g["abiertos"] += 1
        if t.fue_resuelto:
            g["resueltos"] += 1
        if t.estado in (Ticket.Estado.RESUELTO, Ticket.Estado.CERRADO):
            g["cerrados"] += 1
        if not g["ultimo_fecha"] or (t.fecha_creacion and t.fecha_creacion > g["ultimo_fecha"]):
            g["ultimo_fecha"] = t.fecha_creacion
            g["ultimo_estado"] = t.get_estado_display()
            g["nombre"] = nombre
        # Un cierre directo no es una resolución. ANS también mide tiempo
        # transcurrido real, no horas hábiles ni el plazo de la categoría.
        if t.fecha_resolucion and t.fecha_creacion:
            horas = (t.fecha_resolucion - t.fecha_creacion).total_seconds() / 3600.0
            if horas >= 0:
                g["horas"] += horas
                g["n_cerrados"] += 1
    filas = sorted(grupos.values(), key=lambda g: g["creados"], reverse=True)
    correos = [g["email"].lower() for g in filas if g["email"]]
    cuentas = {
        u.email.lower(): u
        for u in User.objects.annotate(_correo_normalizado=Lower("email")).filter(_correo_normalizado__in=correos).only(
            "id", "email", "activo", "avatar", "glpi_user_id"
        )
        if u.email
    }
    for g in filas:
        g["prom_h"] = round(g["horas"] / g["n_cerrados"], 2) if g["n_cerrados"] else None
        cuenta = cuentas.get((g["email"] or "").lower())
        g["pk"] = cuenta.pk if cuenta else None
        g["activo"] = cuenta.activo if cuenta else None
        g["avatar"] = cuenta.avatar if cuenta and cuenta.avatar else None
        g["glpi_id"] = cuenta.glpi_user_id if cuenta else None
    return filas


def _reportes_graficos(tickets):
    """Series y distribuciones reales para la página de reportes.

    Todas parten de la misma colección ya filtrada del reporte, para que una
    gráfica nunca contradiga los KPI o las tablas de la página.
    """
    creados = Counter()
    resueltos = Counter()
    por_estado = Counter()
    por_prioridad = Counter()
    por_origen = Counter()

    for ticket in tickets:
        if ticket.fecha_creacion:
            creados[ticket.fecha_creacion.date()] += 1
        final = ticket.fecha_finalizacion
        if final:
            resueltos[final.date()] += 1
        por_estado[ticket.get_estado_display()] += 1
        por_prioridad[ticket.get_prioridad_display()] += 1
        por_origen[ticket.get_modo_display()] += 1

    fechas = sorted(set(creados) | set(resueltos))
    # Una gráfica con más de 31 puntos pierde legibilidad; agrupamos por día
    # reciente sin alterar los totales de los demás componentes.
    fechas = fechas[-31:]
    return {
        "tendencia": {
            "labels": [fecha.strftime("%d %b") for fecha in fechas],
            "creados": [creados[fecha] for fecha in fechas],
            "resueltos": [resueltos[fecha] for fecha in fechas],
        },
        "estado": {
            "labels": [label for _, label in Ticket.Estado.choices],
            "data": [por_estado[label] for _, label in Ticket.Estado.choices],
            "colores": ["#EF4444", "#F59E0B", "#10B981", "#64748B"],
        },
        "prioridad": {
            "labels": [label for _, label in Ticket.Prioridad.choices],
            "data": [por_prioridad[label] for _, label in Ticket.Prioridad.choices],
            "colores": ["#22C55E", "#FBBF24", "#F97316", "#EF4444"],
        },
        "origen": {
            "labels": [label for _, label in Ticket.Modo.choices],
            "data": [por_origen[label] for _, label in Ticket.Modo.choices],
            "colores": ["#2563EB", "#7C3AED", "#F59E0B", "#64748B"],
        },
    }


@admin_required
def reportes(request):
    f, qs = _reportes_filtros(request)
    # El panel y el archivo descargable deben calcularse sobre exactamente
    # los mismos tickets filtrados, sin recortes distintos y silenciosos.
    tickets = list(qs.order_by("fecha_creacion"))
    kpi_historico = _ticket_kpis_historico(qs)

    kpis = _reportes_metricas_kpis(tickets)
    tecnicos = _reportes_metricas_tecnicos(tickets)
    usuarios = _reportes_metricas_usuarios(tickets)
    graficos = _reportes_graficos(tickets)
    reportes_glpi_base = ""
    if esta_activo_glpi():
        reportes_glpi_base = configuracion_glpi()["base_url"].split("/apirest.php")[0].rstrip("/")
    usuarios_glpi = {
        usuario["email"].lower(): f"{reportes_glpi_base}/front/user.form.php?id={usuario['glpi_id']}"
        for usuario in usuarios
        if reportes_glpi_base and usuario.get("email") and usuario.get("glpi_id")
    }

    cat_counts = Counter(
        (t.categoria.nombre if t.categoria else "Sin categoría") for t in tickets
    )
    top_cats = [k for k, _ in cat_counts.most_common(8)]
    colores_cat = ["#D62B1F", "#F26522", "#F2A900", "#2F7D4F", "#2A6FDB", "#7B5CD6", "#B7791F", "#3E7B9E"]

    # Detalle de tickets por categoría para el tooltip de la gráfica de torta
    cat_detalle = {k: [] for k in top_cats}
    for t in tickets:
        nombre_cat = (t.categoria.nombre if t.categoria else "Sin categoría")
        if nombre_cat not in top_cats:
            continue
        cat_detalle[nombre_cat].append(
            (
                t.codigo,
                t.solicitante_nombre or t.solicitante_email or "—",
                (t.tecnico_asignado.nombre if t.tecnico_asignado else "Sin asignar"),
                t.get_estado_display(),
            )
        )
    for k, det in cat_detalle.items():
        if len(det) > 10:
            cat_detalle[k] = det[:10] + [("…", f"y {len(det) - 10} más", "", "")]

    categorias_pie = {
        "labels": top_cats,
        "data": [cat_counts[k] for k in top_cats],
        "colores": colores_cat[: len(top_cats)],
        "detalle": cat_detalle,
    }
    # Detalle de tickets por técnico para el tooltip de la gráfica comparativa
    nombres_tec = {r["nombre"] for r in tecnicos}
    tec_detalle = {k: [] for k in nombres_tec}
    for t in tickets:
        nombre_tec = (t.tecnico_asignado.nombre if t.tecnico_asignado else "Sin asignar")
        if nombre_tec not in tec_detalle:
            continue
        tec_detalle[nombre_tec].append(
            (
                t.codigo,
                t.solicitante_nombre or t.solicitante_email or "—",
                nombre_tec,
                t.get_estado_display(),
            )
        )
    for k, det in tec_detalle.items():
        if len(det) > 10:
            tec_detalle[k] = det[:10] + [("…", f"y {len(det) - 10} más", "", "")]

    tec_chart = {
        "labels": [r["nombre"] for r in tecnicos],
        "asignados": [r["asignados"] for r in tecnicos],
        "resueltos": [r["resueltos"] for r in tecnicos],
        "detalle": tec_detalle,
    }

    # Personas para el buscador unificado de filtros (técnico o usuario, por nombre o correo).
    personas = []
    for u in User.objects.filter(activo=True, rol__in=["admin", "tecnico"]).order_by("nombre").values("id", "nombre", "email", "rol"):
        personas.append(
            {"nombre": u["nombre"], "email": u["email"] or "", "rol": u["rol"], "tipo": "tecnico", "valor": str(u["id"])}
        )
    for item in Ticket.objects.values("solicitante_nombre", "solicitante_email").distinct().order_by("solicitante_nombre")[:400]:
        nombre = (item["solicitante_nombre"] or item["solicitante_email"] or "").strip()
        if not nombre:
            continue
        personas.append(
            {
                "nombre": nombre,
                "email": item["solicitante_email"] or "",
                "rol": "",
                "tipo": "usuario",
                "valor": item["solicitante_email"] or item["solicitante_nombre"],
            }
        )

    filtro_persona = {"tipo": "", "nombre": "", "rol": "", "valor": ""}
    if f["tecnico"].isdigit():
        meta = User.objects.filter(pk=f["tecnico"]).values("nombre", "rol").first()
        if meta:
            filtro_persona = {
                "tipo": "tecnico",
                "nombre": meta["nombre"],
                "rol": meta["rol"] or "",
                "valor": f["tecnico"],
            }
    elif f["usuario"]:
        filtro_persona = {"tipo": "usuario", "nombre": f["usuario"], "rol": "", "valor": f["usuario"]}

    return render(
        request,
        "tickets/reportes.html",
        {
            "kpis": kpis,
            "kpi_historico": kpi_historico,
            "tecnicos": tecnicos,
            "usuarios": usuarios,
            "tec_chart_json": json.dumps(tec_chart),
            "categorias_pie_json": json.dumps(categorias_pie),
            "graficos_reportes_json": json.dumps(graficos),
            "f": f,
            "filtros_txt": f["filtros_txt"],
            "filtros_categorias": Categoria.objects.filter(activo=True).order_by("grupo", "nombre"),
            "sugerencias_personas": json.dumps(personas),
            "filtro_persona": filtro_persona,
            "prioridad_choices": Ticket.Prioridad.choices,
            "querystring": request.GET.urlencode(),
            "total_tecnicos": sum(1 for tecnico in tecnicos if not tecnico["sin_asignar"]),
            "reportes_glpi_base": reportes_glpi_base,
            "usuarios_glpi": usuarios_glpi,
        },
    )


def _filtrar_estado(qs, estado):
    """Aplica el filtro de estado de las listas.

    "Resuelto" ya no es un estado que quede en el ticket: al marcarlo
    resuelto se cierra y queda registrada la fecha (`fecha_resolucion`). Por
    eso el filtro busca esa marca y no el estado literal, que solo queda en
    los tickets antiguos. Un ticket cerrado sin marca se cerró directo y no
    cuenta como resuelto.
    """
    if not estado:
        return qs
    if estado == Ticket.Estado.RESUELTO:
        return qs.filter(Q(fecha_resolucion__isnull=False) | Q(estado=Ticket.Estado.RESUELTO))
    return qs.filter(estado=estado)


@admin_required
def exportar_reportes(request):
    f, qs = _reportes_filtros(request)
    tickets = list(qs.order_by("fecha_creacion"))
    kpis = _reportes_metricas_kpis(tickets)
    tecnicos = _reportes_metricas_tecnicos(tickets)
    usuarios = _reportes_metricas_usuarios(tickets)

    kpi_rows = [
        ("Tickets en el reporte", kpis["total"]),
        ("Abiertos", kpis["abiertos"]),
        ("En progreso", kpis["en_progreso"]),
        ("Resueltos", kpis["resueltos"]),
        ("Cerrados", kpis["cerrados"]),
        ("Vencidos (ANS)", kpis["vencidos"]),
        ("SLA cumplidos", kpis["sla_ok"]),
        ("SLA incumplidos", kpis["sla_no"]),
    ]
    tec_rows = [
        (
            r["nombre"],
            r["asignados"],
            r["resueltos"],
            r["en_curso"],
            r["prom_h"] if r["prom_h"] is not None else "",
            f"{r['pct_resueltos']}%",
        )
        for r in tecnicos
    ]
    usu_rows = [
        (
            r["nombre"],
            r["email"],
            r["creados"],
            r["abiertos"],
            r["resueltos"],
            r["cerrados"],
            r["ultimo_estado"],
            r["prom_h"] if r["prom_h"] is not None else "",
        )
        for r in usuarios
    ]
    seccion = request.GET.get("seccion", "completo")
    if seccion not in {"completo", "tecnicos", "usuarios"}:
        seccion = "completo"
    return generar_excel_reportes(kpi_rows, tec_rows, usu_rows, tickets, f["filtros_txt"], seccion=seccion)


@staff_required
def exportar_tickets_admin(request):
    qs = Ticket.objects.select_related("categoria", "tecnico_asignado")
    estado = request.GET.get("estado", "").strip()
    prioridad = request.GET.get("prioridad", "").strip()
    categoria = request.GET.get("categoria", "").strip()
    tecnico = request.GET.get("tecnico", "").strip()
    sv = request.GET.get("sv", "todas").strip()
    rango = request.GET.get("rango", "").strip()
    q = (request.GET.get("q", "") or "")[:120].strip()
    qs = _filtrar_estado(qs, estado)
    if prioridad:
        qs = qs.filter(prioridad=prioridad)
    if categoria:
        qs = qs.filter(categoria_id=categoria)
    if tecnico:
        qs = qs.filter(tecnico_asignado_id=tecnico)
    abiertos = (Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO)
    if sv == "completadas":
        qs = qs.filter(estado__in=(Ticket.Estado.RESUELTO, Ticket.Estado.CERRADO))
    elif sv in ("abiertas", "espera"):
        qs = qs.filter(estado=Ticket.Estado.ABIERTO)
    elif sv == "no-asignadas":
        qs = qs.filter(estado__in=abiertos, tecnico_asignado__isnull=True)
    elif sv == "creadas-hoy":
        inicio_hoy = timezone.localtime(timezone.now()).replace(hour=0, minute=0, second=0, microsecond=0)
        qs = qs.filter(fecha_creacion__gte=inicio_hoy)
    if rango:
        try:
            qs = qs.filter(fecha_creacion__gte=timezone.now() - timedelta(days=int(rango)))
        except (TypeError, ValueError):
            pass
    if request.GET.get("mias", "") in ("1", "true", "on"):
        qs = qs.filter(tecnico_asignado=request.user)
    if q:
        qs = qs.filter(
            Q(codigo__iexact=q.upper())
            | Q(titulo__icontains=q)
            | Q(solicitante_nombre__icontains=q)
            | Q(solicitante_email__icontains=q)
        )
    tickets = qs.order_by("-fecha_creacion")
    # Estos dos ámbitos dependen del límite ANS calculado por categoría y
    # prioridad, por eso se resuelven igual que la bandeja tras la consulta.
    if sv in ("vencen-hoy", "vencidas"):
        ahora = timezone.now()
        inicio_hoy = timezone.localtime(ahora).replace(hour=0, minute=0, second=0, microsecond=0)
        fin_hoy = inicio_hoy + timedelta(days=1)
        tickets = list(tickets)
        resultados_ans = evaluar_lote(tickets, ahora=ahora, permitir_provisional=True)
        tickets = [
            ticket for ticket in tickets
            if ticket.estado in abiertos and resultados_ans[ticket.pk].limite
            and (
                inicio_hoy <= resultados_ans[ticket.pk].limite < fin_hoy
                if sv == "vencen-hoy" else resultados_ans[ticket.pk].estado == "vencido"
            )
        ]
    return generar_excel_tickets(tickets, titulo="Dogger Helpdesk · Reporte de Tickets")


@staff_required
def categorias_arbol(request):
    arbol = Categoria.arbol()
    # Cada subcategoria lleva su línea de "qué cubre" para que el
    # administrador vea, en la misma vista, qué se reporta en cada una.
    for grupo in arbol:
        grupo["cubre"] = que_cubre_grupo(grupo["grupo"])
        for sub in grupo["subcategorias"]:
            significado_existente = que_cubre(sub.grupo, sub.nombre)
            sub.cubre = sub.descripcion or significado_existente
            sub.descripcion_edicion = sub.descripcion or significado_existente
    grupos_en_arbol = {grupo["grupo"].casefold() for grupo in arbol}
    for categoria_grupo in CategoriaGrupo.objects.all():
        if categoria_grupo.nombre.casefold() not in grupos_en_arbol:
            arbol.append({
                "grupo": categoria_grupo.nombre,
                "subcategorias": [],
                "total": 0,
                "cubre": que_cubre_grupo(categoria_grupo.nombre),
            })
    arbol.sort(key=lambda grupo: grupo["grupo"].casefold())
    nombres_grupo = set(
        CategoriaGrupo.objects.values_list("nombre", flat=True)
    )
    nombres_grupo.update(
        Categoria.objects.order_by("grupo").values_list("grupo", flat=True)
    )
    return render(
        request,
        "tickets/categorias.html",
        {
            "arbol": arbol,
            "inactivos": Categoria.objects.filter(activo=False).order_by("grupo", "nombre"),
            "grupos_existentes": sorted(nombres_grupo, key=str.casefold),
            "form": CategoriaForm(),
            "grupo_form": CategoriaGrupoForm(),
            "total_grupos": CategoriaGrupo.objects.count(),
            "total_subcategorias_activas": Categoria.objects.filter(activo=True).count(),
            "total_subcategorias_inactivas": Categoria.objects.filter(activo=False).count(),
            "prioridad_choices": Ticket.Prioridad.choices,
            "tecnicos": User.objects.filter(
                activo=True, rol__in=["admin", "tecnico"]
            ).order_by("nombre"),
        },
    )


@staff_required
@require_POST
def categoria_grupo_crear(request):
    form = CategoriaGrupoForm(request.POST)
    if form.is_valid():
        grupo = form.save()
        messages.success(
            request,
            f"Categoría principal «{grupo.nombre}» creada. Ya puedes agregarle subcategorías.",
        )
    else:
        errores = " ".join("; ".join(e) for e in form.errors.values())
        messages.error(request, f"Revisa los datos: {errores}")
    return redirect("tickets:categorias_arbol")


def _asegurar_categoria_grupo(nombre):
    grupo = CategoriaGrupo.objects.filter(nombre__iexact=nombre).first()
    return grupo or CategoriaGrupo.objects.create(nombre=nombre)


@staff_required
@require_POST
def categoria_crear(request):
    form = CategoriaForm(request.POST)
    if form.is_valid():
        categoria = form.save(commit=False)
        categoria.activo = True
        try:
            with transaction.atomic():
                _asegurar_categoria_grupo(categoria.grupo)
                categoria.save()
            messages.success(request, f"Categoría '{categoria}' creada.")
        except IntegrityError:
            messages.error(request, "Ya existe esa subcategoría en el grupo.")
    else:
        errores = " ".join("; ".join(e) for e in form.errors.values())
        messages.error(request, f"Revisa los datos: {errores}")
    return redirect("tickets:categorias_arbol")


@admin_required
@require_POST
@escritura_coordinada
def categoria_toggle(request, pk):
    categoria = get_object_or_404(Categoria, pk=pk)
    categoria.activo = not categoria.activo
    categoria.save(update_fields=["activo"])
    estado_txt = "activada" if categoria.activo else "desactivada (oculta en el portal)"
    messages.success(request, f"Categoría '{categoria.nombre}' {estado_txt}.")
    return redirect("tickets:categorias_arbol")


@staff_required
@require_POST
@escritura_coordinada
def categoria_actualizar(request, pk):
    categoria = get_object_or_404(Categoria, pk=pk)
    nombre = request.POST.get("nombre", "").strip()
    grupo = request.POST.get("grupo", "").strip()
    glpi_id = request.POST.get("glpi_category_id", "").strip()
    tecnico_id = request.POST.get("tecnico_default", "").strip()
    if not nombre or not grupo:
        messages.error(request, "Grupo y nombre son obligatorios.")
        return redirect("tickets:categorias_arbol")
    duplicada = Categoria.objects.filter(grupo__iexact=grupo, nombre__iexact=nombre).exclude(pk=pk).exists()
    if duplicada:
        messages.error(request, f"Ya existe '{nombre}' en el grupo '{grupo}'.")
        return redirect("tickets:categorias_arbol")
    categoria.nombre = nombre
    categoria.grupo = grupo
    categoria.descripcion = request.POST.get("descripcion", "").strip()
    categoria.glpi_category_id = int(glpi_id) if glpi_id.isdigit() else None
    categoria.tecnico_default_id = int(tecnico_id) if tecnico_id.isdigit() else None
    prioridad = request.POST.get("prioridad_default", "").strip()
    if prioridad in dict(Ticket.Prioridad.choices):
        categoria.prioridad_default = prioridad
    ans_horas = request.POST.get("ans_horas", "").strip()
    if ans_horas.isdigit() and int(ans_horas) > 0:
        categoria.ans_horas = int(ans_horas)
    with transaction.atomic():
        _asegurar_categoria_grupo(grupo)
        categoria.save()
    messages.success(request, f"Categoría actualizada: {categoria}.")
    return redirect("tickets:categorias_arbol")


@admin_required
@require_POST
@escritura_coordinada
def categoria_eliminar(request, pk):
    categoria = get_object_or_404(Categoria, pk=pk)
    n_tickets = categoria.tickets.count()
    if n_tickets:
        messages.error(
            request,
            f"No se puede eliminar '{categoria.nombre}': tiene {n_tickets} ticket(s) "
            f"asociado(s). Desactívala para ocultarla del portal.",
        )
        return redirect("tickets:categorias_arbol")
    nombre = categoria.nombre
    categoria.delete()
    messages.success(request, f"Categoría '{nombre}' eliminada.")
    return redirect("tickets:categorias_arbol")


# ---------------------------------------------------------------------------
# Administración de cuentas (solo administrador)
# ---------------------------------------------------------------------------
# --- Presencia de las cuentas ---------------------------------------------
# Un solo umbral para todo el sistema: lo consultan la tabla de usuarios,
# su endpoint de estado y la ficha individual, para que los tres coincidan.
MINUTOS_EN_LINEA = 10
_TITULOS_DOT = {
    "green": "Conectado ahora mismo",
    "yellow": "Activo, pero sin conexion",
    "red": "Cuenta inactiva",
}


def _indicador_cuenta(u, ahora=None):
    """Color del punto de presencia: verde / amarillo / rojo.

    Verde = el navegador esta mandando latidos ahora. Amarillo = cuenta
    activa pero sin conexion. Rojo = cuenta inactiva.
    """
    if not u.activo:
        color = "red"
    else:
        marca = u.ultima_actividad or u.last_login
        limite = (ahora or timezone.now()) - timedelta(minutes=MINUTOS_EN_LINEA)
        color = "green" if (marca and marca >= limite) else "yellow"
    return {
        "dot": color,
        "dot_puede": u.activo,
        "dot_titulo": _TITULOS_DOT[color],
    }


@admin_required
def usuarios_lista(request):
    import time
    from django.conf import settings as dj_settings

    q = (request.GET.get("q", "") or "")[:120].strip()
    tab = request.GET.get("rol", "").strip()
    estado_filtro = request.GET.get("estado", "").strip()
    rol_filtro = request.GET.get("rol_filtro", "").strip()
    glpi_filtro = request.GET.get("glpi", "").strip()

    # Auto-sincronización con GLPI al abrir el panel (sin pulsar botones).
    # Máximo una consulta cada 45 s salvo ?force_glpi=1.
    if esta_activo_glpi():
        forzado = request.GET.get("force_glpi") == "1"
        ahora = time.time()
        ultima = request.session.get("_glpi_usuarios_sync", 0)
        if forzado or (ahora - ultima) > 45:
            request.session["_glpi_usuarios_sync"] = ahora
            try:
                conteos, error = _glpi_sincronizar_cuentas()
            except Exception as exc:  # nunca romper la carga del panel
                conteos, error = None, f"error inesperado: {exc}"
            if conteos and (conteos["creados"] or conteos["sincronizados"]):
                messages.info(
                    request,
                    "GLPI sincronizado automáticamente: "
                    f"{conteos['creados']} cuenta(s) nueva(s), "
                    f"{conteos['sincronizados']} estado(s) actualizado(s).",
                )

    usuarios = (
        User.objects.all()
        .annotate(n_tickets=Count("tickets_asignados"))
        .order_by("rol", "nombre")
    )
    if tab == "usuario":
        usuarios = usuarios.filter(rol="usuario")
    elif tab == "tecnico":
        usuarios = usuarios.filter(rol__in=["tecnico", "admin"])
    if estado_filtro == "activo":
        usuarios = usuarios.filter(activo=True)
    elif estado_filtro == "inactivo":
        usuarios = usuarios.filter(activo=False)
    if rol_filtro in {"usuario", "tecnico", "admin", "observador"}:
        usuarios = usuarios.filter(rol=rol_filtro)
    if glpi_filtro == "con":
        usuarios = usuarios.filter(glpi_user_id__isnull=False)
    elif glpi_filtro == "sin":
        usuarios = usuarios.filter(glpi_user_id__isnull=True)
    if q:
        # Búsqueda por palabras separadas: cada término debe coincidir
        for palabra in q.split():
            usuarios = usuarios.filter(
                Q(nombre__icontains=palabra)
                | Q(email__icontains=palabra)
                | Q(telefono__icontains=palabra)
            )

    pp_us = _resolve_per_page(request, "per_page", PER_PAGE_DEFECTO)
    page_obj = _paginar(usuarios, request, per_page_default=pp_us)

    # ---- Ficha por usuario: estadísticas de tickets, ubicación, actividad,
    #      y (para técnicos) permisos, disponibilidad, tareas/eventos y alertas ----
    from apps.programador.models import CalendarioEvento, DisponibilidadTecnico

    def _tipo_label(v):
        return dict(CalendarioEvento.Tipo.choices).get(v, v)

    def _acceso_label(dt):
        if not dt:
            return "Nunca"
        return timezone.localtime(dt).strftime("%d/%m/%Y %H:%M")

    hoy = date.today()
    ahora = timezone.now()
    hace_10min = ahora - timedelta(minutes=10)
    hace_7d = ahora - timedelta(days=7)
    fin_eventos = hoy + timedelta(days=14)

    en_pagina = [u.pk for u in page_obj.object_list]
    emails = [u.email.lower() for u in page_obj.object_list if u.email]
    stats_tickets = {}
    punto_mas_comun = {}
    if emails:
        stats_tickets = {
            r["solicitante_email"]: r
            for r in Ticket.objects.filter(solicitante_email__in=emails)
            .values("solicitante_email")
            .annotate(
                total=Count("pk"),
                abiertos=Count("pk", filter=Q(estado=Ticket.Estado.ABIERTO)),
                progreso=Count("pk", filter=Q(estado=Ticket.Estado.EN_PROGRESO)),
                resueltos=Count("pk", filter=Q(fecha_resolucion__isnull=False) | Q(estado=Ticket.Estado.RESUELTO)),
                cerrados=Count("pk", filter=Q(estado=Ticket.Estado.CERRADO)),
            )
        }
        _puntos = {}
        for email, punto in Ticket.objects.filter(
            solicitante_email__in=emails
        ).exclude(solicitante_punto__in=[None, ""]).values_list("solicitante_email", "solicitante_punto"):
            _puntos.setdefault(email, Counter())[punto] += 1
        punto_mas_comun = {em: c.most_common(1)[0][0] for em, c in _puntos.items()}

    disp_por_tec = {}
    evts_por_tec = {}
    vencidos_por_tec = {}
    if tab == "tecnico" and en_pagina:
        for d in DisponibilidadTecnico.objects.filter(
            tecnico_id__in=en_pagina, fecha__gte=hoy
        ).order_by("fecha", "tecnico_id"):
            disp_por_tec.setdefault(d.tecnico_id, []).append(d)
        for e in CalendarioEvento.objects.filter(
            tecnico_id__in=en_pagina, fecha__gte=hoy, fecha__lte=fin_eventos
        ).order_by("fecha", "hora").select_related("ticket"):
            evts_por_tec.setdefault(e.tecnico_id, []).append(e)
        # Vencidos se calcula en Python porque fecha_limite_ans es propiedad
        for tk in (
            Ticket.objects.filter(
                tecnico_asignado_id__in=en_pagina,
                estado__in=[Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO],
            )
            .select_related("tecnico_asignado")
            .order_by("-fecha_creacion")[:300]
        ):
            if calcular_ans(tk, ahora=ahora, permitir_provisional=True).estado == "vencido":
                vencidos_por_tec.setdefault(tk.tecnico_asignado_id, []).append(tk)

    for u in page_obj.object_list:
        em = (u.email or "").lower()
        st = stats_tickets.get(em) or {}
        # "En línea" es en vivo: el navegador avisa cada poco y se guarda en
        # `ultima_actividad`. `last_login` queda como respaldo para los que
        # aún no han enviado ni un latido.
        marca = u.ultima_actividad or u.last_login
        u.ficha = {
            "stats": st,
            "punto": punto_mas_comun.get(em, ""),
            "es_nuevo": bool(u.fecha_creacion and u.fecha_creacion >= hace_7d),
            "en_linea": bool(marca and marca >= hace_10min),
            "ultimo_acceso": marca,
            "registrado": u.fecha_creacion,
            "permisos": {
                "es_staff": u.is_staff,
                "borrar_glpi": u.borrar_glpi_al_eliminar,
                "cerrar": u.puede_cerrar_tickets,
                "eliminar": u.puede_eliminar_tickets,
                "reabrir": u.puede_reabrir_tickets,
                "crear": u.puede_crear_tickets,
                "responder": u.puede_responder_chat,
            },
            "disponibilidad": disp_por_tec.get(u.pk, []),
            "eventos": evts_por_tec.get(u.pk, [])[:6],
        }
        # Indicador junto al nombre: verde = conectado ahora mismo,
        # amarillo = activo pero sin conexión, rojo = inactivo.
        u.ficha.update(_indicador_cuenta(u, ahora))
        u.ficha["acceso_label"] = _acceso_label(u.ficha["ultimo_acceso"])
        if u.rol in ("tecnico", "admin"):
            alertas = [
                {
                    "tipo": "vencido",
                    "texto": f"Ticket {tk.codigo} vencido",
                    "url": reverse("tickets:detalle", args=[tk.pk]),
                }
                for tk in vencidos_por_tec.get(u.pk, [])
            ]
            tope_ausencia = hoy + timedelta(days=3)
            for d in u.ficha["disponibilidad"]:
                if d.tipo in ("ausencia", "falta") and d.fecha <= tope_ausencia:
                    alertas.append(
                        {
                            "tipo": "ausencia",
                            "texto": f"{d.get_tipo_display()} el {DateFormat(d.fecha).format('j M')}"
                            + (f" · {d.nota}" if d.nota else ""),
                        }
                    )
            u.ficha["alertas"] = alertas[:6]
        else:
            u.ficha["alertas"] = []

    # Búsqueda en vivo del perfil en GLPI (pestaña Técnicos con texto de búsqueda)
    perfiles_encontrados = 0
    if tab == "tecnico" and q and esta_activo_glpi():
        client = GlpiClient()
        if client.available:
            try:
                client.init_session()
                remotos = client.list_users()
            except Exception:
                remotos = []
            finally:
                client.kill_session()

            def _norm(txt):
                return (txt or "").strip().lower()

            for u in page_obj.object_list:
                u.correo_provisional = (u.email or "").endswith("@glpi.local")
                perfil = None
                for r in remotos:
                    coincide = (
                        (_norm(r["email"]) and _norm(r["email"]) == _norm(u.email))
                        or (_norm(r["login"]) and _norm(r["login"]) == _norm(u.email.split("@")[0]))
                        or (_norm(r["nombre_real"]) and _norm(r["nombre_real"]) in _norm(u.nombre))
                        or (_norm(r["nombre_real"]) and _norm(u.nombre) in _norm(r["nombre_real"]))
                    )
                    if coincide:
                        perfil = r
                        break
                if perfil:
                    u.glpi_perfil = perfil
                    perfiles_encontrados += 1
                    if not u.glpi_user_id and perfil["glpi_id"]:
                        u.glpi_user_id = perfil["glpi_id"]
                        u.save(update_fields=["glpi_user_id"])
                    # Confirmación de estado: lo que diga GLPI manda
                    if perfil["activo_glpi"] is not None and u.activo != perfil["activo_glpi"]:
                        u.activo = perfil["activo_glpi"]
                        u.is_active = perfil["activo_glpi"]
                        u.save(update_fields=["activo", "is_active"])
                        messages.warning(
                            request,
                            f"{u.nombre}: estado actualizado a "
                            f"{'Activo' if u.activo else 'Inactivo'} según su perfil en GLPI.",
                        )
            if perfiles_encontrados:
                messages.info(
                    request,
                    f"{perfiles_encontrados} perfil(es) traídos en vivo desde GLPI para «{q}».",
                )

    glpi_base = ""
    if esta_activo_glpi():
        glpi_base = configuracion_glpi()["base_url"].split("/apirest.php")[0].rstrip("/")

    # Técnicos en GLPI que aún no están en el aplicativo:
    # en la pestaña Técnicos se muestran siempre (con búsqueda, solo coincidencias)
    # para poder importarlos / verlos junto a los internos.
    glpi_remotos = []
    glpi_error = ""
    if tab == "tecnico" and glpi_base:
        palabras = [p.lower() for p in q.split()] if q else None
        ids_locales = set(
            User.objects.exclude(glpi_user_id=None).values_list("glpi_user_id", flat=True)
        )
        correos_locales = set(User.objects.values_list("email", flat=True))
        try:
            client = GlpiClient()
            remotos = []
            if client.available:
                client.init_session()
                remotos = client.list_users()
                client.kill_session()
        except Exception as exc:
            remotos = []
            glpi_error = str(exc)[:200] or "GLPI no responde."
        for r in remotos:
            texto = f"{r['login']} {r['nombre_real']} {r['email']}".lower()
            if palabras and not all(p in texto for p in palabras):
                continue
            if r["glpi_id"] in ids_locales:
                continue
            correo_real = r["email"].lower() if "@" in r["email"] else ""
            if correo_real and correo_real in correos_locales:
                continue
            glpi_remotos.append(r)
            if not palabras and len(glpi_remotos) >= 12:
                break
        glpi_remotos = glpi_remotos[:12]

    return render(
        request,
        "tickets/usuarios.html",
        {
            "usuarios": page_obj.object_list,
            "page_obj": page_obj,
            "querystring": _params_sin_page(request),
            "q": q,
            "tab": tab,
            "estado_filtro": estado_filtro,
            "rol_filtro": rol_filtro,
            "glpi_filtro": glpi_filtro,
            "total": User.objects.count(),
            "n_usuarios_finales": User.objects.filter(rol="usuario").count(),
            "n_tecnicos": User.objects.filter(rol__in=["tecnico", "admin"]).count(),
            "n_tecnicos_glpi": User.objects.filter(
                rol__in=["tecnico", "admin"], glpi_user_id__isnull=False
            ).count(),
            "n_tickets_asignados": Ticket.objects.filter(
                tecnico_asignado__isnull=False
            ).count(),
            "glpi_base": glpi_base,
            "glpi_remotos": glpi_remotos,
            "glpi_error": glpi_error,
            "per_page": pp_us,
            "tipo_label": _tipo_label,
            # Los roles salen del formulario, para que el desplegable y la
            # validación no se puedan quedar desincronizados.
            "rol_choices": UsuarioPanelForm.ROL_CHOICES,
            "hoy": date.today(),
            "n_nuevos": User.objects.filter(fecha_creacion__gte=hace_7d).count(),
            # En línea es en vivo (latido o login reciente), igual que el
            # punto de cada fila: solo last_login quedaba rancio a los minutos.
            "n_en_linea": User.objects.filter(
                Q(ultima_actividad__gte=hace_10min)
                | Q(last_login__gte=hace_10min)
            ).count(),
        },
    )


@staff_required
def usuarios_estado_api(request):
    """Estado 'en tiempo real' de las cuentas visibles: actividad y registro.

    El panel consulta este endpoint cada pocos segundos para refrescar
    los indicadores de usuarios nuevos y de quienes están usando la web.
    """
    ids = [int(x) for x in request.GET.get("ids", "").split(",") if x.strip().isdigit()][:200]
    ahora = timezone.now()
    hace_7d = ahora - timedelta(days=7)
    datos = {}
    for u in User.objects.filter(pk__in=ids):
        # El navegador manda su latido, así que "en línea" es en vivo.
        marca = u.ultima_actividad or u.last_login
        estado = _indicador_cuenta(u, ahora)
        datos[str(u.pk)] = {
            "activo": u.activo,
            "es_staff": u.is_staff,
            "nuevo": bool(u.fecha_creacion and u.fecha_creacion >= hace_7d),
            "en_linea": estado["dot"] == "green",
            "dot": estado["dot"],
            "dot_titulo": estado["dot_titulo"],
            "nombre": u.nombre or u.email,
            "ultimo_acceso": marca.isoformat() if marca else None,
        }
    return JsonResponse({"ok": True, "usuarios": datos})


def _ficha_usuario(u):
    """Construye el dict `ficha` de una cuenta (mismos campos que en usuarios_lista).

    Se usa para servir la ficha dinámica (modal) de una fila concreta.
    """
    from apps.programador.models import CalendarioEvento, DisponibilidadTecnico

    ahora = timezone.now()
    hoy = date.today()
    hace_10min = ahora - timedelta(minutes=10)
    hace_7d = ahora - timedelta(days=7)
    fin_eventos = hoy + timedelta(days=14)
    email = (u.email or "").lower()

    def _acceso_label(dt):
        if not dt:
            return "Nunca"
        return timezone.localtime(dt).strftime("%d/%m/%Y %H:%M")

    stats = {}
    punto = ""
    if u.rol in ("tecnico", "admin"):
        # Para técnicos la estadística son los tickets asignados a su carga.
        tk_qs = Ticket.objects.filter(tecnico_asignado_id=u.pk)
        stats = {
            r["tecnico_asignado_id"]: r
            for r in tk_qs.values("tecnico_asignado_id")
            .annotate(
                total=Count("pk"),
                abiertos=Count("pk", filter=Q(estado=Ticket.Estado.ABIERTO)),
                progreso=Count("pk", filter=Q(estado=Ticket.Estado.EN_PROGRESO)),
                resueltos=Count("pk", filter=Q(fecha_resolucion__isnull=False) | Q(estado=Ticket.Estado.RESUELTO)),
                cerrados=Count("pk", filter=Q(estado=Ticket.Estado.CERRADO)),
            )
        }.get(u.pk) or {}
    elif email:
        tk_qs = Ticket.objects.filter(solicitante_email=email)
        stats = {
            r["solicitante_email"]: r
            for r in tk_qs.values("solicitante_email")
            .annotate(
                total=Count("pk"),
                abiertos=Count("pk", filter=Q(estado=Ticket.Estado.ABIERTO)),
                progreso=Count("pk", filter=Q(estado=Ticket.Estado.EN_PROGRESO)),
                resueltos=Count("pk", filter=Q(fecha_resolucion__isnull=False) | Q(estado=Ticket.Estado.RESUELTO)),
                cerrados=Count("pk", filter=Q(estado=Ticket.Estado.CERRADO)),
            )
        }.get(email) or {}
        cuentas = Counter(
            tk_qs.exclude(solicitante_punto__in=[None, ""]).values_list("solicitante_punto", flat=True)
        )
        if cuentas:
            punto = cuentas.most_common(1)[0][0]

    marca = u.ultima_actividad or u.last_login
    from urllib.parse import quote

    if u.rol == "usuario":
        lista_url = reverse("tickets:lista") + "?solicitante_email=" + quote(u.email or "")
    else:
        lista_url = reverse("tickets:lista") + f"?tecnico={u.pk}"
    ficha = {
        "stats": stats,
        "lista_url": lista_url,
        "punto": punto,
        "es_nuevo": bool(u.fecha_creacion and u.fecha_creacion >= hace_7d),
        "en_linea": bool(marca and marca >= hace_10min),
        "ultimo_acceso": marca,
        "registrado": u.fecha_creacion,
        "permisos": {
            "es_staff": u.is_staff,
            "borrar_glpi": u.borrar_glpi_al_eliminar,
        },
        "disponibilidad": [],
        "eventos": [],
        "alertas": [],
    }

    ultimo_login = u.ultima_actividad or u.last_login
    ficha.update(_indicador_cuenta(u, ahora))
    ficha["acceso_label"] = _acceso_label(ultimo_login)

    if u.rol in ("tecnico", "admin"):
        disp = list(
            DisponibilidadTecnico.objects.filter(tecnico_id=u.pk, fecha__gte=hoy).order_by("fecha")
        )
        evts = list(
            CalendarioEvento.objects.filter(tecnico_id=u.pk, fecha__gte=hoy, fecha__lte=fin_eventos)
            .order_by("fecha", "hora")
            .select_related("ticket")
        )
        vencidos = []
        for tk in (
            Ticket.objects.filter(
                tecnico_asignado_id=u.pk,
                estado__in=[Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO],
            )
            .select_related("tecnico_asignado")
            .order_by("-fecha_creacion")[:300]
        ):
            if calcular_ans(tk, ahora=ahora, permitir_provisional=True).estado == "vencido":
                vencidos.append(tk)
        alertas = [
            {
                "tipo": "vencido",
                "texto": f"Ticket {tk.codigo} vencido",
                "url": reverse("tickets:detalle", args=[tk.pk]),
            }
            for tk in vencidos
        ]
        tope_ausencia = hoy + timedelta(days=3)
        for d in disp:
            if d.tipo in ("ausencia", "falta") and d.fecha <= tope_ausencia:
                alertas.append(
                    {
                        "tipo": "ausencia",
                        "texto": f"{d.get_tipo_display()} el {DateFormat(d.fecha).format('j M')}"
                        + (f" a las {d.hora.strftime('%H:%M')}" if d.hora else "")
                        + (f" · {d.nota}" if d.nota else ""),
                    }
                )
        ficha["disponibilidad"] = disp
        ficha["eventos"] = evts[:6]
        ficha["alertas"] = alertas[:6]
    return ficha


@admin_required
def usuario_ficha_api(request, pk):
    """Ficha de una cuenta (AJAX): ID GLPI, estado, estadísticas y tareas asignadas."""
    u = get_object_or_404(User, pk=pk)
    u.ficha = _ficha_usuario(u)
    html = render(request, "tickets/_ficha_usuario.html", {"u": u}).content.decode("utf-8")
    return JsonResponse({"ok": True, "html": html})


@admin_required
@require_POST
def usuario_importar_uno(request, glpi_id):
    """
    Trae UN perfil concreto de GLPI y crea su cuenta local al instante.
    Reutiliza la sincronización completa (barata y mantiene el espejo de estados).
    """
    conteos, error = _glpi_sincronizar_cuentas()
    destino = None
    if not error:
        destino = User.objects.filter(glpi_user_id=glpi_id).first()
    if error:
        messages.error(request, f"No se pudo importar — {error}")
    elif destino is None:
        messages.warning(
            request,
            f"GLPI no expone un usuario con ID #{glpi_id} visible para el token API.",
        )
    else:
        messages.success(
            request,
            f"Perfil importado desde GLPI: {destino.nombre}"
            + (" — actívalo y define contraseña al editarlo ✏️." if not destino.activo else "."),
        )
    url = reverse("tickets:usuarios")
    qv = request.POST.get("q", "").strip()
    return redirect(f"{url}?rol=tecnico" + (f"&q={qv}" if qv else ""))


@admin_required
@require_POST
def usuario_crear_glpi(request, pk):
    """Publica en GLPI una cuenta técnica creada localmente."""
    usuario = get_object_or_404(User, pk=pk)
    if usuario.glpi_user_id:
        messages.info(request, f"'{usuario.nombre}' ya está vinculado a GLPI (#{usuario.glpi_user_id}).")
        return redirect("tickets:usuarios")
    client = GlpiClient()
    if not client.available:
        messages.error(request, "GLPI no está habilitado o falta configuración (.env).")
        return redirect("tickets:usuarios")
    try:
        client.init_session()
        glpi_id = client.create_user(usuario.nombre, usuario.email)
    except GlpiError as exc:
        messages.error(request, f"No se pudo crear en GLPI: {exc}")
        return redirect("tickets:usuarios")
    finally:
        client.kill_session()
    usuario.glpi_user_id = glpi_id
    usuario.save(update_fields=["glpi_user_id"])
    messages.success(request, f"'{usuario.nombre}' creado en GLPI con id #{glpi_id}.")
    return redirect("tickets:usuarios")


def _aplicar_usuario_panel(user, form, password):
    rol_anterior = user.rol
    cambio_rol_anterior = user.cambio_rol_habilitado
    user.nombre = form.cleaned_data["nombre"]
    user.email = form.cleaned_data["email"]
    user.rol = form.cleaned_data["rol"]
    glpi_id = form.cleaned_data.get("glpi_user_id")
    user.glpi_user_id = glpi_id or None
    user.telefono = (form.cleaned_data.get("telefono") or "").strip()
    user.ubicacion = (form.cleaned_data.get("ubicacion") or "").strip()
    user.activo = form.cleaned_data.get("activo", False)
    user.is_active = user.activo
    # Quien puede cambiar de rol lo decide el administrador aquí; nadie más
    # enciende esta casilla, ni el usuario desde sus ajustes.
    user.cambio_rol_habilitado = form.cleaned_data.get(
        "cambio_rol_habilitado", False
    )
    if not user.cambio_rol_habilitado:
        user.rol_base = ""
    elif user.rol != rol_anterior or not cambio_rol_anterior or not user.rol_base:
        user.rol_base = user.rol
    if user.rol in ("admin", "tecnico"):
        user.is_staff = True
    else:
        user.is_staff = False
    if password:
        user.set_password(password)
    user.save()


@admin_required
@require_POST
def usuario_sync_glpi(request, pk):
    """
    Trae de GLPI los datos actuales del técnico vinculado
    (nombre, correo y estado activo/inactivo) y los aplica localmente.
    """
    usuario = get_object_or_404(User, pk=pk)
    if not usuario.glpi_user_id:
        messages.warning(request, f"{usuario.nombre} no tiene ID de GLPI vinculado.")
        return redirect("tickets:usuarios")

    client = GlpiClient()
    if not client.available:
        messages.error(request, "GLPI no está habilitado o falta configuración (.env).")
        return redirect("tickets:usuarios")
    try:
        client.init_session()
        remotos = client.list_users()
    except GlpiError as exc:
        messages.error(request, f"No se pudo consultar GLPI: {exc}")
        return redirect("tickets:usuarios")
    finally:
        client.kill_session()

    perfil = next((r for r in remotos if r["glpi_id"] == usuario.glpi_user_id), None)
    if not perfil:
        messages.error(
            request,
            f"El ID GLPI #{usuario.glpi_user_id} de {usuario.nombre} ya no existe o "
            f"no es visible para el token API.",
        )
        return redirect("tickets:usuarios")

    cambios = []
    if perfil["nombre_real"] and perfil["nombre_real"] != usuario.nombre:
        usuario.nombre = perfil["nombre_real"]
        cambios.append(f"nombre → {perfil['nombre_real']}")
    if perfil["email"] and "@" in perfil["email"] and perfil["email"].lower() != usuario.email.lower():
        usuario.email = perfil["email"].lower()
        cambios.append(f"correo → {usuario.email}")
    if perfil["activo_glpi"] is not None and usuario.activo != perfil["activo_glpi"]:
        usuario.activo = perfil["activo_glpi"]
        usuario.is_active = perfil["activo_glpi"]
        cambios.append(f"estado → {'Activo' if usuario.activo else 'Inactivo'} (según GLPI)")
    if cambios:
        usuario.save()
        messages.success(
            request,
            f"{usuario.nombre}: se actualizaron {len(cambios)} campo(s) desde GLPI — " + "; ".join(cambios) + ".",
        )
    else:
        messages.info(request, f"{usuario.nombre}: ya estaba igual que en GLPI.")
    return redirect("tickets:usuarios")


@admin_required
@require_POST
@escritura_coordinada
def usuario_guardar(request):
    pk = request.POST.get("pk") or None
    instancia = User.objects.filter(pk=pk).first() if pk else None
    form = UsuarioPanelForm(request.POST)
    if not form.is_valid():
        errores = " ".join("; ".join(e) for e in form.errors.values())
        messages.error(request, f"Revisa los datos del usuario: {errores}")
        return redirect("tickets:usuarios")

    email = form.cleaned_data["email"]
    existente_email = User.objects.filter(email__iexact=email).exclude(pk=instancia.pk if instancia else None).first()
    if existente_email:
        messages.error(request, f"El correo {email} ya está en uso por otra cuenta.")
        return redirect("tickets:usuarios")

    password = form.cleaned_data.get("password1") or ""
    if instancia is None:
        if not password:
            messages.error(request, "Para una cuenta nueva la contraseña es obligatoria.")
            return redirect("tickets:usuarios")
        try:
            user = User.objects.create_user(
                email=email,
                nombre=form.cleaned_data["nombre"],
                password=password,
                rol=form.cleaned_data["rol"],
                activo=form.cleaned_data.get("activo", True),
            )
        except Exception as exc:
            messages.error(request, f"No se pudo crear la cuenta: {exc}")
            return redirect("tickets:usuarios")
        _aplicar_usuario_panel(user, form, password=None)
        messages.success(request, f"Cuenta '{user.nombre}' creada ({user.get_rol_display()}).")
    else:
        _aplicar_usuario_panel(instancia, form, password=password or None)
        messages.success(request, f"Cuenta '{instancia.nombre}' actualizada.")
    return redirect("tickets:usuarios")


@admin_required
@require_POST
@escritura_coordinada
def usuario_toggle(request, pk):
    usuario = get_object_or_404(User, pk=pk)
    if usuario.pk == request.user.pk:
        messages.error(request, "No puedes desactivar tu propia cuenta.")
        return redirect("tickets:usuarios")
    usuario.activo = not usuario.activo
    usuario.is_active = usuario.activo
    usuario.save(update_fields=["activo", "is_active"])
    estado_txt = "activada" if usuario.activo else "desactivada"
    messages.success(request, f"Cuenta '{usuario.nombre}' {estado_txt}.")
    return redirect("tickets:usuarios")


@admin_required
@require_POST
@escritura_coordinada
def usuario_eliminar(request, pk):
    """Elimina definitivamente una cuenta. Los tickets asignados quedan sin técnico."""
    usuario = get_object_or_404(User, pk=pk)
    if usuario.pk == request.user.pk:
        messages.error(request, "No puedes eliminar tu propia cuenta.")
        return redirect("tickets:usuarios")
    if usuario.rol == "admin" and User.objects.filter(rol="admin", activo=True).exclude(pk=pk).count() == 0:
        messages.error(request, "No puedes eliminar al único administrador activo.")
        return redirect("tickets:usuarios")
    nombre = usuario.nombre
    n_asignados = usuario.tickets_asignados.count()
    usuario.delete()
    detalle = f" · {n_asignados} ticket(s) quedaron sin técnico" if n_asignados else ""
    messages.success(request, f"Cuenta '{nombre}' eliminada{detalle}.")
    return redirect("tickets:usuarios")


def _glpi_sincronizar_cuentas():
    """
    Refleja los técnicos visibles en GLPI como cuentas locales.
    Retorna ({conteos}, None) o (None, mensaje_de_error).
    """
    client = GlpiClient()
    if not client.available:
        return None, "GLPI no está habilitado o falta configuración (.env)."
    try:
        client.init_session()
        remotos = client.list_users()
    except GlpiError as exc:
        return None, (
            f"No se pudo consultar GLPI: {exc} "
            f"(revisa que el usuario API tenga permiso de lectura sobre Usuarios)"
        )
    except Exception as exc:
        # Nunca pantalla amarilla: explicar la causa exacta en el panel
        import traceback

        detalle = traceback.format_exc().strip().splitlines()[-3:]
        logger.exception("Error sincronizando cuentas desde GLPI")
        return None, (
            f"Error interno consultando GLPI → {type(exc).__name__}: {exc} · "
            f"{' | '.join(d.strip() for d in detalle)}"
        )
    finally:
        client.kill_session()

    if not remotos:
        return None, (
            "GLPI no devolvió ningún usuario visible para el token API configurado. "
            "Verifica en GLPI que los técnicos existan en la entidad raíz y que el "
            "perfil del usuario API pueda verlos (Administración → Usuarios)."
        )

    actualizados = creados = sin_correo = sincronizados = 0
    for remoto in remotos:
        try:
            glpi_id = int(remoto["glpi_id"])
            login = str(remoto.get("login") or "").strip()
            correo_remoto = str(remoto.get("email") or "").strip()
            nombre = (
                str(remoto.get("nombre_real") or "").strip()
                or login
                or f"Usuario GLPI {glpi_id}"
            )
        except (TypeError, ValueError, KeyError) as exc:
            logger.warning("Fila GLPI inválida descartada: %r (%s)", remoto, exc)
            continue

        if correo_remoto and "@" in correo_remoto:
            email = correo_remoto.lower()
        else:
            # Sin correo en GLPI: correo provisional para poder crear la cuenta.
            email = f"{login or f'glpi{glpi_id}'}@glpi.local"
            sin_correo += 1

        usuario = User.objects.filter(email__iexact=email).first()
        if not usuario:
            usuario = User.objects.filter(glpi_user_id=glpi_id).first()
        if usuario:
            cambios = []
            if usuario.glpi_user_id != glpi_id:
                usuario.glpi_user_id = glpi_id
                cambios.append("glpi_user_id")
            # Espejo del estado de la cuenta en GLPI ("Activo: Sí/No")
            if remoto.get("activo_glpi") is not None and bool(usuario.activo) != bool(
                remoto["activo_glpi"]
            ):
                usuario.activo = bool(remoto["activo_glpi"])
                usuario.is_active = bool(remoto["activo_glpi"])
                cambios.extend(["activo", "is_active"])
                sincronizados += 1
            # Nombre/correo vacíos localmente: completar desde GLPI
            if not (usuario.nombre or "").strip() and nombre:
                usuario.nombre = nombre
                cambios.append("nombre")
            if not (usuario.email or "") or usuario.email.endswith("@glpi.local"):
                if correo_remoto and "@" in correo_remoto:
                    usuario.email = correo_remoto.lower()
                    cambios.append("email")
            if cambios:
                usuario.save(update_fields=list(dict.fromkeys(cambios)))
            actualizados += 1
        else:
            User.objects.create_user(
                email=email,
                nombre=nombre,
                # Django 5 eliminó make_random_password: contraseña provisional aleatoria
                password="".join(
                    secrets.choice(string.ascii_letters + string.digits) for _ in range(12)
                ),
                rol="tecnico",
                activo=(remoto.get("activo_glpi") is not False),
                glpi_user_id=glpi_id,
            )
            creados += 1

    return {
        "creados": creados,
        "actualizados": actualizados,
        "sincronizados": sincronizados,
        "sin_correo": sin_correo,
        "total_glpi": len(remotos),
    }, None


@admin_required
def usuarios_importar_glpi(request):
    """Sincronización manual (enlace ↻ GLPI); el panel también lo hace automático."""
    conteos, error = _glpi_sincronizar_cuentas()
    if error:
        messages.error(request, f"Importación cancelada — {error}")
        return redirect("tickets:usuarios")
    resumen = (
        f"{conteos['creados']} cuenta(s) nueva(s) · "
        f"{conteos['actualizados']} vinculada(s)"
    )
    if conteos["sincronizados"]:
        resumen += f" · {conteos['sincronizados']} estado(s) actualizado(s) según GLPI"
    if conteos["sin_correo"]:
        resumen += (
            f" · {conteos['sin_correo']} sin correo en GLPI (correo provisional "
            f"@glpi.local: completa su correo y contraseña al editarlos)"
        )
    messages.success(request, f"Sincronización con GLPI lista: {resumen}.")
    return redirect("tickets:usuarios")


def faq(request):
    return render(request, "tickets/faq.html")


def quienes_somos(request):
    return render(request, "tickets/quienes_somos.html")


def politica_privacidad(request):
    return render(request, "tickets/politica_privacidad.html")


def portal(request):
    # Quien ya entró no ve el portal: lo manda a su panel. El destino lo
    # decide `landing_por_rol`, el mismo que usa el login, para que ninguna
    # cuenta aterrice en una vista que su rol no puede abrir.
    if request.user.is_authenticated:
        return redirect(landing_por_rol(request.user))

    if request.method == "POST":
        form = TicketForm(request.POST, request.FILES)
        if form.is_valid():
            ticket = form.save()
            _auto_asignar_tecnico(ticket)
            files = form.cleaned_data.get("adjuntos") or []
            for f in files:
                TicketAdjunto.objects.create(
                    ticket=ticket,
                    nombre_original=f.name,
                    archivo=f,
                    mime_type=f.content_type or "application/octet-stream",
                    tamano_bytes=f.size,
                    subido_por=ticket.solicitante_nombre,
                )
            # Sync opcional a GLPI (no bloquea si falla)
            _sincronizar_ticket_nuevo(request, ticket, files)

            notificar_ticket_creado(ticket)

            n = len(files)
            msg = f"Ticket creado: {ticket.codigo}"
            if n:
                msg += f" · {n} archivo(s) adjunto(s)"
            messages.success(request, msg)
            return redirect("tickets:portal")
    else:
        form = TicketForm()

    context = {"form": form}
    return render(request, "tickets/portal.html", context)


def consultar_ticket(request):
    """Consulta pública por código, incluidos los códigos históricos HD."""
    ticket = None
    form = ConsultaTicketForm(request.GET or None)
    if form.is_valid():
        codigo = form.cleaned_data["codigo"].strip().upper()
        ticket = (
            Ticket.objects.filter(codigo=codigo)
            .prefetch_related(
                Prefetch(
                    "comentarios",
                    queryset=TicketComentario.objects.filter(es_interno=False),
                )
            )
            .first()
        )
        if not ticket:
            messages.warning(request, f"No se encontro el ticket {codigo}")
    return render(
        request,
        "tickets/consultar.html",
        {"form": form, "ticket": ticket},
    )


def _sin_revisar(usuario):
    """Cuántos avisos tiene este usuario sin mirar (el número del morrito)."""
    try:
        from apps.notificaciones import services as avisos

        return avisos.sin_revisar(
            usuario, tipos=_tipos_por_revisar(getattr(usuario, "rol", None))
        )
    except Exception:
        return 0


def _avatar_url_simple(usuario):
    try:
        if usuario and getattr(usuario, "avatar", None):
            return usuario.avatar.url
    except Exception:  # noqa: BLE001 - sin foto no se rompe la vista
        pass
    return ""


def _mi_zona_supervisor(user, supervisores_permitidos=None):
    """Zona que gobierna al usuario y supervisor que le toca.

    Se mira por dos caminos: el punto de sus tickets (con los supervisores
    que el administrador asignó a ese punto) y los observadores que lo
    tienen en su lista de seguimiento.
    """
    from apps.tickets.models import ElementoMiLista, ObservadorPunto, Punto

    email = (getattr(user, "email", "") or "").strip()
    puntos_nombres = []
    vistos = set()
    if email:
        for p in (
            Ticket.objects.filter(solicitante_email__iexact=email)
            .exclude(solicitante_punto__isnull=True)
            .exclude(solicitante_punto="")
            .values_list("solicitante_punto", flat=True)
            .distinct()[:10]
        ):
            if p and p not in vistos:
                vistos.add(p)
                puntos_nombres.append(p)
    ubicacion = (getattr(user, "ubicacion", "") or "").strip()
    if ubicacion and ubicacion not in vistos:
        puntos_nombres.append(ubicacion)
    zonas = []
    for nombre in puntos_nombres:
        punto = Punto.objects.filter(nombre__iexact=nombre).first()
        sups = []
        if punto:
            relaciones = ObservadorPunto.objects.filter(punto=punto)
            if supervisores_permitidos is not None:
                relaciones = relaciones.filter(observador_id__in=supervisores_permitidos)
            for op in relaciones.select_related("observador")[:10]:
                o = op.observador
                sups.append({
                    "nombre": o.nombre or o.email,
                    "correo": o.email,
                    "en_linea": bool(getattr(o, "en_linea", False)),
                    "avatar": _avatar_url_simple(o),
                })
        zonas.append({"nombre": nombre, "supervisores": sups})
    supervisores = []
    zonas_seguimiento = {}
    vistos_obs = set()
    if email:
        asignaciones = ElementoMiLista.objects.filter(
            tipo=ElementoMiLista.TIPO_USUARIO,
        ).filter(
            Q(usuario_email__iexact=email) | Q(usuario__email__iexact=email)
        ).filter(zona__isnull=False)
        if supervisores_permitidos is not None:
            asignaciones = asignaciones.filter(observador_id__in=supervisores_permitidos)
        for el in asignaciones.select_related("observador", "zona")[:20]:
            o = el.observador
            supervisor = {
                "nombre": o.nombre or o.email,
                "correo": o.email,
                "zona": el.zona.nombre if el.zona else "",
                "en_linea": bool(getattr(o, "en_linea", False)),
                "avatar": _avatar_url_simple(o),
            }
            if o.pk not in vistos_obs:
                vistos_obs.add(o.pk)
                supervisores.append(supervisor)
            clave_zona = el.zona_id
            zona = zonas_seguimiento.setdefault(clave_zona, {
                "nombre": el.zona.nombre,
                "pk": el.zona_id,
                "supervisores": [],
                "seguimiento": True,
            })
            if not any(s["nombre"] == supervisor["nombre"] for s in zona["supervisores"]):
                zona["supervisores"].append(supervisor)
    ids_zonas = [zona["pk"] for zona in zonas_seguimiento.values()]
    miembros_por_zona = {}
    if ids_zonas:
        for elemento in ElementoMiLista.objects.filter(
            tipo=ElementoMiLista.TIPO_USUARIO,
            zona_id__in=ids_zonas,
        ).select_related("usuario"):
            zona_id = elemento.zona_id
            correo_miembro = (
                elemento.usuario_email
                or (elemento.usuario.email if elemento.usuario_id else "")
            ).strip().lower()
            if correo_miembro:
                miembros_por_zona.setdefault(zona_id, set()).add(correo_miembro)
    for zona in zonas_seguimiento.values():
        zona["correos"] = sorted(miembros_por_zona.get(zona["pk"], set()))
    # Equipo combinado para el retrato del hero (sin repetidos, con foto primero).
    equipo = []
    vistos_eq = set()

    def _meter(sup):
        clave = ((sup.get("nombre") or "").strip().lower())
        if not clave or clave in vistos_eq:
            return
        vistos_eq.add(clave)
        equipo.append(sup)

    for sup in supervisores:
        _meter(sup)
    for z in zonas:
        for sup in z["supervisores"]:
            _meter(sup)
    equipo.sort(key=lambda s: (not s.get("avatar"), not s.get("en_linea"), s.get("nombre", "")))
    return {"zonas": zonas, "supervisores": supervisores,
            "zonas_seguimiento": list(zonas_seguimiento.values()),
            "equipo": equipo[:5], "equipo_extra": max(0, len(equipo) - 5)}


def _zona_dashboard(user, zonas_info, incluir_vacias=False, consulta_base=None):
    """Métricas por zona para el panel del usuario: indicadores, ranking,
    alertas, técnicos y datos listos para las gráficas.

    Solo agregados (conteos y promedios): ningún contenido ajeno sale de
    aquí, así el usuario ve el pulso de su zona sin ver tickets de otros.
    """
    from collections import Counter

    zonas = []
    base_tickets = consulta_base if consulta_base is not None else Ticket.objects.all()
    for z in zonas_info:
        nombre = z["nombre"]
        if z.get("seguimiento"):
            alcance = Q()
            for correo in z.get("correos", []):
                alcance |= Q(solicitante_email__iexact=correo)
            qs = (
                base_tickets.filter(alcance)
                if z.get("correos") else base_tickets.none()
            )
        else:
            qs = base_tickets.filter(solicitante_punto__iexact=nombre)
        total = qs.count()
        if not total and not incluir_vacias:
            continue
        agg = qs.aggregate(
            abiertos=Count("id", filter=Q(estado=Ticket.Estado.ABIERTO)),
            en_progreso=Count("id", filter=Q(estado=Ticket.Estado.EN_PROGRESO)),
            resueltos=Count("id", filter=Q(estado=Ticket.Estado.RESUELTO)),
            cerrados=Count("id", filter=Q(estado=Ticket.Estado.CERRADO)),
        )
        muestra = list(
            qs.select_related("categoria", "tecnico_asignado")
            .order_by("-fecha_creacion")[:500]
        )
        resultados_ans = evaluar_lote(muestra, permitir_provisional=True)
        vencidos = sum(resultados_ans[t.pk].estado == "vencido" for t in muestra)
        en_plazo = sum(resultados_ans[t.pk].estado == "vigente" for t in muestra)
        sin_asignar = sum(
            1 for t in muestra
            if not t.tecnico_asignado_id
            and t.estado in (Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO)
        )
        horas = [
            (t.fecha_finalizacion - t.fecha_creacion).total_seconds() / 3600.0
            for t in muestra
            if t.fecha_finalizacion and t.fecha_creacion
            and (t.fecha_finalizacion - t.fecha_creacion).total_seconds() >= 0
        ]
        prom_h = round(sum(horas) / len(horas), 1) if horas else None
        hechos = agg["resueltos"] + agg["cerrados"]
        avance = round(hechos / total * 100) if total else 0
        medidos = en_plazo + vencidos
        sla = round(en_plazo / medidos * 100) if medidos else 100
        cats = Counter(
            t.categoria.nombre if t.categoria else "Sin categoría" for t in muestra
        )
        top_cats = [{"nombre": n, "total": v} for n, v in cats.most_common(5)]
        tecs = {}
        for t in muestra:
            tec = t.tecnico_asignado
            if not tec:
                continue
            e = tecs.setdefault(tec.pk, {
                "nombre": tec.nombre or tec.email, "email": tec.email,
                "avatar": _avatar_url_simple(tec),
                "en_linea": bool(getattr(tec, "en_linea", False)),
                "abiertos": 0,
            })
            if t.estado in (Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO):
                e["abiertos"] += 1
        zonas.append({
            "nombre": nombre,
            "total": total,
            "abiertos": agg["abiertos"],
            "en_progreso": agg["en_progreso"],
            "resueltos": agg["resueltos"],
            "cerrados": agg["cerrados"],
            "vencidos": vencidos,
            "en_plazo": en_plazo,
            "sin_asignar": sin_asignar,
            "prom_h": prom_h,
            "avance": avance,
            "sla": sla,
            "supervisores": z["supervisores"],
            "seguimiento": bool(z.get("seguimiento")),
            "tecnicos": sorted(tecs.values(), key=lambda e: (-e["abiertos"], e["nombre"].lower()))[:6],
            "top_categorias": top_cats,
        })
    zonas.sort(key=lambda z: (-z["avance"], -z["total"]))
    for i, z in enumerate(zonas, start=1):
        z["posicion"] = i
    promhs = [z["prom_h"] for z in zonas if z["prom_h"] is not None]
    totales = {
        "abiertos": sum(z["abiertos"] for z in zonas),
        "vencidos": sum(z["vencidos"] for z in zonas),
        "en_progreso": sum(z["en_progreso"] for z in zonas),
        "prom_h": round(sum(promhs) / len(promhs), 1) if promhs else None,
        "avance": round(sum(z["resueltos"] + z["cerrados"] for z in zonas)
                        / max(1, sum(z["total"] for z in zonas)) * 100),
    }
    alertas = []
    for z in zonas:
        if z["vencidos"]:
            alertas.append({"nivel": "rojo",
                            "texto": f"{z['vencidos']} vencido(s) en {z['nombre']}"})
        if z["sin_asignar"]:
            alertas.append({"nivel": "amarillo",
                            "texto": f"{z['sin_asignar']} sin asignar en {z['nombre']}"})
        if z["total"] >= 5 and z["avance"] < 50:
            alertas.append({"nivel": "amarillo",
                            "texto": f"Avance bajo en {z['nombre']} ({z['avance']}%)"})
    return {"zonas": zonas, "alertas": alertas[:8], "totales": totales}


def _indicadores_mismas_que_observador(user):
    """Indicadores del usuario calcados a lo que ve el observador.

    El observador sigue «carpetas» (ZonaObservador) con cuentas dentro. Al
    usuario no se le puede enseñar un número distinto del que ve quien lo
    acompaña: sus KPI (zonas, cuentas, tickets, abiertos, en progreso y ANS
    vencidos) salen de esas mismas carpetas, sumando exactamente los tickets
    de las cuentas que tienen dentro, sin importar el punto —igual que la
    tarjeta de zona del observador.
    """
    from apps.tickets.models import ElementoMiLista, ZonaObservador

    vacio = {"zonas": 0, "cuentas": 0, "tickets": 0,
             "abiertos": 0, "en_progreso": 0, "vencidos": 0}
    correo = (getattr(user, "email", "") or "").strip().lower()
    if not correo:
        return vacio

    # Carpetas de cualquier observador donde esté esta persona como cuenta.
    zonas = list(
        ZonaObservador.objects.filter(
            elementos__tipo=ElementoMiLista.TIPO_USUARIO,
        ).filter(
            Q(elementos__usuario_email__iexact=correo)
            | Q(elementos__usuario__email__iexact=correo)
        ).distinct()
    )
    if not zonas:
        return vacio

    # Cuentas de esas carpetas: son las que el observador mide, y solo esas.
    correos = set()
    for elemento in ElementoMiLista.objects.filter(
        tipo=ElementoMiLista.TIPO_USUARIO, zona__in=zonas,
    ).select_related("usuario"):
        miembro = (
            elemento.usuario_email
            or (elemento.usuario.email if elemento.usuario_id else "")
        ).strip().lower()
        if miembro:
            correos.add(miembro)

    # Mismo cálculo que _resumen_por_correo(global_scope=True): los tickets
    # de cada cuenta, estén en el punto que estén.
    from .views_observador import _resumen_por_correo

    resumen = _resumen_por_correo(
        user, global_scope=True, correos=sorted(correos)
    )
    abiertos = en_progreso = resueltos = 0
    for r in resumen.values():
        abiertos += r.get("abiertos", 0)
        en_progreso += r.get("en_progreso", 0)
        resueltos += r.get("cerrados_total", 0)
    # No se debe confundir prioridad urgente con ANS vencido. El indicador
    # usa el mismo cálculo que las alertas de desempeño y recorre todas las
    # cuentas de las carpetas donde participa este punto de venta.
    alcance_ans = Q()
    for correo_miembro in correos:
        alcance_ans |= Q(solicitante_email__iexact=correo_miembro)
    from . import ans_avisos

    vencidos = sum(
        ticket.ans_estado == "vencido"
        for ticket in ans_avisos.por_vencer(
            consulta=Ticket.objects.filter(alcance_ans),
            limite=None,
            solo_sin_avisar=False,
        )
    )
    return {
        "zonas": len(zonas),
        "cuentas": len(correos),
        "tickets": abiertos + resueltos,
        "abiertos": abiertos,
        "en_progreso": en_progreso,
        "vencidos": vencidos,
    }


def _zona_dashboard_ctx(user):
    """Contexto del dashboard de zona del usuario (vacío para otros roles)."""
    vacio = {"zona_dashboard": {"zonas": [], "alertas": [],
                                "totales": {"abiertos": 0, "vencidos": 0,
                                            "en_progreso": 0, "prom_h": None,
                                            "avance": 0}},
             "zona_json": "{}",
             "zona_datos": {},
             "mi_zona": {"zonas": [], "supervisores": [], "equipo": [],
                         "zonas_seguimiento": [], "equipo_extra": 0},
             "dash_json": "{}",
             "zona_seguimiento_dashboard": {"zonas": []},
             "zona_indicadores": {
                 "zonas": 0, "cuentas": 0, "tickets": 0,
                 "abiertos": 0, "en_progreso": 0, "vencidos": 0,
             },
             "alcances_tortas": tuple(
                 alcance for alcance in _ALCANCES_TORTAS
                 if alcance[0] != "eliminados"
             ),
             "alcances_20dias": tuple(
                 alcance for alcance in _ALCANCES_20_DIAS
                 if alcance[0] != "eliminados"
             )}
    if getattr(user, "rol", None) != "usuario" or not getattr(user, "pk", None):
        return vacio
    correo_usuario = (getattr(user, "email", "") or "").strip()
    # Solo una asignación explícita del usuario a una carpeta autoriza los
    # datos generales de los puntos observados por ese supervisor.
    identidad = Q(usuario_id=user.pk)
    if correo_usuario:
        identidad |= Q(usuario_email__iexact=correo_usuario)
    asignaciones = ElementoMiLista.objects.filter(
        tipo=ElementoMiLista.TIPO_USUARIO, zona__isnull=False,
        zona__observador_id=F("observador_id"),
    ).filter(identidad)
    supervisores_ids = list(asignaciones.values_list("observador_id", flat=True).distinct())
    if not supervisores_ids:
        vacio["dash_json"] = _build_tecnico_dashboard(
            consulta=Ticket.objects.none(), incluir_detalle_pivot=False
        )
        return vacio
    elementos_supervisados = ElementoMiLista.objects.filter(
        observador_id__in=supervisores_ids,
    ).select_related("usuario", "punto")
    correos_zona = set()
    puntos_zona = set()
    for elemento in elementos_supervisados:
        if elemento.tipo == ElementoMiLista.TIPO_USUARIO:
            correo = (elemento.usuario_email or (elemento.usuario.email if elemento.usuario_id else "")).strip()
            if correo:
                correos_zona.add(correo)
        elif elemento.tipo == ElementoMiLista.TIPO_PUNTO and elemento.punto_id and elemento.punto.activo:
            puntos_zona.add(elemento.punto.nombre)
    alcance = Q()
    for correo in correos_zona:
        alcance |= Q(solicitante_email__iexact=correo)
    for punto in puntos_zona:
        alcance |= Q(solicitante_punto__iexact=punto)
    tickets_zona = Ticket.objects.filter(alcance) if correos_zona or puntos_zona else Ticket.objects.none()
    mi_zona = _mi_zona_supervisor(user, supervisores_permitidos=supervisores_ids)
    zd = _zona_dashboard(user, mi_zona["zonas"], consulta_base=tickets_zona)
    seguimiento = _zona_dashboard(
        user, mi_zona["zonas_seguimiento"], incluir_vacias=True, consulta_base=tickets_zona
    )
    if zd["zonas"]:
        datos = {
            "barras": {
                "labels": [z["nombre"] for z in zd["zonas"]],
                "abiertos": [z["abiertos"] for z in zd["zonas"]],
                "progreso": [z["en_progreso"] for z in zd["zonas"]],
                "resueltos": [z["resueltos"] + z["cerrados"] for z in zd["zonas"]],
            },
            "ans": {
                "plazo": sum(z["en_plazo"] for z in zd["zonas"]),
                "vencidos": sum(z["vencidos"] for z in zd["zonas"]),
            },
            "categorias": _zona_categorias(zd["zonas"]),
        }
    else:
        # Sin puntos en sus tickets no hay zonas que rankear: en vez de
        # dejar las tres gráficas en blanco, se arman con sus propios
        # tickets, mes a mes.
        propio = _dashboard_de_mis_tickets(user)
        if not propio:
            zd, datos = vacio["zona_dashboard"], {}
        else:
            zd, datos = propio
    # El pivote entregado a la cuenta contiene agregados, nunca tickets.
    puntos_pivot = list(
        tickets_zona.exclude(solicitante_punto__isnull=True)
        .exclude(solicitante_punto="")
        .order_by("solicitante_punto")
        .values_list("solicitante_punto", flat=True)
        .distinct()
    )
    dash_json = _build_tecnico_dashboard(
        consulta=tickets_zona,
        incluir_pivot=True,
        puntos_pivot=puntos_pivot,
        incluir_detalle_pivot=False,
    )
    return {"zona_dashboard": zd,
            # La tarjeta visible al punto de venta usa la carpeta/zona real
            # que sigue el observador; `zona_dashboard` se conserva para los
            # datos históricos y las pruebas del panel.
            "zona_panel_unificado": seguimiento,
            # zona_json sigue viajando por si algo lo lee, pero la plantilla
            # se lleva el dict: el JSON se imprime con json_script, no a
            # mano, para que Chart.js siempre reciba JSON de verdad.
            "zona_json": json.dumps(datos, ensure_ascii=False),
            "zona_datos": datos,
            "mi_zona": mi_zona,
            "zona_seguimiento_dashboard": seguimiento,
            "dash_json": dash_json,
            "zona_indicadores": _indicadores_mismas_que_observador(user),
            "alcances_tortas": vacio["alcances_tortas"],
            "alcances_20dias": vacio["alcances_20dias"]}


def _zona_categorias(zonas, tope=6):
    from collections import Counter

    conteo = Counter()
    for z in zonas:
        for c in z["top_categorias"]:
            conteo[c["nombre"]] += c["total"]
    top = conteo.most_common(tope)
    return {"labels": [n for n, _ in top], "data": [v for _, v in top]}


_MESES_CORTOS = ("ene", "feb", "mar", "abr", "may", "jun",
                 "jul", "ago", "sep", "oct", "nov", "dic")


def _dashboard_de_mis_tickets(user):
    """Pulso de los tickets propios del usuario, mes a mes.

    Cuando su lista no tiene puntos (sus tickets salen sin solicitante_punto
    y su ubicación no existe como Punto) el dashboard de zona no tiene nada
    que rankear y las tres gráficas del panel salían en blanco. Para que el
    panel nunca quede sin datos, se arman con sus propios tickets: las
    barras pasan a ser los últimos seis meses y el título lo manda el dato.

    Devuelve la tupla (dashboard, datos) con la misma forma que arma
    _zona_dashboard, solo que sin zonas que comparar.
    """
    from collections import Counter

    correo = (getattr(user, "email", "") or "").strip()
    if not correo:
        return None
    qs = Ticket.objects.filter(solicitante_email__iexact=correo)
    total = qs.count()
    if not total:
        return None
    agg = qs.aggregate(
        abiertos=Count("id", filter=Q(estado=Ticket.Estado.ABIERTO)),
        en_progreso=Count("id", filter=Q(estado=Ticket.Estado.EN_PROGRESO)),
        resueltos=Count("id", filter=Q(estado=Ticket.Estado.RESUELTO)),
        cerrados=Count("id", filter=Q(estado=Ticket.Estado.CERRADO)),
    )
    muestra = list(
        qs.select_related("categoria").order_by("-fecha_creacion")[:500]
    )
    resultados_ans = evaluar_lote(muestra, permitir_provisional=True)
    vencidos = sum(resultados_ans[t.pk].estado == "vencido" for t in muestra)
    en_plazo = sum(resultados_ans[t.pk].estado == "vigente" for t in muestra)
    horas = [
        (t.fecha_finalizacion - t.fecha_creacion).total_seconds() / 3600.0
        for t in muestra
        if t.fecha_finalizacion and t.fecha_creacion
        and (t.fecha_finalizacion - t.fecha_creacion).total_seconds() >= 0
    ]
    prom_h = round(sum(horas) / len(horas), 1) if horas else None
    hechos = agg["resueltos"] + agg["cerrados"]
    # Últimos seis meses con su nombre corto, para que las barras siempre
    # tengan eje aunque el mes actual no tenga ni un ticket.
    hoy = timezone.localtime().date()
    meses = []
    for i in range(5, -1, -1):
        mes = hoy.month - i
        anio = hoy.year
        while mes <= 0:
            mes += 12
            anio -= 1
        meses.append((anio, mes))
    por_mes = {m: [0, 0, 0] for m in meses}
    cats = Counter()
    for t in muestra:
        cats[t.categoria.nombre if t.categoria else "Sin categoría"] += 1
        if not t.fecha_creacion:
            continue
        caja = por_mes.get((t.fecha_creacion.year, t.fecha_creacion.month))
        if caja is None:
            continue
        if t.estado in (Ticket.Estado.RESUELTO, Ticket.Estado.CERRADO):
            caja[2] += 1
        elif t.estado == Ticket.Estado.EN_PROGRESO:
            caja[1] += 1
        elif t.estado == Ticket.Estado.ABIERTO:
            caja[0] += 1
    top_cats = cats.most_common(6)
    datos = {
        "barras": {
            "labels": [_MESES_CORTOS[m - 1] for _, m in meses],
            "abiertos": [por_mes[m][0] for m in meses],
            "progreso": [por_mes[m][1] for m in meses],
            "resueltos": [por_mes[m][2] for m in meses],
            "titulo": "Mis tickets por mes",
        },
        "ans": {"plazo": en_plazo, "vencidos": vencidos},
        "categorias": {
            "labels": [n for n, _ in top_cats],
            "data": [c for _, c in top_cats],
        },
    }
    return {
        "zonas": [],
        "alertas": [],
        "totales": {
            "abiertos": agg["abiertos"] + agg["en_progreso"],
            "vencidos": vencidos,
            "en_progreso": agg["en_progreso"],
            "prom_h": prom_h,
            "avance": round(hechos / total * 100) if total else 0,
        },
    }, datos


@login_required
@require_POST
def mi_presionar_zona(request):
    """El usuario presiona o pide apoyo para UNA de sus zonas.

    Avisa por campana a los supervisores de la zona (o a los admins si no
    hay). La zona debe ser de las suyas: otra devuelve 404.
    """
    from apps.accounts.routing import landing_por_rol
    from apps.notificaciones import services as avisos

    u = request.user
    zona = (request.POST.get("zona") or "").strip()[:80]
    accion = "solicitar" if request.POST.get("accion") == "solicitar" else "presionar"
    mensaje = (request.POST.get("mensaje") or "").strip()[:500]
    mias = {z["nombre"].lower() for z in _mi_zona_supervisor(u)["zonas"]}
    if not zona or zona.lower() not in mias:
        raise Http404
    if not mensaje:
        messages.error(request, "Escribe el mensaje para la zona.")
        return redirect("tickets:mi_panel")
    from apps.tickets.models import ObservadorPunto, Punto

    punto = Punto.objects.filter(nombre__iexact=zona).first()
    dests = []
    if punto:
        dests = [op.observador for op in
                 ObservadorPunto.objects.filter(punto=punto).select_related("observador")[:10]]
    dests = [d for d in dests if getattr(d, "is_active", False)]
    if not dests:
        dests = list(get_user_model().objects.filter(
            rol="admin", activo=True, is_active=True)[:10])
    if accion == "solicitar":
        titulo = f"{u.nombre or u.email} solicita apoyo en {zona}"
    else:
        titulo = f"{u.nombre or u.email} presiona la {zona}"
    for d in dests:
        destino = (
            f"{reverse('tickets:monitoreo_admin')}#zonas"
            if d.rol == Usuario.Rol.ADMIN
            else f"{landing_por_rol(d)}#zonas"
        )
        avisos.crear(
            d, "sistema", titulo, mensaje,
            url=destino,
            icono="i-alert",
            actor=u.nombre or u.email,
            actor_rol="Punto de venta",
        )
    messages.success(request, f"Aviso enviado a la {zona}.")
    return redirect("tickets:mi_panel")


@login_required
@require_POST
def mi_presionar_tecnico(request, pk):
    """El usuario le escribe al técnico de SU ticket para que lo atienda.

    Guarda el mensaje en el hilo (visible, no interno) y le avisa al
    técnico por campana y correo. Solo tickets propios abiertos o en
    progreso con técnico asignado.
    """
    ticket = get_object_or_404(Ticket, pk=pk)
    u = request.user
    correo_ticket = (ticket.solicitante_email or "").strip().casefold()
    correo_usuario = (u.email or "").strip().casefold()
    if not correo_ticket or not correo_usuario or correo_ticket != correo_usuario:
        raise Http404
    if ticket.estado not in (Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO):
        messages.error(request, "Solo puedes presionar tickets abiertos o en progreso.")
        return redirect("tickets:mi_panel")
    if not ticket.tecnico_asignado_id:
        messages.error(request, "Tu ticket aún no tiene técnico asignado.")
        return redirect("tickets:mi_panel")
    mensaje = (request.POST.get("mensaje") or "").strip()[:500]
    if not mensaje:
        messages.error(request, "Escribe el mensaje para el técnico.")
        return redirect("tickets:mi_panel")
    presion = TicketComentario.objects.create(
        ticket=ticket, usuario=u, autor_nombre=u.nombre,
        comentario=mensaje, es_interno=False, es_presion=True,
    )
    notificar_comentario(ticket, u.nombre, mensaje, actor=u)
    from .notifications import notificar_presion_observadores
    notificar_presion_observadores(ticket, u, presion)
    messages.success(request, f"Mensaje enviado al técnico del {ticket.codigo}.")
    return redirect("tickets:mi_panel")


@user_required
def mi_panel(request):
    if request.method == "GET" and request.GET.get("actividad") == "1":
        filas = _eventos_panel_punto(request.user)
        return JsonResponse({"eventos": [{
            "codigo": fila["codigo"], "texto": fila["texto"],
            "icono": fila["icono"], "tono": fila["tono"],
            "fecha_label": fila["fecha_label"],
            "ticket_url": reverse("tickets:mi_ticket", args=[fila["ticket"].pk]) + "#chat-soporte" if fila["ticket"] else "",
        } for fila in filas]})
    initial = {
        "solicitante_nombre": request.user.nombre,
        "solicitante_email": request.user.email,
    }
    form = TicketForm(
        request.POST or None,
        request.FILES or None,
        initial=initial,
        categoria_automatica=True,
    )
    if request.method == "POST" and form.is_valid():
        ticket = form.save(commit=False)
        ticket.solicitante_email = request.user.email
        ticket.solicitante_nombre = request.user.nombre or ticket.solicitante_nombre
        ticket.save()
        _auto_asignar_tecnico(ticket)
        if ticket.asignacion_automatica:
            messages.info(
                request,
                f"Asignado automáticamente a {ticket.tecnico_asignado.nombre} "
                f"según la categoría del problema.",
            )
        files = form.cleaned_data.get("adjuntos") or []
        for f in files:
            TicketAdjunto.objects.create(
                ticket=ticket,
                nombre_original=f.name,
                archivo=f,
                mime_type=f.content_type or "application/octet-stream",
                tamano_bytes=f.size,
                subido_por=ticket.solicitante_nombre,
            )
        _sincronizar_ticket_nuevo(request, ticket, files)
        notificar_ticket_creado(ticket)
        messages.success(request, f"Ticket creado: {ticket.codigo}")
        return redirect("tickets:mi_panel")

    tickets_qs = Ticket.objects.select_related("categoria", "tecnico_asignado").filter(
        solicitante_email=request.user.email
    )
    total_qs = tickets_qs.count()
    estado_filtro = request.GET.get("estado", "").strip()
    categoria_filtro = request.GET.get("categoria", "").strip()
    q_filtro = (request.GET.get("q", "") or "")[:120].strip()
    if estado_filtro == Ticket.Estado.RESUELTO:
        # En Mi panel "Resueltas" trae resueltas y cerradas: al marcar
        # resuelto el ticket se cierra, y las cerradas directo también
        # cuentan como terminadas para quien las pidió.
        tickets_qs = tickets_qs.filter(
            Q(fecha_resolucion__isnull=False)
            | Q(estado=Ticket.Estado.RESUELTO)
        )
    elif estado_filtro:
        tickets_qs = tickets_qs.filter(estado=estado_filtro)
    if categoria_filtro.isdigit():
        tickets_qs = tickets_qs.filter(categoria_id=categoria_filtro)
    else:
        categoria_filtro = ""
    if q_filtro:
        tickets_qs = tickets_qs.filter(
            Q(codigo__icontains=q_filtro.upper())
            | Q(titulo__icontains=q_filtro)
        )

    stats = {
        "total": total_qs,
        # Un solo agregado en vez de tres COUNT: misma cuenta, una ida a la BD.
        **Ticket.objects.filter(solicitante_email=request.user.email).aggregate(
            abiertos=Count("id", filter=Q(estado=Ticket.Estado.ABIERTO)),
            en_progreso=Count("id", filter=Q(estado=Ticket.Estado.EN_PROGRESO)),
            resueltos=Count(
                "id",
                filter=Q(fecha_resolucion__isnull=False)
                | Q(estado=Ticket.Estado.RESUELTO),
            ),
        ),
    }
    pp_mp = _resolve_per_page(request, "per_page", PER_PAGE_DEFECTO)
    page_obj = _paginar(
        tickets_qs.annotate(_prioridad_orden=orden_prioridad_annotation()).order_by(
            "-fecha_creacion", "_prioridad_orden", "-pk"
        ),
        request,
        per_page_default=pp_mp,
    )
    dashboard_context = _build_dashboard_context(request, list(page_obj.object_list))
    zona_context = _zona_dashboard_ctx(request.user)
    punto_dashboard = _punto_venta_panel_datos(request.user, zona_context)
    return render(
        request,
        "tickets/mi_panel.html",
        {
            "usuario": request.user,
            "saludo": "Bienvenida" if request.user.genero == "femenino" else "Bienvenido",
            "tickets": page_obj.object_list,
            "page_obj": page_obj,
            "querystring": _params_sin_page(request),
            "filtro_estado": estado_filtro,
            "filtro_categoria": categoria_filtro,
            "categorias_panel": Categoria.objects.filter(activo=True).order_by("nombre"),
            "q": q_filtro,
            "estados": Ticket.Estado.choices,
            "stats": stats,
            "punto_dashboard": punto_dashboard,
            # Lo mismo que cuenta el morrito del menú: lo que tiene sin mirar.
            # Al entrar a Mi panel ya queda revisado, así que el número baja
            # a cero y solo vuelve a subir cuando pase algo.
            "pendientes": _sin_revisar(request.user),
            "form": form,
            "per_page": pp_mp,
            "cat_sugerencias_json": json.dumps(claves_para_json(), ensure_ascii=False),
            "puede_calificar_tecnicos": puede_calificar(request.user),
            "tecnicos_activos": mapeados_del_tecnico(request.user),
            "mis_abiertos": list(
                Ticket.objects.select_related("tecnico_asignado").filter(
                    solicitante_email=request.user.email,
                    estado__in=[Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO],
                ).order_by("-fecha_creacion")[:10]
            ),
            **zona_context,
            **dashboard_context,
        },
    )


@login_required
@require_POST
def calificar_tecnico(request, pk):
    """Pulgar arriba / abajo a un técnico, desde Mi panel o desde un ticket.

    Dos alcances, según si llega `ticket`:

    * Sin ticket: el voto al técnico en general (modal de Mi panel). Votar lo
      mismo dos veces quita el voto; cambiar de opinión lo reemplaza.
    * Con ticket: la opinión sobre el trabajo de ese técnico en ese ticket.
      Solo puede votar quien lo abrió, y el voto queda atado al ticket para
      que la barra cuente el trabajo y no a la persona suelta. Vale también
      con el ticket abierto, mientras tenga técnico asignado.

    Responde JSON con el voto propio y los contadores ya actualizados.
    """
    from apps.tickets.models import CalificacionTecnico
    from apps.tickets.services.tecnicos import puede_calificar

    if not puede_calificar(request.user):
        return JsonResponse(
            {"ok": False, "detalle": "Tu rol no puede calificar técnicos."}, status=403
        )

    tecnico = get_object_or_404(
        Usuario, pk=pk, rol=Usuario.Rol.TECNICO, activo=True, is_active=True
    )
    try:
        valor = int(request.POST.get("valor", 0))
    except (TypeError, ValueError):
        valor = 0
    if valor not in (CalificacionTecnico.Valor.ME_GUSTA, CalificacionTecnico.Valor.NO_ME_GUSTA):
        valor = 0

    ticket = None
    if request.POST.get("ticket"):
        ticket = get_object_or_404(
            Ticket, pk=request.POST.get("ticket"), solicitante_email=request.user.email
        )
        if not ticket.tecnico_asignado_id:
            return JsonResponse(
                {
                    "ok": False,
                    "detalle": "Este ticket todavía no tiene técnico asignado.",
                },
                status=400,
            )
        if ticket.tecnico_asignado_id != tecnico.pk:
            return JsonResponse(
                {
                    "ok": False,
                    "detalle": "Solo puedes calificar al técnico asignado a este ticket.",
                },
                status=403,
            )

    if ticket is not None:
        # Un ticket representa un trabajo concreto: su opinión se conserva y
        # no puede duplicarse o cambiarse por doble clic.
        _, creado = CalificacionTecnico.registrar_ticket_una_vez(
            tecnico, request.user, ticket, valor
        )
        # El contador que se pinta es el de ese ticket; la barra es la de todo
        # lo que el técnico tiene resuelto.
        conteos = CalificacionTecnico.conteos(tecnico, request.user, ticket)
        return JsonResponse(
            {
                "ok": True,
                "pk": tecnico.pk,
                "ticket": ticket.pk,
                "mi_voto": conteos["mi_voto"],
                "me_gusta": conteos["me_gusta"],
                "no_me_gusta": conteos["no_me_gusta"],
                "barra": CalificacionTecnico.aprobacion_por_resueltos(tecnico),
                "voto_bloqueado": True,
                "ya_calificado": not creado,
            }
        )

    CalificacionTecnico.registrar(tecnico, request.user, valor, ticket=ticket)
    conteos = CalificacionTecnico.conteos(tecnico, request.user)
    return JsonResponse(
        {
            "ok": True,
            "pk": tecnico.pk,
            "mi_voto": conteos["mi_voto"],
            "me_gusta": conteos["me_gusta"],
            "no_me_gusta": conteos["no_me_gusta"],
        }
    )


@sin_observador
@login_required
def crear_ticket(request):
    """
    Levantar un ticket con sesión iniciada (usuarios y staff).
    El staff puede crear en nombre de otro solicitante indicando sus datos.
    """
    es_usuario_final = request.user.rol == "usuario"
    if es_usuario_final and not getattr(request.user, "puede_crear_tickets", False):
        messages.error(request, "El administrador no te permite crear tickets.")
        return redirect("tickets:mi_panel")
    initial = {
        "solicitante_nombre": request.user.nombre,
        "solicitante_email": request.user.email,
    }
    # Desde la vista de categorías se llega con ?categoria=<id>. El parámetro
    # permanece en la URL también al enviar el formulario, así que se valida
    # en ambos métodos y la elección no se pierde ante un error de validación.
    elegida = None
    categoria_id = request.GET.get("categoria")
    if categoria_id and categoria_id.isdigit():
        elegida = Categoria.objects.filter(pk=categoria_id, activo=True).first()
        if elegida:
            initial["categoria"] = elegida.pk
    form = TicketForm(
        request.POST or None,
        request.FILES or None,
        initial=initial,
        permitir_modo=not es_usuario_final,
        categoria_automatica=es_usuario_final,
        categoria_preseleccionada=bool(elegida),
    )
    if request.method == "POST" and form.is_valid():
        ticket = form.save(commit=False)
        if es_usuario_final:
            ticket.solicitante_email = request.user.email
            ticket.solicitante_nombre = request.user.nombre or ticket.solicitante_nombre
        ticket.save()
        _auto_asignar_tecnico(ticket)
        if ticket.asignacion_automatica:
            messages.info(
                request,
                f"Asignado automáticamente a {ticket.tecnico_asignado.nombre} "
                f"según categoría, prioridad y disponibilidad.",
            )
        files = form.cleaned_data.get("adjuntos") or []
        for f in files:
            TicketAdjunto.objects.create(
                ticket=ticket,
                nombre_original=f.name,
                archivo=f,
                mime_type=f.content_type or "application/octet-stream",
                tamano_bytes=f.size,
                subido_por=ticket.solicitante_nombre,
            )
        _sincronizar_ticket_nuevo(request, ticket, files)
        notificar_ticket_creado(ticket)
        request.session["ticket_creado_info"] = {
            "codigo": ticket.codigo,
            "titulo": ticket.titulo,
            "categoria": str(ticket.categoria) if ticket.categoria_id else "Sin categoría",
            "prioridad": ticket.prioridad,
            "prioridad_label": ticket.get_prioridad_display(),
            "tecnico_nombre": ticket.tecnico_asignado.nombre if ticket.tecnico_asignado_id else "",
            "tecnico_iniciales": ticket.tecnico_asignado.iniciales if ticket.tecnico_asignado_id else "",
        }
        messages.success(request, f"Ticket creado: {ticket.codigo}")
        return redirect("tickets:crear_ticket")

    tecnicos_disponibles = _tecnicos_disponibles_para_formulario()
    return render(
        request,
        "tickets/crear_ticket.html",
        {
            "form": form,
            "es_usuario_final": es_usuario_final,
            "categoria_preseleccionada": bool(elegida),
            "categoria_seleccionada": elegida,
            "tecnicos_disponibles": tecnicos_disponibles,
            "cat_sugerencias_json": json.dumps(claves_para_json(), ensure_ascii=False),
            "ans_categorias_json": json.dumps(
                [
                    {
                        "id": c.pk,
                        "prioridad": c.prioridad_default,
                        "ans": c.ans_horas or horas_por_prioridad(c.prioridad_default),
                        "tecnico_default_id": c.tecnico_default_id,
                    }
                    for c in Categoria.objects.filter(activo=True).select_related("tecnico_default")
                ],
                ensure_ascii=False,
            ),
            "tecnicos_disponibles_json": json.dumps(
                tecnicos_disponibles, ensure_ascii=False
            ),
        },
    )


@user_required
def exportar_mis_tickets(request):
    tickets = Ticket.objects.select_related("categoria", "tecnico_asignado").filter(
        solicitante_email=request.user.email
    ).order_by("-fecha_creacion")
    return generar_excel_tickets(tickets, titulo=f"Mis tickets · {request.user.nombre}")


def _timeline_ticket(ticket, include_internos=False):
    """Feed cronológico unificado (chat): seguimientos públicos + eventos GLPI."""
    items = []
    for c in ticket.comentarios.all():
        if c.es_interno:
            if not include_internos:
                continue
            items.append(
                {
                    "tipo": "interno",
                    "fecha": c.fecha,
                    "autor": c.autor_nombre or (c.usuario.nombre if c.usuario_id else "Staff"),
                    "texto": c.comentario,
                }
            )
            continue
        es_usuario = bool(c.usuario_id and getattr(c.usuario, "rol", None) == "usuario")
        es_observador = bool(c.usuario_id and getattr(c.usuario, "rol", None) == "observador")
        autor = c.autor_nombre or (c.usuario.nombre if c.usuario_id else "Mesa de ayuda")
        if es_usuario:
            insignia = "Punto de venta"
        elif es_observador:
            insignia = "Observador"
        elif c.usuario_id:
            insignia = {"tecnico": "Técnico", "admin": "Admin"}.get(
                getattr(c.usuario, "rol", ""), "Soporte"
            )
        else:
            insignia = "Mesa de ayuda"
        items.append(
            {
                "tipo": "usuario" if es_usuario else ("observador" if es_observador else "soporte"),
                "fecha": c.fecha,
                "autor": autor,
                "texto": c.comentario,
                "insignia": insignia,
            }
        )
    for ev in ticket.eventos_glpi.all():
        items.append(
            {
                "tipo": "sistema",
                "fecha": ev.fecha,
                "autor": "GLPI",
                "texto": ev.descripcion,
                "evento": ev.tipo,
                "etiqueta": ev.get_tipo_display(),
            }
        )
    items.sort(key=lambda i: i["fecha"])
    return items


@login_required
def mi_ticket(request, pk):
    u = request.user
    rol = getattr(u, "rol", None)
    if rol == "usuario":
        ticket = get_object_or_404(
            Ticket.objects.select_related("categoria").prefetch_related(
                "comentarios",
                "eventos_glpi",
                "adjuntos",
            ),
            pk=pk,
            solicitante_email=u.email,
        )
        solo_lectura = False
    elif rol == "observador":
        # El observador abre la misma ficha del ticket, en solo lectura:
        # sin responder, sin editar y sin calificar. Solo tickets de sus
        # puntos o de cuentas de su lista.
        from .views_observador import puntos_del_observador

        ticket = get_object_or_404(
            Ticket.objects.select_related("categoria").prefetch_related(
                "comentarios",
                "eventos_glpi",
                "adjuntos",
            ),
            pk=pk,
        )
        puntos = puntos_del_observador(u)
        en_lista = bool(
            ticket.solicitante_email
            and ElementoMiLista.objects.filter(
                observador=u, usuario_email__iexact=ticket.solicitante_email
            ).exists()
        )
        if (ticket.solicitante_punto or "") not in puntos and not en_lista:
            raise Http404
        solo_lectura = True
    else:
        raise PermissionDenied("Solo puedes ver tus propias solicitudes.")
    timeline = _timeline_ticket(ticket)

    # Botón de calificar técnicos: se muestra siempre que el ticket tenga un
    # técnico asignado (también mientras sigue abierto), y el voto queda
    # atado a este ticket. Es el mismo modal de Mi panel, pero acá cada tarjeta
    # trae la barra de aprobación por tickets resueltos.
    from apps.tickets.services.tecnicos import mapeados_del_tecnico, puede_calificar

    puede = puede_calificar(request.user) and bool(ticket.tecnico_asignado_id)
    tecnicos = mapeados_del_tecnico(request.user, ticket) if puede else []

    return render(
        request,
        "tickets/mi_ticket.html",
        {
            "ticket": ticket,
            "timeline": timeline,
            "eventos_count": sum(1 for i in timeline if i["tipo"] == "sistema"),
            "comentario_form": ComentarioForm(),
            "usuario": request.user,
            "share_text": f"Ticket {ticket.codigo} — {ticket.titulo} ({ticket.get_estado_display()})",
            "puede_calificar_tecnicos": puede,
            "tecnicos_activos": tecnicos,
            "voto_ticket": puede,
            "nombre_tecnico_ticket": (
                ticket.tecnico_asignado.nombre if puede and ticket.tecnico_asignado else ""
            ),
            "solo_lectura": solo_lectura,
            "puede_responder": not solo_lectura or rol == "observador",
        },
    )


@sin_observador
@user_required
@require_POST
def responder_ticket(request, pk):
    ticket = get_object_or_404(
        Ticket.objects.select_related("categoria"),
        pk=pk,
        solicitante_email=request.user.email,
    )
    comentario = request.POST.get("comentario", "").strip()
    if not comentario:
        messages.error(request, "Debes escribir un mensaje para responder.")
        return redirect("tickets:mi_ticket", pk=pk)

    instancia = TicketComentario.objects.create(
        ticket=ticket,
        usuario=request.user,
        autor_nombre=request.user.nombre,
        comentario=comentario,
        es_interno=False,
    )

    notificar_comentario(ticket, request.user.nombre, comentario, actor=request.user)

    if ticket.glpi_id:
        try:
            sync_followup_to_glpi(ticket, comentario)
            messages.success(request, "Tu respuesta se envió a GLPI.")
        except GlpiError:
            messages.warning(request, "Se guardó localmente, pero no fue posible notificar a GLPI.")
    else:
        messages.success(request, "Tu respuesta quedó registrada en el ticket.")

    GlpiEvento.objects.create(
        ticket=ticket,
        tipo=GlpiEvento.Tipo.SEGUIMIENTO,
        descripcion=f"{ticket.codigo}: respuesta del solicitante registrada",
        payload_bruto={"usuario": request.user.email, "comentario": comentario},
    )
    return redirect("tickets:mi_ticket", pk=pk)


@login_required
@require_POST
def responder_ticket_obs(request, pk):
    """El observador se une a la conversación del ticket.

    Solo lectura en todo lo demás: esto solo guarda su mensaje (visible,
    no interno) en tickets de sus puntos o de su lista, y avisa al
    técnico y al solicitante como cualquier respuesta.
    """
    from .views_observador import puntos_del_observador

    u = request.user
    if getattr(u, "rol", None) != "observador":
        raise PermissionDenied("Solo el observador usa esta vía.")
    if not getattr(u, "puede_responder_chat", False):
        messages.error(request, "El administrador no te permite chatear.")
        return redirect("tickets:mi_ticket", pk=pk)
    ticket = get_object_or_404(
        Ticket.objects.select_related("categoria"), pk=pk
    )
    puntos = puntos_del_observador(u)
    en_lista = bool(
        ticket.solicitante_email
        and ElementoMiLista.objects.filter(
            observador=u, usuario_email__iexact=ticket.solicitante_email
        ).exists()
    )
    if (ticket.solicitante_punto or "") not in puntos and not en_lista:
        raise Http404
    comentario = request.POST.get("comentario", "").strip()
    if not comentario:
        messages.error(request, "Escribe tu mensaje para participar.")
        return redirect("tickets:mi_ticket", pk=pk)
    TicketComentario.objects.create(
        ticket=ticket,
        usuario=u,
        autor_nombre=u.nombre,
        comentario=comentario,
        es_interno=False,
    )
    notificar_comentario(ticket, u.nombre, comentario, actor=u)
    if ticket.glpi_id:
        try:
            sync_followup_to_glpi(ticket, comentario)
        except GlpiError:
            pass
    messages.success(request, "Tu mensaje quedó en la conversación.")
    return redirect("tickets:mi_ticket", pk=pk)


def _puede_gestionar_ticket(user, ticket) -> bool:
    """Dueño del ticket o personal de mesa de ayuda."""
    es_dueno = (
        user.is_authenticated
        and getattr(user, "rol", None) == "usuario"
        and ticket.solicitante_email == user.email
    )
    return bool(es_dueno or getattr(user, "es_staff_helpdesk", False))


@login_required
@require_POST
def reenviar_glpi(request, pk):
    """
    Reintenta la sincronización con GLPI de un ticket existente:
    lo crea en GLPI si falta, sube adjuntos pendientes y refleja cambios.
    Disponible para el dueño del ticket y para el personal.
    """
    ticket = get_object_or_404(Ticket.objects.select_related("categoria", "tecnico_asignado"), pk=pk)
    if not _puede_gestionar_ticket(request.user, ticket):
        raise PermissionDenied("No puedes gestionar este ticket.")

    try:
        if not ticket.glpi_id:
            glpi_id = sync_ticket_to_glpi(ticket)
            if not glpi_id:
                messages.warning(
                    request,
                    "GLPI no está habilitado o no tiene tokens configurados (.env).",
                )
                return redirect(_url_vuelta(request.user, ticket))
            messages.success(request, f"Ticket {ticket.codigo} registrado en GLPI #{glpi_id}.")
        else:
            sync_edicion_to_glpi(ticket)
            messages.success(request, f"Contenido de {ticket.codigo} actualizado en GLPI #{ticket.glpi_id}.")

        if ticket.tecnico_asignado_id:
            try:
                if sync_asignacion_to_glpi(ticket):
                    messages.info(request, "Técnico asignado también actualizado en GLPI.")
            except GlpiError as exc:
                messages.warning(request, f"No se pudo reflejar el técnico en GLPI: {exc}")

        n = 0
        try:
            n = sync_adjuntos_to_glpi(ticket)
        except GlpiError as exc:
            messages.warning(request, f"Adjuntos pendientes sin subir a GLPI: {exc}")
        if n:
            messages.info(request, f"{n} adjunto(s) subido(s) a GLPI.")
    except GlpiError as exc:
        messages.error(
            request,
            f"No se pudo sincronizar con GLPI: {exc}. Verifica que GLPI esté encendido "
            f"y vuelve a intentarlo.",
        )
    return redirect(_url_vuelta(request.user, ticket))


def _url_vuelta(user, ticket) -> str:
    if getattr(user, "es_staff_helpdesk", False):
        return reverse("tickets:detalle", args=[ticket.pk])
    return reverse("tickets:mi_ticket", args=[ticket.pk])


@sin_observador
@login_required
def editar_mi_ticket(request, pk):
    """El solicitante puede editar su ticket mientras siga abierto."""
    ticket = get_object_or_404(
        Ticket.objects.select_related("categoria", "tecnico_asignado"),
        pk=pk,
        solicitante_email=request.user.email,
    )
    if request.user.rol != "usuario":
        return redirect("tickets:detalle", pk=pk)
    if ticket.estado != Ticket.Estado.ABIERTO:
        messages.warning(
            request,
            "El ticket ya está siendo atendido; solo se puede editar mientras está abierto.",
        )
        return redirect("tickets:mi_ticket", pk=pk)

    form = TicketEdicionForm(request.POST or None, instance=ticket)
    if request.method == "POST" and form.is_valid():
        with coordinacion_asignacion():
            ticket = Ticket.objects.select_for_update().get(pk=ticket.pk)
            if ticket.estado != Ticket.Estado.ABIERTO:
                messages.warning(request, "El ticket ya está siendo atendido y no puede editarse.")
                return redirect("tickets:mi_ticket", pk=pk)
            antes_categoria = ticket.categoria_id
            for campo in form.Meta.fields:
                setattr(ticket, campo, form.cleaned_data[campo])
            ticket.save(update_fields=[*form.Meta.fields, "fecha_actualizacion"])
        reasignar = (
            not ticket.tecnico_asignado_id
            or (ticket.categoria_id != antes_categoria and ticket.asignacion_automatica)
        )
        if reasignar and _auto_asignar_tecnico(ticket):
            messages.info(
                request,
                f"Reasignado automáticamente a {ticket.tecnico_asignado.nombre} según la nueva categoría.",
            )
        if ticket.glpi_id:
            try:
                sync_edicion_to_glpi(ticket)
                messages.success(request, "Cambios reflejados en GLPI.")
            except GlpiError as exc:
                messages.warning(
                    request,
                    f"Cambios guardados localmente, pero no se pudieron reflejar en GLPI: {exc}",
                )
        messages.success(request, f"Ticket {ticket.codigo} actualizado.")
        return redirect("tickets:mi_ticket", pk=pk)

    return render(
        request,
        "tickets/mi_ticket_editar.html",
        {"form": form, "ticket": ticket},
    )


def _dashboard_filtros(request, fecha_campo="fecha_creacion"):
    """Filtros compartidos por el panel administrador y su actualización JSON."""
    qs = Ticket.objects.select_related("categoria", "tecnico_asignado")
    periodo = request.GET.get("periodo", "30")
    estado = request.GET.get("estado", "")
    prioridad = request.GET.get("prioridad", "")
    categoria = request.GET.get("categoria", "")
    tecnico = request.GET.get("tecnico", "")
    punto = request.GET.get("punto", "")
    if periodo in {"7", "30", "90"}:
        qs = qs.filter(**{f"{fecha_campo}__gte": timezone.now() - timedelta(days=int(periodo))})
    else:
        periodo = "30"
        qs = qs.filter(**{f"{fecha_campo}__gte": timezone.now() - timedelta(days=30)})
    if estado in dict(Ticket.Estado.choices):
        qs = qs.filter(estado=estado)
    if prioridad in dict(Ticket.Prioridad.choices):
        qs = qs.filter(prioridad=prioridad)
    if categoria.isdigit():
        qs = qs.filter(categoria_id=categoria)
    if tecnico.isdigit():
        qs = qs.filter(tecnico_asignado_id=tecnico)
    if punto:
        qs = qs.filter(solicitante_punto=punto)
    return {
        "periodo": periodo, "estado": estado, "prioridad": prioridad,
        "categoria": categoria, "tecnico": tecnico, "punto": punto,
    }, qs


def _dashboard_metricas(tickets):
    """Métricas reales de una colección ya filtrada, sin estimar datos ausentes."""
    total = len(tickets)
    activos = (Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO)
    abiertos = sum(t.estado == Ticket.Estado.ABIERTO for t in tickets)
    progreso = sum(t.estado == Ticket.Estado.EN_PROGRESO for t in tickets)
    cerrados = sum(t.estado == Ticket.Estado.CERRADO for t in tickets)
    resueltos = sum(t.fue_resuelto for t in tickets)
    sin_asignar = sum(t.estado in activos and not t.tecnico_asignado_id for t in tickets)
    urgentes = sum(t.estado in activos and t.prioridad == Ticket.Prioridad.URGENTE for t in tickets)
    altas = sum(t.estado in activos and t.prioridad == Ticket.Prioridad.ALTA for t in tickets)
    vencidos = 0
    sla_ok = sla_total = 0
    sla_dentro = sla_proximos = sla_sin = 0
    sla_tickets = {clave: [] for clave in ("dentro", "vencidos", "proximos", "sin")}
    duraciones = []
    ahora_ans = timezone.now()
    guardados = [ticket for ticket in tickets if not ticket._state.adding]
    resultados_ans = evaluar_lote(guardados, ahora=ahora_ans) if guardados else {}
    resultados_operativos = evaluar_lote(guardados, ahora=ahora_ans, permitir_provisional=True) if guardados else {}
    for ticket in tickets:
        resultado_ans = resultados_ans[ticket.pk] if not ticket._state.adding else calcular_ans(ticket, ahora=ahora_ans)
        final = ticket.fecha_finalizacion
        if final and ticket.fecha_creacion and final >= ticket.fecha_creacion:
            duraciones.append(final - ticket.fecha_creacion)
        if resultado_ans.estado == "sin_informacion":
            sla_sin += 1
            sla_tickets["sin"].append(ticket)
            continue
        sla_total += 1
        if resultado_ans.estado in ("vigente", "por_vencer", "cumplido"):
            sla_ok += 1
            if resultado_ans.estado == "por_vencer":
                sla_proximos += 1
                sla_tickets["proximos"].append(ticket)
            else:
                sla_dentro += 1
                sla_tickets["dentro"].append(ticket)
        else:
            vencidos += 1
            sla_tickets["vencidos"].append(ticket)
    promedio = sum(duraciones, timedelta()) / len(duraciones) if duraciones else None

    # Primera respuesta: se toma el primer comentario público de personal
    # técnico o administrador, nunca un comentario del solicitante.
    ticket_ids = [ticket.pk for ticket in tickets]
    primeras_respuestas = dict(
        TicketComentario.objects.filter(
            ticket_id__in=ticket_ids,
            es_interno=False,
            usuario__rol__in=(Usuario.Rol.ADMIN, Usuario.Rol.TECNICO),
        ).values("ticket_id").annotate(fecha_primera=Min("fecha"))
        .values_list("ticket_id", "fecha_primera")
    ) if ticket_ids else {}
    tiempos_primera_respuesta = [
        fecha - ticket.fecha_creacion
        for ticket in tickets
        if (fecha := primeras_respuestas.get(ticket.pk)) and ticket.fecha_creacion
        and fecha >= ticket.fecha_creacion
    ]
    promedio_primera_respuesta = (
        sum(tiempos_primera_respuesta, timedelta()) / len(tiempos_primera_respuesta)
        if tiempos_primera_respuesta else None
    )

    # Una aprobación no es estadísticamente representativa con un único voto.
    # Solo se muestran resultados con tres o más evaluaciones de tickets.
    from .models import CalificacionTecnico
    votos = CalificacionTecnico.objects.filter(ticket_id__in=ticket_ids)
    total_votos = votos.count()
    positivos = votos.filter(valor=CalificacionTecnico.Valor.ME_GUSTA).count()
    return {
        "total": total, "abiertos": abiertos, "progreso": progreso, "pendientes": abiertos + progreso,
        "vencidos_pendientes": sum(t.estado in activos and
            (resultados_operativos[t.pk] if not t._state.adding else calcular_ans(t, ahora=ahora_ans, permitir_provisional=True)).estado == "vencido"
            for t in tickets),
        "completados_actuales": sum(t.estado in (Ticket.Estado.RESUELTO, Ticket.Estado.CERRADO) for t in tickets),
        "sin_asignar": sin_asignar, "urgentes": urgentes, "altas": altas,
        "en_progreso": progreso,
        "cerrados": cerrados, "resueltos": resueltos,
        "resueltos_cerrados": resueltos + cerrados, "vencidos": vencidos,
        "sla_pct": round(sla_ok * 100 / sla_total) if sla_total else None,
        "sla_ok": sla_ok,
        "sla_no": sla_total - sla_ok,
        "sla_total": sla_total,
        "sla_dentro": sla_dentro, "sla_proximos": sla_proximos, "sla_sin": sla_sin,
        "sla_tickets": {clave: [{"codigo": t.codigo, "titulo": t.titulo, "url": reverse("tickets:detalle", args=[t.pk])} for t in grupo] for clave, grupo in sla_tickets.items()},
        "primera_respuesta": formatear_duracion(promedio_primera_respuesta) if promedio_primera_respuesta else None,
        "primera_respuesta_total": len(tiempos_primera_respuesta),
        "resolucion": formatear_duracion(promedio) if promedio else None,
        "resolucion_total": len(duraciones),
        "satisfaccion": round(positivos * 100 / total_votos) if total_votos >= 3 else None,
        "satisfaccion_positivos": positivos,
        "satisfaccion_votos": total_votos,
    }


def _dashboard_sparks(tickets, dias=7):
    """Series históricas derivadas exclusivamente de fechas reales de tickets."""
    inicio = timezone.localdate() - timedelta(days=dias - 1)
    fechas = [inicio + timedelta(days=i) for i in range(dias)]
    series = {"total": [0] * dias, "abiertos": [0] * dias, "progreso": [0] * dias,
              "cerrados": [0] * dias, "vencidos": [0] * dias}
    for clave in ("sin_asignar", "urgentes", "altas", "sla_total", "pendientes", "vencidos_pendientes", "completados_actuales"):
        series[clave] = [0] * dias
    ahora_ans = timezone.now()
    guardados = [ticket for ticket in tickets if not ticket._state.adding]
    resultados_ans = evaluar_lote(guardados, ahora=ahora_ans) if guardados else {}
    resultados_operativos = evaluar_lote(guardados, ahora=ahora_ans, permitir_provisional=True) if guardados else {}
    for ticket in tickets:
        resultado_ans = resultados_ans[ticket.pk] if not ticket._state.adding else calcular_ans(ticket, ahora=ahora_ans)
        fecha = _key_fecha(ticket.fecha_creacion)
        if fecha not in fechas:
            continue
        indice = (fecha - inicio).days
        series["total"][indice] += 1
        activo = ticket.estado in (Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO)
        if activo:
            series["pendientes"][indice] += 1
            resultado_operativo = resultados_operativos[ticket.pk] if not ticket._state.adding else calcular_ans(ticket, ahora=ahora_ans, permitir_provisional=True)
            if resultado_operativo.estado == "vencido":
                series["vencidos_pendientes"][indice] += 1
        if ticket.estado in (Ticket.Estado.RESUELTO, Ticket.Estado.CERRADO):
            series["completados_actuales"][indice] += 1
        if activo and not ticket.tecnico_asignado_id:
            series["sin_asignar"][indice] += 1
        if activo and ticket.prioridad == Ticket.Prioridad.URGENTE:
            series["urgentes"][indice] += 1
        if activo and ticket.prioridad == Ticket.Prioridad.ALTA:
            series["altas"][indice] += 1
        if resultado_ans.estado != "sin_informacion":
            series["sla_total"][indice] += 1
        if ticket.estado == Ticket.Estado.ABIERTO:
            series["abiertos"][indice] += 1
        elif ticket.estado == Ticket.Estado.EN_PROGRESO:
            series["progreso"][indice] += 1
        elif ticket.estado == Ticket.Estado.CERRADO:
            series["cerrados"][indice] += 1
        if resultado_ans.estado in ("vencido", "incumplido"):
            series["vencidos"][indice] += 1
    return series


def _dashboard_atencion(tickets):
    orden = {Ticket.Prioridad.URGENTE: 0, Ticket.Prioridad.ALTA: 1,
             Ticket.Prioridad.MEDIA: 2, Ticket.Prioridad.BAJA: 3}
    pendientes = [t for t in tickets if t.estado in (Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO)]
    ahora = timezone.now()
    resultados_ans = evaluar_lote(pendientes, ahora=ahora, permitir_provisional=True)
    pendientes.sort(key=lambda t: (resultados_ans[t.pk].estado != "vencido", orden.get(t.prioridad, 9), resultados_ans[t.pk].limite or ahora))
    return pendientes[:8]


def _dashboard_sparks_resueltos(qs):
    inicio = timezone.localdate() - timedelta(days=6)
    valores = [0] * 7
    for fecha in qs.filter(estado__in=[Ticket.Estado.RESUELTO, Ticket.Estado.CERRADO]).values_list("fecha_resolucion", flat=True):
        dia = _key_fecha(fecha)
        if dia and 0 <= (dia - inicio).days < 7:
            valores[(dia - inicio).days] += 1
    return valores


def _dashboard_comparacion_resueltos(request, filtros, actual):
    dias = int(filtros["periodo"])
    fin = timezone.now() - timedelta(days=dias)
    # Se reconstruye la consulta sin la restricción temporal actual.
    base = Ticket.objects.filter(fecha_resolucion__gte=fin - timedelta(days=dias), fecha_resolucion__lt=fin, estado__in=[Ticket.Estado.RESUELTO, Ticket.Estado.CERRADO])
    for clave, campo in (("estado", "estado"), ("prioridad", "prioridad"), ("categoria", "categoria_id"), ("tecnico", "tecnico_asignado_id"), ("punto", "solicitante_punto")):
        valor = filtros.get(clave)
        if valor and (clave not in ("categoria", "tecnico") or valor.isdigit()) and (clave != "estado" or valor in dict(Ticket.Estado.choices)) and (clave != "prioridad" or valor in dict(Ticket.Prioridad.choices)):
            base = base.filter(**{campo: valor})
    anterior = base.count()
    return round((actual - anterior) * 100 / anterior) if anterior else None


@admin_required
def registro_seguimientos_api(request):
    """Fuente parcial: solo seguimientos reales, disponible al administrador."""
    from .actividad_registro import consultar_seguimientos

    pagina, conteos = consultar_seguimientos(request.GET)
    eventos = []
    for comentario in pagina:
        eventos.append({
            "id": comentario.pk,
            "tipo": "presion" if comentario.es_presion else "seguimiento",
            "ticket": comentario.ticket.codigo,
            "ticket_url": reverse("tickets:detalle", args=[comentario.ticket_id]),
            "actor": comentario.autor_nombre or (comentario.usuario.nombre if comentario.usuario else "Sistema"),
            "rol_actual": comentario.usuario.rol if comentario.usuario else None,
            "interno": comentario.es_interno,
            "fecha": timezone.localtime(comentario.fecha).isoformat(),
        })
    return JsonResponse({"eventos": eventos, "conteos_por_rol_actual": conteos,
                         "pagina": pagina.number, "paginas": pagina.paginator.num_pages,
                         "total": pagina.paginator.count})


@admin_required
def dashboard(request):
    filtros, tickets_qs = _dashboard_filtros(request)
    tickets_todos = list(tickets_qs)
    stats = _dashboard_metricas(tickets_todos)
    _, resueltos_qs = _dashboard_filtros(request, fecha_campo="fecha_resolucion")
    stats["resueltos_periodo"] = resueltos_qs.filter(estado__in=[Ticket.Estado.RESUELTO, Ticket.Estado.CERRADO]).count()
    stats["variacion_resueltos"] = _dashboard_comparacion_resueltos(request, filtros, stats["resueltos_periodo"])
    ahora = timezone.now()
    inicio_mes = ahora.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    inicio_mes_anterior = (inicio_mes - timedelta(days=1)).replace(day=1)

    def conteo_mes(consulta):
        return {
            "total": consulta.count(),
            "abiertos": consulta.filter(estado=Ticket.Estado.ABIERTO).count(),
            "progreso": consulta.filter(estado=Ticket.Estado.EN_PROGRESO).count(),
            "resueltos": consulta.filter(
                estado__in=[Ticket.Estado.RESUELTO, Ticket.Estado.CERRADO]
            ).count(),
        }

    mes_actual = conteo_mes(tickets_qs.filter(fecha_creacion__gte=inicio_mes))
    mes_anterior = conteo_mes(
        tickets_qs.filter(
            fecha_creacion__gte=inicio_mes_anterior,
            fecha_creacion__lt=inicio_mes,
        )
    )

    def variacion(actual, anterior):
        if not anterior:
            return {"texto": "Nuevo" if actual else "0%", "clase": "is-flat"}
        cambio = round((actual - anterior) / anterior * 100)
        if cambio > 0:
            return {"texto": f"+{cambio}%", "clase": "is-up"}
        if cambio < 0:
            return {"texto": f"{cambio}%", "clase": "is-down"}
        return {"texto": "0%", "clase": "is-flat"}
    tickets_abiertos_qs = tickets_qs.filter(estado__in=[Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO])
    tickets = list(
        tickets_abiertos_qs.annotate(
            _prioridad_orden=orden_prioridad_annotation()
        ).order_by("-fecha_creacion", "_prioridad_orden", "-pk")[:200]
    )
    pp_recientes = _resolve_per_page(request, "per_page_recientes", PER_PAGE_DEFECTO)
    recientes_page = paginate_recent_tickets(request, tickets_qs, per_page=pp_recientes)
    dashboard_context = _build_dashboard_context(request, tickets)
    recientes = _adjuntar_solicitantes(recientes_page.object_list)
    n_tecnicos = User.objects.filter(activo=True, rol__in=[User.Rol.TECNICO, User.Rol.ADMIN]).count()
    n_puntos = tickets_qs.exclude(solicitante_punto__isnull=True).exclude(solicitante_punto="").values("solicitante_punto").distinct().count()
    # Solo se compara cuando la base conserva el evento histórico necesario.
    # Técnicos, puntos y vencidos son estados actuales: no existe un snapshot
    # histórico de ellos, por lo que mostrar un porcentaje sería inventarlo.
    kpi_trends = [
        variacion(mes_actual["total"], mes_anterior["total"]),
        variacion(mes_actual["abiertos"], mes_anterior["abiertos"]),
        variacion(mes_actual["progreso"], mes_anterior["progreso"]),
        variacion(mes_actual["resueltos"], mes_anterior["resueltos"]),
        None,
        None,
        None,
    ]
    return render(
        request,
        "tickets/dashboard.html",
        {
            "stats": stats,
            "recientes": recientes,
            "recientes_page": recientes_page,
            "per_page_recientes": pp_recientes,
            "querystring": _params_sin_page(request, "page_recientes"),
            "dash_json": _build_tecnico_dashboard(consulta=tickets_qs),
            "alcances_tortas": _ALCANCES_TORTAS,
            "alcances_20dias": _ALCANCES_20_DIAS,
            "tecnicos_stats": _tecnicos_resumen(tickets_todos),
            "n_tecnicos": n_tecnicos,
            "n_puntos": n_puntos,
            "kpi_trends": kpi_trends,
            "kpi_sparks": {**_dashboard_sparks(tickets_todos), "resueltos_periodo": _dashboard_sparks_resueltos(resueltos_qs)},
            "atencion": _dashboard_atencion(tickets_todos),
            "filtros": filtros,
            "categorias_dashboard": Categoria.objects.filter(activo=True).order_by("nombre"),
            "tecnicos_dashboard": User.objects.filter(activo=True, rol__in=[User.Rol.TECNICO, User.Rol.ADMIN]).order_by("nombre"),
            "puntos_dashboard": tickets_qs.exclude(solicitante_punto__isnull=True).exclude(solicitante_punto="").values_list("solicitante_punto", flat=True).distinct().order_by("solicitante_punto"),
            "estados": Ticket.Estado.choices,
            "prioridades": Ticket.Prioridad.choices,
            **dashboard_context,
        },
    )


@admin_required
def dashboard_data_api(request):
    """Datos del dashboard para actualización parcial; no altera tickets ni sesión."""
    filtros, qs = _dashboard_filtros(request)
    tickets = list(qs)
    metricas = _dashboard_metricas(tickets)
    _, resueltos_qs = _dashboard_filtros(request, fecha_campo="fecha_resolucion")
    metricas["resueltos_periodo"] = resueltos_qs.filter(estado__in=[Ticket.Estado.RESUELTO, Ticket.Estado.CERRADO]).count()
    metricas["variacion_resueltos"] = _dashboard_comparacion_resueltos(request, filtros, metricas["resueltos_periodo"])
    metricas["tecnicos"] = User.objects.filter(
        activo=True, rol__in=[User.Rol.TECNICO, User.Rol.ADMIN]
    ).count()
    metricas["puntos"] = qs.exclude(solicitante_punto__isnull=True).exclude(
        solicitante_punto=""
    ).values("solicitante_punto").distinct().count()
    tecnicos_stats = _tecnicos_resumen(tickets)
    busqueda = (request.GET.get("busqueda_equipo") or "").strip()[:150].casefold()
    coincidencias = {
        ticket.tecnico_asignado_id for ticket in tickets
        if busqueda and (busqueda in (ticket.codigo or "").casefold()
                         or busqueda in (ticket.titulo or "").casefold())
    }
    for tecnico in tecnicos_stats:
        tecnico["oculto_busqueda"] = bool(busqueda and tecnico["id"] not in coincidencias
            and busqueda not in (tecnico["nombre"] or "").casefold()
            and busqueda not in (tecnico["email"] or "").casefold())
    return JsonResponse({
        "kpis": metricas,
        "sparks": {**_dashboard_sparks(tickets), "resueltos_periodo": _dashboard_sparks_resueltos(resueltos_qs)},
        "charts": json.loads(_build_tecnico_dashboard(consulta=qs)),
        "tecnicos_html": render_to_string("tickets/_dashboard_tecnicos_rows.html", {"tecnicos_stats": tecnicos_stats}, request=request),
        "updated_at": timezone.localtime().strftime("%H:%M"),
    })


def _paginar(qs, request, param="page", per_page_param="per_page", per_page_default=PER_PAGE_DEFECTO):
    allowed = PER_PAGE_OPCIONES
    try:
        pp = int(request.GET.get(per_page_param, per_page_default))
    except (ValueError, TypeError):
        pp = per_page_default
    if pp not in allowed:
        pp = per_page_default
    if pp == 0:
        pp = qs.count() or 1
    paginator = Paginator(qs, pp)
    numero = request.GET.get(param) or 1
    return paginator.get_page(numero)


def _resolve_per_page(request, param="per_page", default=PER_PAGE_DEFECTO):
    allowed = PER_PAGE_OPCIONES
    try:
        pp = int(request.GET.get(param, default))
    except (ValueError, TypeError):
        pp = default
    return pp if pp in allowed else default


def _params_sin_page(request, param="page"):
    params = request.GET.copy()
    params.pop(param, None)
    return params.urlencode()


def _adjuntar_solicitantes(tickets):
    """Adjunta a cada ticket su Usuario (para mostrar avatar/initials) según el correo del solicitante."""
    emails = {t.solicitante_email.lower() for t in tickets if t.solicitante_email}
    if not emails:
        return tickets
    usuarios = {
        u.email.lower(): u
        for u in get_user_model().objects.filter(email__in=list(emails))
    }
    for t in tickets:
        t.solicitante_usuario = usuarios.get((t.solicitante_email or "").lower())
    return tickets


def _tecnicos_resumen(tickets=None):
    """Resumen por técnico/admin activo: carga, ANS (vencidos/por vencer) y categorías.

    Permite al dashboard del administrador seguir el historial de cada técnico:
    cuántos tickets tiene a cargo, si están vencidos o por vencer, los resueltos/
    cerrados y qué categorías maneja.
    """
    tecnicos = {
        u.id: u
        for u in User.objects.filter(activo=True).filter(
            Q(rol__in=["tecnico", "admin"]) |
            Q(cambio_rol_habilitado=True, rol_base__in=["tecnico", "admin"])
        ).order_by("nombre")
    }
    agg = {
        uid: {
            "id": uid,
            "nombre": u.nombre or u.email,
            "email": u.email,
            "cambio_rol_habilitado": u.cambio_rol_habilitado,
            "rol_actual": u.get_rol_display(),
            "rol_base": u.get_rol_base_display() if u.rol_base else u.get_rol_display(),
            "rol_actual_codigo": u.rol,
            "rol_base_codigo": u.rol_base or u.rol,
            "rol_cambiado": bool(u.rol_base and u.rol_base != u.rol),
            "abrir": 0,
            "espera": 0,
            "vencido": 0,
            "riesgo": 0,
            "resueltos": 0,
            "cerrado": 0,
            "asignados": 0,
            "promedio_segundos": 0,
            "terminados": 0,
            "sla_ok": 0,
            "sla_total": 0,
            "categorias": set(),
        }
        for uid, u in tecnicos.items()
    }
    origen = list(tickets if tickets is not None else Ticket.objects.select_related("categoria", "tecnico_asignado"))
    evaluados = evaluar_lote(origen) if origen else {}
    operativos = evaluar_lote(origen, permitir_provisional=True) if origen else {}
    for t in origen:
        tid = t.tecnico_asignado_id
        if not tid or tid not in agg:
            continue
        r = agg[tid]
        r["asignados"] += 1
        resultado_ans = evaluados[t.pk]
        if resultado_ans.estado != "sin_informacion":
            r["sla_total"] += 1
            if resultado_ans.estado in ("vigente", "por_vencer", "cumplido"):
                r["sla_ok"] += 1
        final = t.fecha_finalizacion
        if final and t.fecha_creacion and final >= t.fecha_creacion:
            r["promedio_segundos"] += (final - t.fecha_creacion).total_seconds()
            r["terminados"] += 1
        if t.estado == Ticket.Estado.ABIERTO:
            r["abrir"] += 1
        elif t.estado == Ticket.Estado.EN_PROGRESO:
            r["espera"] += 1
        elif t.estado == Ticket.Estado.RESUELTO:
            r["resueltos"] += 1
        elif t.estado == Ticket.Estado.CERRADO:
            r["cerrado"] += 1
        if t.estado in (Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO):
            ans = operativos[t.pk].estado
            if ans == "vencido":
                r["vencido"] += 1
            elif ans == "por_vencer":
                r["riesgo"] += 1
            if t.categoria_id:
                r["categorias"].add(
                    f"{t.categoria.grupo or ''} › {t.categoria.nombre or ''}".strip(" ›") or "Sin categoría"
                )
            else:
                r["categorias"].add("Sin categoría")
    resumen = []
    for r in agg.values():
        r["categorias"] = sorted(r["categorias"])
        r["promedio_resolucion"] = (
            formatear_duracion(timedelta(seconds=r["promedio_segundos"] / r["terminados"]))
            if r["terminados"] else None
        )
        r["sla_pct"] = round(r["sla_ok"] * 100 / r["sla_total"]) if r["sla_total"] else None
        resumen.append(r)
    return resumen


def _cat_label(t):
    if t.categoria_id:
        return f"{t.categoria.grupo or ''} › {t.categoria.nombre or ''}".strip(" ›") or "Sin categoría"
    return "Sin categoría"


@admin_required
def tec_tickets_api(request, pk):
    """Tickets asignados a un técnico, para la tarjeta 'Técnicos' del panel admin."""
    tec = get_object_or_404(User, pk=pk)
    qs = (
        Ticket.objects.filter(tecnico_asignado=tec)
        .select_related("categoria")
        .order_by("-fecha_creacion")
    )
    tickets = []
    origen = list(qs)
    resultados_ans = evaluar_lote(origen, permitir_provisional=True)
    for t in origen:
        ans = t.datos_ans_desde_resultado(resultados_ans[t.pk])[0]
        tickets.append(
            {
                "id": t.pk,
                "codigo": t.codigo,
                "titulo": t.titulo,
                "prioridad": t.get_prioridad_display(),
                "estado": t.estado,
                "estado_label": t.get_estado_display(),
                "categoria": _cat_label(t),
                "ans": ans,
                "solicitante": (t.solicitante_nombre or t.solicitante_email or "Sin datos"),
                "detalle_url": reverse("tickets:detalle", args=[t.pk]),
            }
        )
    return JsonResponse(
        {
            "nombre": tec.nombre or tec.email,
            "email": tec.email,
            "total": qs.count(),
            "tickets": tickets,
        }
    )


@staff_required
def sin_asignar(request):
    """Bandeja de solicitudes sin técnico asignado.

    El administrador asigna cada solicitud a un técnico; el técnico puede
    'tomar' las que queden disponibles (auto-asignación).
    """
    es_admin = request.user.rol == "admin"
    abiertos = [Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO]
    base = (
        Ticket.objects.select_related("categoria", "tecnico_asignado")
        .filter(estado__in=abiertos, tecnico_asignado__isnull=True)
        .order_by("-fecha_creacion")
    )
    tecnicos = (
        get_user_model()
        .objects.filter(activo=True, is_active=True, rol__in=["admin", "tecnico"])
        .order_by("nombre", "pk")
    )

    if request.method == "POST":
        pk_raw = request.POST.get("ticket_id", "")
        try:
            ticket = base.get(pk=int(pk_raw))
        except (TypeError, ValueError, Ticket.DoesNotExist):
            messages.error(request, "No se encontró la solicitud indicada.")
            return redirect("tickets:sin_asignar")
        accion = request.POST.get("action", "").strip()
        if accion == "asignar" and es_admin:
            valor = request.POST.get("tecnico", "").strip()
            if valor.isdigit():
                tec = tecnicos.filter(pk=int(valor)).first()
                if not tec:
                    messages.error(request, "El técnico seleccionado no es válido.")
                    return redirect("tickets:sin_asignar")
            else:
                tec = None
            ticket, _ = asignar_manual(ticket.pk, tec)
            if tec:
                try:
                    if sync_asignacion_to_glpi(ticket):
                        messages.success(request, f"{ticket.codigo} asignado a {tec.nombre} (también en GLPI).")
                    else:
                        messages.success(request, f"{ticket.codigo} asignado a {tec.nombre}.")
                except GlpiError as exc:
                    messages.warning(request, f"{ticket.codigo} asignado a {tec.nombre}; no se reflejó en GLPI: {exc}")
            else:
                messages.success(request, f"{ticket.codigo} quedó sin técnico (por si otro lo toma).")
            return redirect("tickets:sin_asignar")
        if accion == "tomar":
            ticket, tomado = asignar_manual(ticket.pk, request.user, solo_sin_asignar=True)
            if not tomado:
                messages.warning(request, "La solicitud ya fue asignada por otro usuario.")
                return redirect("tickets:sin_asignar")
            if request.user.glpi_user_id:
                try:
                    if sync_asignacion_to_glpi(ticket):
                        messages.success(request, f"Ticket {ticket.codigo} tomado (también en GLPI).")
                    else:
                        messages.success(request, f"Ticket {ticket.codigo} tomado.")
                except GlpiError as exc:
                    messages.warning(request, f"Ticket {ticket.codigo} tomado localmente; no se reflejó en GLPI: {exc}")
            else:
                messages.success(request, f"Ticket {ticket.codigo} tomado. Configura tu 'ID usuario GLPI' en Admin para reflejarlo allá.")
            return redirect("tickets:sin_asignar")
        messages.error(request, "Acción no permitida.")
        return redirect("tickets:sin_asignar")

    pp_mp = _resolve_per_page(request, "per_page", PER_PAGE_DEFECTO)
    page_obj = _paginar(base, request, param="page", per_page_default=pp_mp)
    return render(
        request,
        "tickets/sin_asignar.html",
        {
            "es_admin": es_admin,
            "tickets": page_obj.object_list,
            "page_obj": page_obj,
            "tecnicos": tecnicos,
            "per_page": pp_mp,
            "querystring": _params_sin_page(request),
            "pendientes": _sin_revisar(request.user),
        },
    )


def _ticket_kpis_historico(scope_qs):
    """Series reales de siete días para los indicadores de la bandeja.

    Cada serie toma la fecha que representa el evento: creación para los
    tickets que siguen abiertos/en curso/sin asignar; resolución o cierre
    para los terminados. No se generan patrones decorativos cuando no hay
    actividad registrada.
    """
    hoy = timezone.localdate()
    inicio = hoy - timedelta(days=13)
    fechas = [inicio + timedelta(days=indice) for indice in range(14)]
    series = {clave: [0] * 14 for clave in (
        "total", "abiertas", "progreso", "resueltas", "cerradas", "sin_asignar"
    )}
    # El queryset de Reportes carga relaciones para tablas y gráficas. Esta
    # consulta histórica solo requiere campos del ticket; quitarlas antes de
    # usar `only()` evita diferir una FK que Django intentaría recorrer.
    eventos = scope_qs.select_related(None).filter(
        Q(fecha_creacion__date__gte=inicio)
        | Q(fecha_resolucion__date__gte=inicio)
        | Q(fecha_cierre__date__gte=inicio)
    ).only("fecha_creacion", "fecha_resolucion", "fecha_cierre", "estado", "tecnico_asignado_id")

    def sumar(clave, momento):
        if not momento:
            return
        dia = timezone.localtime(momento).date() if timezone.is_aware(momento) else momento.date()
        try:
            series[clave][fechas.index(dia)] += 1
        except ValueError:
            pass

    for ticket in eventos:
        sumar("total", ticket.fecha_creacion)
        if ticket.estado == Ticket.Estado.ABIERTO:
            sumar("abiertas", ticket.fecha_creacion)
        if ticket.estado == Ticket.Estado.EN_PROGRESO:
            sumar("progreso", ticket.fecha_creacion)
        if ticket.fecha_resolucion or ticket.estado == Ticket.Estado.RESUELTO:
            sumar("resueltas", ticket.fecha_resolucion or ticket.fecha_cierre or ticket.fecha_creacion)
        if ticket.estado == Ticket.Estado.CERRADO:
            sumar("cerradas", ticket.fecha_cierre or ticket.fecha_creacion)
        if ticket.estado in (Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO) and not ticket.tecnico_asignado_id:
            sumar("sin_asignar", ticket.fecha_creacion)

    tendencias = {}
    for clave, valores in series.items():
        anterior, actual = sum(valores[:7]), sum(valores[7:])
        if not anterior and not actual:
            tendencias[clave] = None
            continue
        if not anterior:
            tendencias[clave] = {"texto": "Nuevo", "clase": "is-flat"}
            continue
        cambio = round((actual - anterior) / anterior * 100)
        # El color expresa impacto operativo, no solo el signo matemático:
        # más resueltas/cerradas es favorable; más pendientes no lo es.
        if clave == "total" or not cambio:
            clase = "is-flat"
        elif clave in ("resueltas", "cerradas"):
            clase = "is-down" if cambio > 0 else "is-up"
        else:
            clase = "is-up" if cambio > 0 else "is-down"
        tendencias[clave] = {
            "texto": f"{cambio:+d}%" if cambio else "0%",
            "clase": clase,
        }
    return {
        "labels": [dia.strftime("%d/%m") for dia in fechas[7:]],
        "series": {clave: valores[7:] for clave, valores in series.items()},
        "tendencias": tendencias,
    }


def _tecnico_actividad_graficas(scope_qs):
    """Últimos días con creación o resolución de tickets asignados."""
    eventos = list(scope_qs.select_related(None).only("fecha_creacion", "fecha_resolucion", "fecha_cierre", "estado", "tecnico_asignado_id"))
    fechas = sorted({dia for ticket in eventos for dia in (_key_fecha(ticket.fecha_creacion), _key_fecha(ticket.fecha_resolucion), _key_fecha(ticket.fecha_cierre)) if dia})[-7:]
    series = {clave: [0] * len(fechas) for clave in ("total", "abiertas", "progreso", "resueltas", "cerradas", "sin_asignar")}
    indices = {dia: i for i, dia in enumerate(fechas)}
    for ticket in eventos:
        creado, resuelto = _key_fecha(ticket.fecha_creacion), _key_fecha(ticket.fecha_resolucion)
        if creado in indices:
            i = indices[creado]
            series["total"][i] += 1
            if ticket.estado == Ticket.Estado.ABIERTO:
                series["abiertas"][i] += 1
            elif ticket.estado == Ticket.Estado.EN_PROGRESO:
                series["progreso"][i] += 1
            if ticket.estado in (Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO) and not ticket.tecnico_asignado_id:
                series["sin_asignar"][i] += 1
        if resuelto in indices:
            series["resueltas"][indices[resuelto]] += 1
        cerrado = _key_fecha(ticket.fecha_cierre)
        if ticket.estado == Ticket.Estado.CERRADO and cerrado in indices:
            series["cerradas"][indices[cerrado]] += 1
    return {"labels": [dia.strftime("%d/%m/%Y") for dia in fechas], "series": series}


@staff_required
def lista_tickets(request):
    """Lista unificada de tickets: el admin ve todos, el técnico solo los suyos."""
    es_admin = request.user.rol == "admin"
    qs = Ticket.objects.select_related("categoria", "tecnico_asignado").annotate(
        adjuntos_count=Count("adjuntos")
    )
    if not es_admin:
        qs = qs.filter(tecnico_asignado=request.user)

    scope_qs = Ticket.objects.all() if es_admin else qs
    stats = scope_qs.aggregate(
        total=Count("pk"),
        abiertas=Count("pk", filter=Q(estado=Ticket.Estado.ABIERTO)),
        progreso=Count("pk", filter=Q(estado=Ticket.Estado.EN_PROGRESO)),
        # El chip cuenta lo mismo que el filtro "Resueltas": los que tienen
        # la marca de resolución.
        resueltas=Count("pk", filter=Q(fecha_resolucion__isnull=False)),
        cerradas=Count("pk", filter=Q(estado=Ticket.Estado.CERRADO)),
    )
    stats["sin_asignar"] = (
        Ticket.objects.filter(
            estado__in=[Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO],
            tecnico_asignado__isnull=True,
        ).count()
    )
    kpi_historico = _ticket_kpis_historico(scope_qs)
    kpi_historico.update(_tecnico_actividad_graficas(scope_qs))

    estado = request.GET.get("estado", "").strip()
    prioridad = request.GET.get("prioridad", "").strip()
    categoria = request.GET.get("categoria", "").strip()
    tecnico = request.GET.get("tecnico", "").strip() if es_admin else ""
    q = (request.GET.get("q", "") or "")[:120].strip()
    solicitante_email = request.GET.get("solicitante_email", "").strip()
    zona = request.GET.get("zona", "").strip()[:80]
    presets_mis = list(PRESETS_MIS)
    presets_mis_map = dict(presets_mis)
    sv = request.GET.get("sv", "todas").strip()
    if sv not in presets_mis_map:
        sv = "todas"
    rangos_mis = list(RANGOS_MIS)
    rango = request.GET.get("rango", "").strip()
    if rango not in dict(rangos_mis):
        rango = ""
    mias = request.GET.get("mias", "") in ("1", "true", "on")

    def url_kpi(**cambios):
        """Conserva los filtros de la bandeja al abrir un KPI."""
        parametros = request.GET.copy()
        parametros.pop("page", None)
        parametros.pop("estado", None)
        parametros.pop("sv", None)
        for clave, valor in cambios.items():
            parametros[clave] = valor
        query = parametros.urlencode()
        base = reverse("tickets:lista")
        return f"{base}?{query}" if query else base

    kpi_urls = {
        "total": url_kpi(),
        "abiertas": url_kpi(estado=Ticket.Estado.ABIERTO),
        "progreso": url_kpi(estado=Ticket.Estado.EN_PROGRESO),
        "resueltas": url_kpi(estado=Ticket.Estado.RESUELTO),
        "cerradas": url_kpi(estado=Ticket.Estado.CERRADO),
        "sin_asignar": url_kpi(sv="no-asignadas"),
    }

    abiertos = [Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO]
    if sv == "pendientes":
        qs = qs.filter(estado__in=abiertos)
    elif sv == "completadas":
        qs = qs.filter(estado__in=[Ticket.Estado.RESUELTO, Ticket.Estado.CERRADO])
    elif sv == "abiertas":
        qs = qs.filter(estado=Ticket.Estado.ABIERTO)
    elif sv == "espera":
        qs = qs.filter(estado=Ticket.Estado.ABIERTO)
    elif sv == "no-asignadas":
        qs = qs.filter(estado__in=abiertos, tecnico_asignado__isnull=True)
    elif sv == "creadas-hoy":
        inicio_hoy = timezone.localtime(timezone.now()).replace(
            hour=0, minute=0, second=0, microsecond=0
        )
        qs = qs.filter(fecha_creacion__gte=inicio_hoy)
    elif sv in ("vencen-hoy", "vencidas"):
        qs = qs.filter(estado__in=abiertos)
    elif sv == "abiertas":
        qs = qs.filter(estado__in=abiertos)

    if rango:
        try:
            qs = qs.filter(
                **{("fecha_resolucion__gte" if request.GET.get("fecha_resolucion_periodo") == "1" else "fecha_creacion__gte"): timezone.now() - timedelta(days=int(rango))}
            )
        except (TypeError, ValueError):
            pass
    if mias:
        qs = qs.filter(tecnico_asignado=request.user)

    qs = _filtrar_estado(qs, estado)
    if prioridad:
        if prioridad == "alta,urgente":
            qs = qs.filter(
                estado__in=abiertos,
                prioridad__in=[Ticket.Prioridad.ALTA, Ticket.Prioridad.URGENTE],
            )
        else:
            qs = qs.filter(prioridad=prioridad)
    if categoria:
        qs = qs.filter(categoria_id=categoria)
    if tecnico:
        qs = qs.filter(tecnico_asignado_id=tecnico)
    if solicitante_email:
        qs = qs.filter(solicitante_email__iexact=solicitante_email)
    if zona:
        qs = qs.filter(solicitante_punto__iexact=zona)
    punto_dashboard = request.GET.get("punto", "").strip()[:150]
    if punto_dashboard:
        qs = qs.filter(solicitante_punto=punto_dashboard)
    if q:
        match_codigo = re.match(r"^(?:HD|DG-[A-Z]{2})-\d+$", q.upper())
        condicion = (
            Q(codigo__iexact=q.upper())
            | Q(titulo__icontains=q)
            | Q(solicitante_nombre__icontains=q)
            | Q(solicitante_email__icontains=q)
        )
        if match_codigo:
            condicion = Q(codigo__iexact=q.upper()) | Q(titulo__icontains=q) | Q(solicitante_nombre__icontains=q)
        qs = qs.filter(condicion)

    # La bandeja prioriza densidad legible: cinco filas como valor inicial.
    pp_lista = _resolve_per_page(request, "per_page", 5)
    if q or sv in ("vencen-hoy", "vencidas"):
        pp_lista = 0
    page_obj = _paginar(
        qs.annotate(_prioridad_orden=orden_prioridad_annotation()).order_by(
            "-fecha_creacion", "_prioridad_orden", "-pk"
        ),
        request,
        per_page_default=pp_lista,
    )

    filtros_activos = any([estado, prioridad, categoria, tecnico, q, solicitante_email, zona, sv != "todas", rango, mias])
    tickets = _adjuntar_solicitantes(page_obj.object_list)
    if sv in ("vencen-hoy", "vencidas"):
        tickets = list(tickets)
        ahora = timezone.now()
        resultados_ans = evaluar_lote(tickets, ahora=ahora, permitir_provisional=True)
    if sv == "vencen-hoy":
        inicio_hoy = timezone.localtime(ahora).replace(
            hour=0, minute=0, second=0, microsecond=0
        )
        fin_hoy = inicio_hoy + timedelta(days=1)
        tickets = [
            t
            for t in tickets
            if t.estado in abiertos
            and resultados_ans[t.pk].limite
            and inicio_hoy <= resultados_ans[t.pk].limite < fin_hoy
        ]
    elif sv == "vencidas":
        tickets = [
            t
            for t in tickets
            if t.estado in abiertos
            and resultados_ans[t.pk].estado == "vencido"
        ]
    return render(
        request,
        "tickets/lista.html",
        {
            "tickets": tickets,
            "page_obj": page_obj,
            "querystring": _params_sin_page(request),
            "filtros_activos": filtros_activos,
            "filtro_estado": estado,
            "filtro_prioridad": prioridad,
            "filtro_categoria": categoria,
            "filtro_tecnico": tecnico,
            "filtro_zona": zona,
            "q": q,
            "estados": Ticket.Estado.choices,
            "prioridades": Ticket.Prioridad.choices,
            "categorias": Categoria.objects.filter(activo=True).order_by("grupo", "nombre"),
            "tecnicos": User.objects.filter(
                activo=True, rol__in=["admin", "tecnico"]
            ).order_by("nombre"),
            "presets_mis": presets_mis,
            "sv": sv,
            "rangos_mis": rangos_mis,
            "rango": rango,
            "mias": mias,
            "stats": stats,
            "ticket_kpi_historico": kpi_historico,
            "ticket_kpi_urls": kpi_urls,
            "total_resultados": (
                len(tickets) if sv in ("vencen-hoy", "vencidas") else page_obj.paginator.count
            ),
            "es_admin": es_admin,
            "per_page": pp_lista,
        },
    )


@staff_required
def detalle_ticket(request, pk):
    ticket = get_object_or_404(
        Ticket.objects.select_related("categoria", "tecnico_asignado").prefetch_related(
            "adjuntos", "comentarios", "comentarios__usuario"
        ),
        pk=pk,
    )
    comentario_form = ComentarioForm()
    asignar_form = AsignarTecnicoForm(initial={"tecnico": ticket.tecnico_asignado_id})

    if request.method == "POST":
        action = request.POST.get("action")
        if action == "comentario":
            comentario_form = ComentarioForm(request.POST)
            if comentario_form.is_valid():
                c = comentario_form.save(commit=False)
                c.ticket = ticket
                c.usuario = request.user
                c.autor_nombre = request.user.nombre
                c.save()
                notificar_comentario(
                    ticket, request.user.nombre, c.comentario, c.es_interno, actor=request.user
                )
                messages.success(request, "Seguimiento agregado")
                return redirect("tickets:detalle", pk=pk)
        elif action == "asignar":
            asignar_form = AsignarTecnicoForm(request.POST)
            if asignar_form.is_valid():
                ticket, _ = asignar_manual(ticket.pk, asignar_form.cleaned_data["tecnico"])
                if ticket.tecnico_asignado_id:
                    try:
                        if sync_asignacion_to_glpi(ticket):
                            messages.success(request, "Tecnico actualizado (también en GLPI)")
                        else:
                            messages.success(
                                request,
                                "Tecnico actualizado"
                                + (
                                    ""
                                    if ticket.tecnico_asignado.glpi_user_id
                                    else " · configura su 'ID usuario GLPI' en Admin para reflejarlo en GLPI"
                                ),
                            )
                    except GlpiError as exc:
                        messages.warning(
                            request, f"Técnico guardado localmente, pero no se reflejó en GLPI: {exc}"
                        )
                else:
                    messages.success(request, "Tecnico actualizado")
                return redirect("tickets:detalle", pk=pk)

    timeline_data_ = _timeline_ticket(ticket, include_internos=True)
    from django.contrib.auth import get_user_model
    cuenta_solicitante = (
        get_user_model().objects.filter(email__iexact=ticket.solicitante_email).first()
        if ticket.solicitante_email else None
    )
    vinculo_principal = (
        TicketVinculo.objects.filter(ticket_secundario=ticket)
        .select_related("ticket_principal", "ticket_principal__categoria", "creado_por")
        .first()
    )
    vinculos_secundarios = list(
        TicketVinculo.objects.filter(ticket_principal=ticket)
        .select_related("ticket_secundario", "ticket_secundario__categoria", "creado_por")
        .order_by("fecha")
    )
    return render(
        request,
        "tickets/detalle.html",
        {
            "ticket": ticket,
            "timeline": timeline_data_,
            "ans_ajuste_clave": secrets.token_hex(24),
            "cuenta_solicitante": cuenta_solicitante,
            "eventos_count": sum(1 for i in timeline_data_ if i["tipo"] == "sistema"),
            "comentario_form": comentario_form,
            "asignar_form": asignar_form,
            "vinculo_principal": vinculo_principal,
            "vinculos_secundarios": vinculos_secundarios,
            "share_text": f"Ticket {ticket.codigo} — {ticket.titulo} ({ticket.get_estado_display()})",
        },
    )


@staff_required
def ticket_estado_ajax(request, pk):
    ticket = get_object_or_404(Ticket, pk=pk)
    return JsonResponse({"ok": True, "estado": ticket.estado})


@staff_required
@require_POST
def cambiar_estado(request, pk):
    ticket = get_object_or_404(Ticket, pk=pk)
    nuevo = request.POST.get("estado")
    validos = {c[0] for c in Ticket.Estado.choices}
    if nuevo not in validos:
        messages.error(request, "Estado no valido.")
    elif ticket.estado in (Ticket.Estado.RESUELTO, Ticket.Estado.CERRADO) and nuevo in (Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO):
        messages.error(request, "Las solicitudes finalizadas no pueden volver a abrirse.")
    else:
        from .services.transiciones_ans import cambiar_estado_ans, EstadoTicketModificado
        try:
            ticket = cambiar_estado_ans(ticket.pk, nuevo, actor=request.user,
                                        estado_esperado=ticket.estado,
                                        resolver_y_cerrar=nuevo == Ticket.Estado.RESUELTO)
        except EstadoTicketModificado:
            messages.error(request, "El ticket cambió; actualiza la página e inténtalo de nuevo.")
            return redirect(_destino_seguro(request, "tickets:lista"))
        if nuevo == Ticket.Estado.RESUELTO:
            aviso = f"{ticket.codigo} quedó resuelto y cerrado."
        else:
            aviso = f"{ticket.codigo} → {ticket.get_estado_display()}"
        notificar_ticket_actualizado(ticket, f"cambiado a {ticket.get_estado_display()}", actor=request.user)
        try:
            sync_estado_to_glpi(ticket)
        except GlpiError as exc:
            messages.warning(request, f"No se pudo actualizar el estado en GLPI: {exc}")
            logger.warning("GLPI estado sync: %s", exc)
        messages.success(request, aviso)
    return redirect(_destino_seguro(request, "tickets:lista"))


@admin_required
@require_POST
def ajustar_ans_ticket(request, pk):
    from django.utils.dateparse import parse_datetime
    from .services.transiciones_ans import ajustar_plazo_ans, EstadoTicketModificado
    get_object_or_404(Ticket, pk=pk)
    try:
        fecha = parse_datetime(request.POST.get("limite", ""))
        if fecha and timezone.is_naive(fecha):
            fecha = timezone.make_aware(fecha, timezone.get_current_timezone())
        version = int(request.POST.get("version", ""))
        ajustar_plazo_ans(pk, fecha, actor=request.user, motivo=request.POST.get("motivo"),
                          clave=request.POST.get("clave"), version_esperada=version)
        messages.success(request, "El ajuste ANS quedó registrado.")
    except (ValueError, ValidationError, EstadoTicketModificado):
        messages.error(request, "No se pudo registrar el ajuste. Revisa los datos o actualiza la página.")
    return redirect("tickets:detalle", pk=pk)


def _destino_seguro(request, nombre_ruta):
    destino = (request.POST.get("next") or "").strip()
    if destino.startswith("/") and url_has_allowed_host_and_scheme(destino, {request.get_host()}, require_https=request.is_secure()):
        return destino
    return reverse(nombre_ruta)


def _es_dueno(ticket, user):
    """El ticket le pertenece a la persona que lo reportó."""
    return bool(getattr(user, "email", None)) and ticket.solicitante_email == user.email


def _puede_gestionar_papelera(request, ticket):
    """Staff (admin/técnico) o el propio solicitante pueden restaurar/purgar.

    Antes solo el administrador podía tocar la papelera, así que un usuario
    que cancelaba una solicitud se quedaba sin poder recuperarla.
    """
    if getattr(request.user, "es_staff_helpdesk", False):
        return True
    return _es_dueno(ticket, request.user)


@login_required
@require_POST
def eliminar_ticket(request, pk):
    """Borrado lógico: el ticket va a la papelera y se puede restaurar.

    Ya no se borra en duro ni se tocan los adjuntos: la purga definitiva
    vive en la papelera (`purgar_ticket`), que sí elimina en GLPI si está
    configurado. Así "eliminar" deja de ser irreversible.

    El solicitante también puede cancelar el suyo: antes le salía un 403 y
    desde Mi panel no había forma de deshacerlo.
    """
    ticket = get_object_or_404(Ticket, pk=pk)
    if not _puede_gestionar_papelera(request, ticket):
        raise PermissionDenied("Solo puedes eliminar tus propias solicitudes.")
    motivo = request.POST.get("motivo_eliminacion", "").strip()
    if len(motivo) > 2000:
        messages.error(request, "El motivo no puede superar los 2000 caracteres.")
        return redirect(_destino_seguro(request, "tickets:lista"))
    codigo = ticket.codigo
    had_glpi = bool(ticket.glpi_id)
    with transaction.atomic():
        if motivo:
            TicketComentario.objects.create(ticket=ticket, usuario=request.user,
                autor_nombre=request.user.nombre, comentario="Motivo de envío a la papelera: " + motivo,
                es_interno=True)
        ticket.mandar_a_la_papelera(request.user)
    mensaje = f"Ticket {codigo} enviado a la papelera."
    if had_glpi:
        mensaje += " Se conserva en GLPI hasta que se purge definitivamente."
    messages.success(request, mensaje)
    return redirect(_destino_seguro(request, "tickets:lista"))


@user_required
def mi_papelera(request):
    """Papelera del solicitante: solo sus propias solicitudes eliminadas.

    Es el mismo criterio de la papelera del administrador (borrado lógico,
    restaurable, sin contar en el panel), pero acotada a lo suyo para que
    pueda recuperar sin pedirle permiso a nadie.
    """
    q = (request.GET.get("q", "") or "")[:120].strip()
    base = (
        Ticket.en_papelera()
        .filter(solicitante_email=request.user.email)
        .select_related("tecnico_asignado", "categoria")
        .order_by("-eliminado_en")
    )
    if q:
        # Búsqueda por palabras separadas: cada término debe coincidir.
        for palabra in q.split():
            base = base.filter(
                Q(codigo__icontains=palabra) | Q(titulo__icontains=palabra)
            )
    total = base.count()
    page_obj = _paginar(base, request, per_page_default=10)
    return render(
        request,
        "tickets/mi_papelera.html",
        {
            "page_obj": page_obj,
            "tickets": page_obj.object_list,
            "total": total,
            "mi_papelera_total": total,  # el context processor lo omite en esta vista
            "q": q,
        },
    )


@staff_required
def papelera(request):
    """Papelera de reciclaje: tickets eliminados que aún se pueden restaurar.

    Están aquí el administrador y el técnico, que es quien a veces tiene que
    deshacer un borrado suyo o de otro. El punto de venta no entra a esta
    vista: la suya es `mi_papelera`, que solo muestra lo que él canceló.
    """
    q = (request.GET.get("q", "") or "")[:120].strip()
    base = (
        Ticket.en_papelera()
        .select_related("tecnico_asignado", "categoria", "eliminado_por")
        .order_by("-eliminado_en")
    )
    if q:
        # Búsqueda por palabras separadas: cada término debe coincidir
        for palabra in q.split():
            base = base.filter(
                Q(codigo__icontains=palabra)
                | Q(titulo__icontains=palabra)
                | Q(solicitante_email__icontains=palabra)
                | Q(solicitante_nombre__icontains=palabra)
            )
    total = base.count()
    page_obj = _paginar(base, request, per_page_default=10)
    return render(
        request,
        "tickets/papelera.html",
        {
            "page_obj": page_obj,
            "tickets": page_obj.object_list,
            "total": total,
            "papelera_total": total,  # el context processor lo omite en esta vista
            "q": q,
            "nav_papelera": True,
        },
    )


@login_required
@require_POST
def restaurar_ticket(request, pk):
    """Saca el ticket de la papelera y lo devuelve a la operación.

    Lo puede hacer el staff o el solicitante del ticket: si uno se arrepiente
    de cancelar una solicitud, no tiene que esperar a que un administrador se
    lo restaure.
    """
    ticket = get_object_or_404(Ticket.en_papelera(), pk=pk)
    if not _puede_gestionar_papelera(request, ticket):
        raise PermissionDenied("Solo puedes restaurar tus propias solicitudes.")
    codigo = ticket.codigo
    ticket.restaurar()
    messages.success(request, f"Ticket {codigo} restaurado.")
    return redirect(_destino_seguro(request, "tickets:papelera"))


@login_required
@require_POST
def purgar_ticket(request, pk):
    """Elimina DEFINITIVAMENTE el ticket. Irreversible: por eso vive en la papelera."""
    ticket = get_object_or_404(Ticket.en_papelera(), pk=pk)
    if not _puede_gestionar_papelera(request, ticket):
        raise PermissionDenied("Solo puedes eliminar definitivamente tus propias solicitudes.")
    codigo = ticket.codigo
    glpi_id = ticket.glpi_id
    es_dueno = not getattr(request.user, "es_staff_helpdesk", False)
    borrar_en_glpi = bool(getattr(request.user, "borrar_glpi_al_eliminar", False))
    aviso_glpi = None
    if borrar_en_glpi and glpi_id:
        client = GlpiClient()
        if client.available:
            try:
                client.init_session()
                client.delete_ticket(glpi_id)
            except GlpiError as exc:
                aviso_glpi = str(exc)
            except Exception as exc:
                aviso_glpi = f"error inesperado: {exc}"
            finally:
                client.kill_session()
    for adj in ticket.adjuntos.all():
        if adj.archivo:
            adj.archivo.delete(save=False)
    ticket.delete()
    mensaje = f"Ticket {codigo} eliminado definitivamente."
    if es_dueno:
        # El interruptor "borrar también en GLPI" es del staff: el solicitante
        # borra su copia de Dogger y el ticket sigue existiendo en GLPI.
        if glpi_id:
            mensaje += " El registro de GLPI se conserva."
    elif borrar_en_glpi:
        if glpi_id:
            mensaje += " También se eliminó en GLPI." if not aviso_glpi else f" GLPI local (no se sincronizó: {aviso_glpi})."
        else:
            mensaje += " No tenía registro en GLPI."
    messages.success(request, mensaje)
    return redirect(_destino_seguro(request, "tickets:papelera"))


@login_required
def ver_adjunto(request, pk):
    """Sirve un adjunto con permiso y disposición segura.

    Solo staff o el dueño del ticket (antes era staff sin revisar el
    ticket, y el resto del sitio enlazaba el archivo directo sin auth).
    Las imágenes raster se muestran inline para la vista previa; SVG y
    el resto fuerzan descarga para que nada se ejecute en el navegador
    (`?descargar=1` lo fuerza siempre).
    """
    adj = get_object_or_404(TicketAdjunto.objects.select_related("ticket"), pk=pk)
    ticket = adj.ticket
    u = request.user
    correo_ticket = (ticket.solicitante_email or "").strip().casefold()
    correo_usuario = (getattr(u, "email", "") or "").strip().casefold()
    es_dueno = bool(correo_ticket and correo_usuario and correo_ticket == correo_usuario)
    # El observador también abre los adjuntos de los tickets que ve en su
    # monitoreo (sus puntos o su lista); si no, la ficha le mostraba el
    # enlace y al pulsarlo recibía 404.
    es_observador = False
    if getattr(u, "rol", None) == "observador":
        from .views_observador import puntos_del_observador

        puntos = puntos_del_observador(u)
        es_observador = bool(
            (ticket.solicitante_punto or "") in puntos
            or (
                ticket.solicitante_email
                and ElementoMiLista.objects.filter(
                    observador=u, usuario_email__iexact=ticket.solicitante_email
                ).exists()
            )
        )
    if not (getattr(u, "es_staff_helpdesk", False) or es_dueno or es_observador):
        raise Http404("Archivo no encontrado")
    if not adj.archivo:
        raise Http404("Archivo no encontrado en disco")
    mime = (adj.mime_type or "application/octet-stream").lower().strip()
    imagenes_seguras = {"image/png", "image/jpeg", "image/gif", "image/webp"}
    forzar = request.GET.get("descargar") == "1" or mime not in imagenes_seguras
    if mime not in imagenes_seguras and mime != "application/pdf":
        mime = "application/octet-stream"
    try:
        return FileResponse(
            adj.archivo.open("rb"),
            content_type=mime,
            as_attachment=forzar,
            filename=adj.nombre_original,
        )
    except FileNotFoundError:
        raise Http404("Archivo no encontrado en disco")


# ---------------------------------------------------------------------------
# Mi panel corporativo — endpoints AJAX (editar / ver respuestas / cerrar)
# ---------------------------------------------------------------------------
def _mi_ticket_del_usuario(request, pk):
    return get_object_or_404(
        Ticket.objects.select_related("categoria"),
        pk=pk,
        solicitante_email=request.user.email,
    )


def _respuestas_para(ticket, include_internos=False):
    """Historial de mensajes del ticket (comentarios de soporte + del usuario)."""
    items = []
    for c in ticket.comentarios.order_by("fecha"):
        if c.es_interno:
            if not include_internos:
                continue
            rol = "interno"
            autor = c.autor_nombre or (c.usuario.nombre if c.usuario_id else "Staff")
            items.append(
                {
                    "rol": rol,
                    "autor": autor,
                    "fecha": c.fecha.isoformat() if c.fecha else "",
                    "fecha_label": c.fecha.strftime("%d/%m/%Y %H:%M") if c.fecha else "",
                    "texto": c.comentario,
                }
            )
            continue
        rol = "soporte"
        autor = c.autor_nombre or (c.usuario.nombre if c.usuario_id else "Mesa de ayuda")
        if c.usuario_id and getattr(c.usuario, "rol", None) == "usuario":
            rol = "usuario"
        items.append(
            {
                "rol": rol,
                "autor": autor,
                "fecha": c.fecha.isoformat() if c.fecha else "",
                "fecha_label": c.fecha.strftime("%d/%m/%Y %H:%M") if c.fecha else "",
                "texto": c.comentario,
            }
        )
    for ev in ticket.eventos_glpi.order_by("fecha"):
        items.append(
            {
                "rol": "sistema",
                "autor": "GLPI",
                "fecha": ev.fecha.isoformat() if ev.fecha else "",
                "fecha_label": ev.fecha.strftime("%d/%m/%Y %H:%M") if ev.fecha else "",
                "texto": ev.descripcion,
            }
        )
    items.sort(key=lambda i: i["fecha"])
    return items


@user_required
def mi_ticket_info_ajax(request, pk):
    """Datos del ticket para editar y su historial de respuestas (JSON)."""
    ticket = _mi_ticket_del_usuario(request, pk)
    imagenes = [
        {
            "pk": a.pk,
            "url": reverse("tickets:adjunto", args=[a.pk]) if a.archivo else "",
            "nombre": a.nombre_original,
        }
        for a in ticket.adjuntos.filter(mime_type__startswith="image/").order_by("fecha_subida")
    ]
    return JsonResponse(
        {
            "ok": True,
            "ticket": {
                "pk": ticket.pk,
                "codigo": ticket.codigo,
                "titulo": ticket.titulo,
                "descripcion": ticket.descripcion,
                "categoria_id": ticket.categoria_id,
                "categoria_nombre": ticket.categoria.nombre if ticket.categoria else "Sin categoría",
                "prioridad": ticket.prioridad,
                "prioridad_nombre": ticket.get_prioridad_display(),
                "solicitante_punto": ticket.solicitante_punto,
                "estado": ticket.estado,
                "estado_label": ticket.get_estado_display(),
                # El JS refresca los distintivos solo: necesita saber si hubo
                # un "marcar resuelto" para pintar los dos.
                "resuelto": ticket.fue_resuelto,
                "fecha": ticket.fecha_creacion.strftime("%d/%m/%Y %H:%M") if ticket.fecha_creacion else "",
                "editable": ticket.estado == ticket.Estado.ABIERTO,
                "cerrable": ticket.estado in (ticket.Estado.ABIERTO, ticket.Estado.EN_PROGRESO),
            },
            "imagenes": imagenes,
            "categorias": [
                {"id": c.pk, "nombre": f"{c.grupo} · {c.nombre}"}
                for c in Categoria.objects.filter(activo=True).order_by("grupo", "nombre")
            ],
            "respuestas": _respuestas_para(ticket),
        }
    )


@user_required
@require_POST
def mi_ticket_editar_ajax(request, pk):
    """Guardar la edición del ticket sin recargar la página.

    El usuario solo puede cambiar el título, las observaciones (descripción) y
    adjuntar/eliminar una imagen. Prioridad y categoría NO se pueden editar.
    """
    ticket = _mi_ticket_del_usuario(request, pk)
    if ticket.estado != ticket.Estado.ABIERTO:
        return JsonResponse(
            {"ok": False, "error": "Solo puedes editar tu ticket mientras está abierto."},
            status=400,
        )

    titulo = (request.POST.get("titulo") or "").strip()
    descripcion = (request.POST.get("descripcion") or "").strip()
    if not titulo:
        return JsonResponse({"ok": False, "error": "Debes escribir el nombre del ticket."}, status=400)

    # Adjuntar imagen pequeña (si viene un archivo de imagen)
    archivo = request.FILES.get("imagen")
    if archivo:
        if archivo.size > 5 * 1024 * 1024:
            return JsonResponse({"ok": False, "error": "La imagen no puede superar los 5 MB."}, status=400)
        if ticket.adjuntos.filter(mime_type__startswith="image/").count() >= 1:
            return JsonResponse({"ok": False, "error": "Solo se permite una imagen por ticket."}, status=400)
        from django.core.exceptions import ValidationError
        from .forms import validar_contenido_adjunto
        try:
            validar_contenido_adjunto(archivo, solo_imagen=True)
        except ValidationError as exc:
            return JsonResponse({"ok": False, "error": exc.messages[0]}, status=400)
    # Solo guardar el texto cuando todas las validaciones hayan pasado.
    ticket.titulo = titulo
    ticket.descripcion = descripcion
    ticket.save(update_fields=["titulo", "descripcion"])
    if archivo:
        TicketAdjunto.objects.create(
            ticket=ticket,
            nombre_original=archivo.name,
            archivo=archivo,
            mime_type=archivo.content_type or "image/png",
            tamano_bytes=archivo.size,
            subido_por=ticket.solicitante_email,
        )

    # Eliminar imagen existente (si se solicita)
    eliminar_pk = request.POST.get("eliminar_imagen")
    if eliminar_pk:
        adj = ticket.adjuntos.filter(mime_type__startswith="image/", pk=eliminar_pk).first()
        if adj:
            if adj.archivo:
                adj.archivo.delete(save=False)
            adj.delete()

    if ticket.glpi_id:
        try:
            sync_edicion_to_glpi(ticket)
        except GlpiError:
            pass

    return JsonResponse(
        {
            "ok": True,
            "ticket": {
                "pk": ticket.pk,
                "titulo": ticket.titulo,
                "descripcion": ticket.descripcion,
                "categoria_id": ticket.categoria_id,
            },
        }
    )


@user_required
@require_POST
def mi_ticket_cerrar_ajax(request, pk):
    """Cerrar el ticket del usuario sin recargar la página."""
    if not getattr(request.user, "puede_cerrar_tickets", False):
        return JsonResponse(
            {"ok": False, "error": "El administrador no te permite cerrar tickets."},
            status=403,
        )
    ticket = _mi_ticket_del_usuario(request, pk)
    if ticket.estado in (ticket.Estado.RESUELTO, ticket.Estado.CERRADO):
        return JsonResponse(
            {"ok": False, "error": "Este ticket ya está resuelto o cerrado."},
            status=400,
        )
    from .services.transiciones_ans import cambiar_estado_ans, EstadoTicketModificado
    try:
        ticket = cambiar_estado_ans(ticket.pk, ticket.Estado.CERRADO, actor=request.user, estado_esperado=ticket.estado)
    except EstadoTicketModificado:
        return JsonResponse({"ok": False, "error": "El ticket cambió; actualiza la página."}, status=409)
    notificar_ticket_actualizado(ticket, "Cerrado", "El solicitante cerro el ticket.")
    try:
        sync_estado_to_glpi(ticket)
    except GlpiError:
        pass
    return JsonResponse({"ok": True, "estado": "cerrado", "estado_label": "Cerrado"})


@user_required
@require_POST
def mi_ticket_eliminar_ajax(request, pk):
    """Renunciar/cancelar el propio ticket del usuario.

    Es borrado lógico: si el usuario se equivoca, lo restaura él mismo desde
    su papelera (Mi panel → Papelera). Antes solo se podía cancelar con el
    ticket abierto, así que una solicitud "en progreso" o ya resuelta se
    quedaba sin forma de quitarla de la lista.

    Al cancelar se avisa enseguida al técnico asignado (y a la bandeja si
    estaba sin técnico), para que no siga trabajando en una solicitud que ya
    no existe y para que su contador de la bandeja también lo note.

    Antes `ticket.delete()` lo borraba sin vuelta atrás.
    """
    if not getattr(request.user, "puede_eliminar_tickets", False):
        return JsonResponse(
            {"ok": False, "error": "El administrador no te permite eliminar tickets."},
            status=403,
        )
    ticket = _mi_ticket_del_usuario(request, pk)
    codigo = ticket.codigo
    tecnico = ticket.tecnico_asignado
    ticket.mandar_a_la_papelera(request.user)

    # La solicitud se cancela de inmediato del lado del técnico.
    try:
        notificar_ticket_actualizado(
            ticket,
            "cancelado por el solicitante",
            f"El solicitante cancelo {codigo}. Ya no hay nada que atender.",
            actor=request.user,
        )
        if tecnico is not None:
            from apps.notificaciones.models import Notificacion
            from apps.notificaciones import services as avisos

            avisos.crear(
                tecnico,
                Notificacion.Tipo.TICKET_EDITADO,
                f"{codigo} fue cancelado por quien lo pidio",
                "El solicitante retiro su solicitud: ya no hay nada que atender.",
                url=reverse("tickets:detalle", args=[ticket.pk]),
                icono="i-ban",
                clave=f"ticket:{ticket.pk}:cancelado:{tecnico.pk}",
            )
    except Exception:
        # Un aviso que falla nunca debe impedir la cancelación.
        pass

    return JsonResponse(
        {"ok": True, "codigo": codigo, "papelera": True, "estado": ticket.estado}
    )


@user_required
@require_POST
def mi_responder_ajax(request, pk):
    """Responder a un ticket propio desde el mini chat (sincroniza con GLPI)."""
    ticket = _mi_ticket_del_usuario(request, pk)
    comentario = request.POST.get("comentario", "").strip()
    if not comentario:
        return JsonResponse({"ok": False, "error": "Escribe un mensaje para responder."}, status=400)

    TicketComentario.objects.create(
        ticket=ticket,
        usuario=request.user,
        autor_nombre=request.user.nombre,
        comentario=comentario,
        es_interno=False,
    )

    notificar_comentario(ticket, request.user.nombre, comentario, actor=request.user)

    notificado = False
    if ticket.glpi_id:
        try:
            sync_followup_to_glpi(ticket, comentario)
            notificado = True
        except GlpiError:
            notificado = False
    else:
        notificado = False

    GlpiEvento.objects.create(
        ticket=ticket,
        tipo=GlpiEvento.Tipo.SEGUIMIENTO,
        descripcion=f"{ticket.codigo}: respuesta del solicitante registrada",
        payload_bruto={"usuario": request.user.email, "comentario": comentario},
    )

    return JsonResponse({
        "ok": True,
        "notificado": notificado,
        "mensaje": {
            "rol": "usuario",
            "autor": request.user.nombre,
            "fecha_label": DateFormat(timezone.now()).format("d/m/Y H:i"),
            "texto": comentario,
        },
    })


@staff_required
def panel_tecnico(request):
    """
    Panel del técnico: solicitudes asignadas a él/ella + chat para responderlas.
    """
    tecnico = request.user
    estado = request.GET.get("estado", "").strip()
    q = (request.GET.get("q", "") or "")[:120].strip()
    q_cola = (request.GET.get("q_cola", "") or "")[:120].strip()
    pp_mis = _resolve_per_page(request, "per_page", PER_PAGE_DEFECTO)
    pp_sol = _resolve_per_page(request, "per_page_sol", PER_PAGE_DEFECTO)
    if q:
        pp_mis = 0
    if q_cola:
        pp_sol = 0

    qs = (
        Ticket.objects.filter(tecnico_asignado=tecnico)
        .select_related("categoria", "tecnico_asignado")
        .prefetch_related("comentarios", "eventos_glpi")
    )
    qs = _filtrar_estado(qs, estado)
    if q:
        match_codigo = re.match(r"^(?:HD|DG-[A-Z]{2})-\d+$", q.upper())
        condicion = (
            Q(codigo__iexact=q.upper())
            | Q(titulo__icontains=q)
            | Q(solicitante_nombre__icontains=q)
            | Q(solicitante_email__icontains=q)
            | Q(solicitante_punto__icontains=q)
        )
        if match_codigo:
            condicion = Q(codigo__iexact=q.upper()) | Q(titulo__icontains=q) | Q(solicitante_nombre__icontains=q)
        qs = qs.filter(condicion)

    # Dashboard del técnico: resumen completo de SUS tickets (sin filtros de búsqueda)
    base_qs = Ticket.objects.filter(tecnico_asignado=tecnico)
    stats = base_qs.aggregate(
        total=Count("id"),
        abiertos=Count("id", filter=Q(estado=Ticket.Estado.ABIERTO)),
        en_progreso=Count("id", filter=Q(estado=Ticket.Estado.EN_PROGRESO)),
        resueltos=Count("id", filter=Q(fecha_resolucion__isnull=False)),
        cerrados=Count("id", filter=Q(estado=Ticket.Estado.CERRADO)),
    )
    chart_context = _build_chart_context(
        list(base_qs.select_related("categoria", "tecnico_asignado"))
    )

    # Las solicitudes finalizadas también se pueden consultar desde los filtros.
    cola_qs = (
        Ticket.objects.select_related("categoria", "tecnico_asignado")
        .annotate(_prioridad_orden=orden_prioridad_annotation())
        .order_by("-fecha_creacion", "_prioridad_orden", "-pk")
    )
    if q_cola:
        match_cola = re.match(r"^(?:HD|DG-[A-Z]{2})-\d+$", q_cola.upper())
        condicion_cola = (
            Q(codigo__iexact=q_cola.upper())
            | Q(titulo__icontains=q_cola)
            | Q(solicitante_nombre__icontains=q_cola)
            | Q(solicitante_email__icontains=q_cola)
            | Q(solicitante_punto__icontains=q_cola)
        )
        if match_cola:
            condicion_cola = Q(codigo__iexact=q_cola.upper()) | Q(titulo__icontains=q_cola) | Q(solicitante_nombre__icontains=q_cola)
        cola_qs = cola_qs.filter(condicion_cola)
    cola_estado = request.GET.get("cola_estado", "")
    cola_prioridad = request.GET.get("cola_prioridad", "")
    cola_tecnico = request.GET.get("cola_tecnico", "")
    cola_periodo = request.GET.get("cola_periodo", "")
    cola_orden = request.GET.get("cola_orden", "")
    cola_campos = {"codigo": "codigo", "solicitante": "solicitante_nombre", "punto": "solicitante_punto", "prioridad": "prioridad", "tecnico": "tecnico_asignado__nombre", "estado": "estado"}
    if cola_estado == Ticket.Estado.RESUELTO:
        cola_qs = cola_qs.filter(Q(estado=Ticket.Estado.RESUELTO) | Q(fecha_resolucion__isnull=False))
    elif cola_estado in dict(Ticket.Estado.choices):
        cola_qs = cola_qs.filter(estado=cola_estado)
    if cola_prioridad in dict(Ticket.Prioridad.choices):
        cola_qs = cola_qs.filter(prioridad=cola_prioridad)
    if cola_tecnico.isdigit():
        cola_qs = cola_qs.filter(tecnico_asignado_id=cola_tecnico)
    if cola_periodo in {"7", "30", "90"}:
        cola_qs = cola_qs.filter(fecha_creacion__gte=timezone.now() - timedelta(days=int(cola_periodo)))
    campo_orden = cola_campos.get(cola_orden.lstrip("-"))
    if campo_orden:
        cola_qs = cola_qs.order_by(("-" if cola_orden.startswith("-") else "") + campo_orden, "pk")
    elif cola_orden.lstrip("-") == "vencimiento":
        tickets_cola = list(cola_qs)
        resultados_cola = evaluar_lote(tickets_cola, permitir_provisional=True)
        con_limite = [t for t in tickets_cola if resultados_cola[t.pk].limite]
        sin_limite = [t for t in tickets_cola if not resultados_cola[t.pk].limite]
        con_limite.sort(key=lambda t: resultados_cola[t.pk].limite, reverse=cola_orden.startswith("-"))
        cola_qs = con_limite + sin_limite
    solicitudes_page = _paginar(
        cola_qs,
        request,
        per_page_param="per_page_sol",
        per_page_default=pp_sol,
        param="page_sol",
    )


    page_obj = _paginar(
        qs.annotate(_prioridad_orden=orden_prioridad_annotation()).order_by(
            "-fecha_creacion", "_prioridad_orden", "-pk"
        ),
        request,
        per_page_default=pp_mis,
    )

    ticket = None
    timeline = []
    eventos_count = 0
    ticket_pk = request.GET.get("ticket")
    if ticket_pk:
        try:
            ticket = Ticket.objects.select_related(
                "categoria", "tecnico_asignado"
            ).prefetch_related(
                "comentarios", "comentarios__usuario", "eventos_glpi", "adjuntos"
            ).get(pk=ticket_pk, tecnico_asignado=tecnico)
            timeline = _timeline_ticket(ticket, include_internos=True)
            eventos_count = sum(1 for i in timeline if i["tipo"] == "sistema")
        except Ticket.DoesNotExist:
            ticket = None

    vista = request.GET.get("vista", "").strip() or ("mis" if ticket_pk else "panel")

    # Bandeja "Sin asignar" (pestaña del panel): abiertas sin técnico.
    sin_qs = (
        Ticket.objects.select_related("categoria", "tecnico_asignado")
        .filter(
            estado__in=[Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO],
            tecnico_asignado__isnull=True,
        )
        .annotate(_prioridad_orden=orden_prioridad_annotation())
        .order_by("-fecha_creacion", "_prioridad_orden", "-pk")
    )
    sin_count = sin_qs.count()
    sin_page = (
        _paginar(
            sin_qs,
            request,
            per_page_param="per_page_sin",
            per_page_default=pp_sol,
            param="page_sin",
        )
        if vista == "sin"
        else None
    )

    # Módulo corporativo "Mis solicitudes abiertas" (solo cuando no hay chat abierto)
    abiertas = []
    tarjetas = []
    combinadas_map = {}
    sitios = []
    grupos = []
    tecnicos = []
    abiertas_count = 0
    mis_page = None
    if request.user.rol == "admin":
        mias = request.GET.get("mias", "") in ("1", "true", "on")
    else:
        mias = True  # el técnico solo ve sus solicitudes asignadas
    abiertos = [Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO]
    presets_mis = list(PRESETS_MIS)
    if request.user.rol != "admin":
        presets_mis = [p for p in presets_mis if p[0] != "no-asignadas"]
    presets_mis_map = dict(presets_mis)
    # La pestana entra sin recorte: sv=todas y sin limite de fecha. Antes se
    # llegaba con sv=abiertas + rango=30, asi que los tickets resueltos,
    # cerrados o con mas de 30 dias no aparecian nunca y el tecnico concluyo
    # "no tengo solicitudes" teniendolas asignadas.
    sv = request.GET.get("sv", "todas").strip() or "todas"
    if sv not in presets_mis_map:
        sv = "todas"
    rangos_mis = list(RANGOS_MIS)
    rango = request.GET.get("rango", "")
    if rango not in dict(rangos_mis):
        rango = ""
    if estado and sv != "todas":
        # Un estado explicito manda sobre la vista: con "abiertas" (abierto/en
        # progreso) + "resueltos" la interseccion siempre salia vacia.
        sv = "todas"
    # El contador de la pestana y la lista comparten queryset, asi el numero
    # siempre coincide con lo que se ve (el texto de busqueda no lo altera).
    secundarias_comb = set(
        TicketVinculo.objects.filter(tipo=TicketVinculo.Tipo.COMBINAR).values_list(
            "ticket_secundario_id", flat=True
        )
    )
    mis_qs = Ticket.objects.select_related("categoria", "tecnico_asignado")
    if secundarias_comb:
        mis_qs = mis_qs.exclude(pk__in=secundarias_comb)
    inicio_hoy = timezone.localtime(timezone.now()).replace(
        hour=0, minute=0, second=0, microsecond=0
    )
    if sv == "completadas":
        mis_qs = mis_qs.filter(
            estado__in=[Ticket.Estado.RESUELTO, Ticket.Estado.CERRADO]
        )
    elif sv == "espera":
        mis_qs = mis_qs.filter(estado=Ticket.Estado.ABIERTO)
    elif sv == "no-asignadas":
        mis_qs = mis_qs.filter(estado__in=abiertos, tecnico_asignado__isnull=True)
    elif sv == "vencen-hoy":
        mis_qs = mis_qs.filter(estado__in=abiertos)
    elif sv == "vencidas":
        mis_qs = mis_qs.filter(estado__in=abiertos)
    elif sv == "creadas-hoy":
        mis_qs = mis_qs.filter(fecha_creacion__gte=inicio_hoy)
    elif sv != "todas":
        mis_qs = mis_qs.filter(estado__in=abiertos)
    if rango:
        try:
            mis_qs = mis_qs.filter(
                fecha_creacion__gte=timezone.now() - timedelta(days=int(rango))
            )
        except (TypeError, ValueError):
            pass
    mis_qs = _filtrar_estado(mis_qs, estado)
    if mias:
        mis_qs = mis_qs.filter(tecnico_asignado=tecnico)
    if sv in ("vencen-hoy", "vencidas"):
        ahora_ans = timezone.now()
        limite_hoy = inicio_hoy + timedelta(days=1)
        ids_ans = []
        candidatos_ans = list(mis_qs)
        resultados_ans = evaluar_lote(candidatos_ans, ahora=ahora_ans, permitir_provisional=True)
        for item in candidatos_ans:
            resultado_ans = resultados_ans[item.pk]
            limite = resultado_ans.limite
            if limite and (inicio_hoy <= limite < limite_hoy if sv == "vencen-hoy" else resultado_ans.estado == "vencido"):
                ids_ans.append(item.pk)
        mis_qs = mis_qs.filter(pk__in=ids_ans)
    mis_qs = mis_qs.annotate(_prioridad_orden=orden_prioridad_annotation()).order_by(
        "-fecha_creacion", "_prioridad_orden", "-pk"
    )
    mis_count = mis_qs.count()
    if vista == "mis" and not ticket_pk:
        combinadas_map = {}
        for v in TicketVinculo.objects.filter(
            tipo=TicketVinculo.Tipo.COMBINAR
        ).select_related("ticket_secundario"):
            combinadas_map.setdefault(v.ticket_principal_id, []).append(v.ticket_secundario)
        if q:
            match_codigo = re.match(r"^(?:HD|DG-[A-Z]{2})-\d+$", q.upper())
            condicion = (
                Q(codigo__iexact=q.upper())
                | Q(titulo__icontains=q)
                | Q(solicitante_nombre__icontains=q)
                | Q(solicitante_email__icontains=q)
                | Q(solicitante_punto__icontains=q)
            )
            if match_codigo:
                condicion = Q(codigo__iexact=q.upper()) | Q(titulo__icontains=q) | Q(solicitante_nombre__icontains=q)
            mis_qs = mis_qs.filter(condicion)
        # "abiertas" alimenta la tabla y la rejilla de tarjetas. Se pagina
        # sobre mis_qs (el queryset ya filtrado de la pestaña) para que las
        # tarjetas salgan en la rejilla 3x3 y no la lista completa; con filtro
        # de texto o "todas" se mantiene la lista entera.
        if q or pp_mis == 0:
            tarjetas = list(mis_qs)
        else:
            tarjetas = list(
                _paginar(
                    mis_qs.annotate(_prioridad_orden=orden_prioridad_annotation()).order_by(
                        "-fecha_creacion", "_prioridad_orden", "-pk"
                    ),
                    request,
                    per_page_default=pp_mis,
                ).object_list
            )
        mis_page = _paginar(mis_qs, request, per_page_default=pp_mis)
        abiertas = list(mis_page.object_list)
        tarjetas = list(mis_page.object_list)
        tarjetas = _adjuntar_solicitantes(tarjetas)
        for t in tarjetas:
            t.combinadas = combinadas_map.get(t.pk, [])
        abiertas = _adjuntar_solicitantes(abiertas)
        for t in abiertas:
            t.combinadas = combinadas_map.get(t.pk, [])
        abiertas_count = mis_page.paginator.count
        sitios = sorted(
            {t.solicitante_punto for t in abiertas if t.solicitante_punto},
            key=str.lower,
        )
        grupos = sorted(
            {t.categoria.grupo for t in abiertas if t.categoria_id and t.categoria.grupo},
            key=str.lower,
        )
        tecnicos = list(
            User.objects.filter(activo=True, rol__in=["admin", "tecnico"]).order_by("nombre")
        )

    dash_json = (
        _build_tecnico_dashboard(None)
        if request.user.rol == "admin"
        else _build_tecnico_dashboard(tecnico.id)
    ) if vista == "panel" else "{}"

    tickets = _adjuntar_solicitantes(page_obj.object_list)
    solicitudes = _adjuntar_solicitantes(solicitudes_page.object_list)
    sin_solicitudes = (
        _adjuntar_solicitantes(sin_page.object_list) if sin_page is not None else []
    )

    return render(
        request,
        "tickets/panel_tecnico.html",
        {
            "tickets": tickets,
            "page_obj": page_obj,
            "solicitudes": solicitudes,
            "solicitudes_page": solicitudes_page,
            "cola_count": solicitudes_page.paginator.count,
            "sin_solicitudes": sin_solicitudes,
            "sin_page": sin_page,
            "sin_count": sin_count,
            "querystring_sin": _params_sin_page(request, "page_sin"),
            "vista": vista,
            "querystring": _params_sin_page(request),
            "querystring_cola": _params_sin_page(request, "page_sol"),
            "filtro_estado": estado,
            "q": q,
            "q_cola": q_cola,
            "cola_estado": cola_estado, "cola_prioridad": cola_prioridad, "cola_tecnico": cola_tecnico,
            "cola_periodo": cola_periodo, "cola_orden": cola_orden,
            "cola_prioridades": Ticket.Prioridad.choices,
            "cola_tecnicos": User.objects.filter(activo=True, rol__in=[User.Rol.TECNICO, User.Rol.ADMIN]).order_by("nombre"),
            "estados": Ticket.Estado.choices,
            "total_resultados": page_obj.paginator.count,
            "ticket": ticket,
            "timeline": timeline,
            "eventos_count": eventos_count,
            "stats": stats,
            "per_page": pp_mis,
            "tecnico_kpi_historico": _tecnico_actividad_graficas(base_qs),
            "per_page_sol": pp_sol,
            "dash_json": dash_json,
            "alcances_tortas": _ALCANCES_TORTAS,
            "alcances_20dias": _ALCANCES_20_DIAS,
            "abiertas": abiertas,
            "tarjetas": tarjetas,
            "abiertas_count": abiertas_count,
            "mis_page": mis_page,
            "mis_count": mis_count,
            "sitios": sitios,
            "grupos": grupos,
            "tecnicos": tecnicos,
            "mias": mias,
            "sv": sv,
            "sv_label": (
                dict(Ticket.Estado.choices).get(
                    estado, presets_mis_map.get(sv, "Mis solicitudes abiertas")
                )
                if estado
                else presets_mis_map.get(sv, "Mis solicitudes abiertas")
            ),
            "presets_mis": presets_mis,
            "rango": rango,
            "rangos_mis": rangos_mis,
            **chart_context,
        },
    )


@staff_required
@require_POST
def panel_tecnico_tomar(request, pk):
    """Toma un ticket: sin asignar o de otro técnico que no puede atenderlo.

    Si ya lo tiene el que lo pide, no se hace nada. Si lo tiene otro
    técnico, se reasigna y se dice a quién se le quitó.
    """
    ticket = get_object_or_404(
        Ticket.objects.select_related("tecnico_asignado"),
        pk=pk,
    )
    if ticket.estado in (Ticket.Estado.RESUELTO, Ticket.Estado.CERRADO) or ticket.fue_resuelto:
        messages.error(request, "No se puede tomar una solicitud finalizada.")
        return redirect("tickets:panel_tecnico")
    anterior = None
    if ticket.tecnico_asignado_id:
        if ticket.tecnico_asignado_id == request.user.pk:
            messages.info(
                request, f"El ticket {ticket.codigo} ya está asignado a ti."
            )
            return redirect("tickets:panel_tecnico")
        anterior = (
            ticket.tecnico_asignado.nombre
            if ticket.tecnico_asignado else "otro técnico"
        )

    ticket, _ = asignar_manual(ticket.pk, request.user)
    tomado = (
        f"Ticket {ticket.codigo} tomado (antes lo tenía {anterior})."
        if anterior else f"Ticket {ticket.codigo} tomado."
    )

    if request.user.glpi_user_id:
        try:
            if sync_asignacion_to_glpi(ticket):
                messages.success(request, tomado + " (también en GLPI).")
            else:
                messages.success(request, tomado)
        except GlpiError as exc:
            messages.warning(request, f"{tomado} No se reflejó en GLPI: {exc}")
    else:
        messages.success(
            request,
            f"{tomado} Configura tu 'ID usuario GLPI' en Admin para reflejarlo allá.",
        )
    return redirect("tickets:panel_tecnico")


@staff_required
@require_POST
def panel_tecnico_lote(request):
    """Acciones en lote del módulo 'Mis solicitudes abiertas' (selección múltiple)."""
    accion = request.POST.get("accion", "").strip()
    try:
        ids = [int(x) for x in request.POST.get("ids", "").split(",") if x.strip().isdigit()]
    except (TypeError, ValueError):
        ids = []
    if not ids:
        return JsonResponse({"ok": False, "error": "Selecciona al menos una solicitud."}, status=400)

    tickets = list(
        Ticket.objects.select_related("categoria", "tecnico_asignado").filter(pk__in=ids)
    )
    if not tickets:
        return JsonResponse({"ok": False, "error": "No se encontraron las solicitudes."}, status=404)

    if accion == "recoger":
        tomados, ya_asignados = 0, 0
        for t in tickets:
            if t.tecnico_asignado_id:
                ya_asignados += 1
                continue
            t, tomado = asignar_manual(t.pk, request.user, solo_sin_asignar=True)
            if not tomado:
                ya_asignados += 1
                continue
            tomados += 1
            if request.user.glpi_user_id:
                try:
                    sync_asignacion_to_glpi(t)
                except GlpiError:
                    pass
        msg = f"{tomados} solicitud(es) recogida(s)."
        if ya_asignados:
            msg += f" {ya_asignados} ya estaban asignadas y se omitieron."
        return JsonResponse({"ok": True, "mensaje": msg, "recogidas": tomados})

    if accion == "cerrar":
        cerrados = 0
        for t in tickets:
            if t.estado == Ticket.Estado.CERRADO:
                continue
            from .services.transiciones_ans import cambiar_estado_ans, EstadoTicketModificado
            try:
                t = cambiar_estado_ans(t.pk, Ticket.Estado.CERRADO, actor=request.user, estado_esperado=t.estado)
            except EstadoTicketModificado:
                continue
            notificar_ticket_actualizado(t, "cambiado a Cerrado")
            try:
                sync_estado_to_glpi(t)
            except GlpiError:
                pass
            cerrados += 1
        return JsonResponse({"ok": True, "mensaje": f"{cerrados} solicitud(es) cerrada(s).", "cerrados": cerrados})

    if accion == "eliminar":
        if not request.user.rol == "admin":
            return JsonResponse({"ok": False, "error": "Solo el administrador puede eliminar solicitudes en lote."}, status=403)
        # Borrado lógico: van a la papelera, sin tocar adjuntos ni GLPI.
        eliminados = 0
        for t in tickets:
            t.mandar_a_la_papelera(request.user)
            eliminados += 1
        return JsonResponse({
            "ok": True,
            "mensaje": (
                f"{eliminados} solicitud(es) enviada(s) a la papelera."
                if eliminados
                else "No había nada por eliminar."
            ),
            "eliminados": eliminados,
        })

    if accion == "asignar":
        sitio = request.POST.get("sitio", "").strip()
        grupo = request.POST.get("grupo", "").strip()
        tecnico_id = request.POST.get("tecnico", "").strip()
        if not any([sitio, grupo, tecnico_id]):
            return JsonResponse({"ok": False, "error": "Completa al menos un campo de asignación."}, status=400)

        tecnico = None
        if tecnico_id.isdigit():
            tecnico = User.objects.filter(pk=int(tecnico_id), activo=True,
                                          rol__in=["admin", "tecnico"]).first()
            if tecnico_id and not tecnico:
                return JsonResponse({"ok": False, "error": "El técnico seleccionado no existe."}, status=400)
        categoria = None
        if grupo:
            categoria = Categoria.objects.filter(activo=True, grupo=grupo).order_by("nombre").first()
            if not categoria:
                return JsonResponse({"ok": False, "error": f"No hay categorías activas en el grupo '{grupo}'."}, status=400)

        asignados = 0
        for t in tickets:
            cambios = {}
            if sitio:
                cambios["solicitante_punto"] = sitio
            if categoria:
                cambios["categoria"] = categoria
            t, _ = asignar_manual(t.pk, tecnico, cambiar_tecnico=bool(tecnico_id), cambios=cambios)
            if tecnico and tecnico.glpi_user_id:
                try:
                    sync_asignacion_to_glpi(t)
                except GlpiError:
                    pass
            asignados += 1
        return JsonResponse({"ok": True, "mensaje": f"{asignados} solicitud(es) actualizada(s).", "asignados": asignados})

    if accion == "combinar":
        principal_id = request.POST.get("principal", "").strip()
        principal = next(
            (t for t in tickets if str(t.pk) == principal_id), None
        )
        if not principal:
            return JsonResponse(
                {"ok": False, "error": "Selecciona la solicitud principal para combinar."},
                status=400,
            )
        secundarios = [t for t in tickets if t.pk != principal.pk]
        if not secundarios:
            return JsonResponse(
                {"ok": False, "error": "Selecciona al menos dos solicitudes para combinar."},
                status=400,
            )
        ref_sec = ", ".join(t.codigo for t in secundarios)
        combinados = 0
        for sec in secundarios:
            _, creado = TicketVinculo.objects.get_or_create(
                ticket_principal=principal,
                ticket_secundario=sec,
                tipo=TicketVinculo.Tipo.COMBINAR,
                defaults={"comentario": "", "creado_por": request.user},
            )
            TicketComentario.objects.create(
                ticket=sec,
                usuario=request.user,
                autor_nombre=request.user.nombre,
                comentario=(
                    f"Solicitud combinada: este ticket se combinó con la solicitud "
                    f"principal {principal.codigo}. Ref. {ref_sec}."
                ),
                es_interno=True,
            )
            combinados += 1
        TicketComentario.objects.create(
            ticket=principal,
            usuario=request.user,
            autor_nombre=request.user.nombre,
            comentario=f"Solicitud combinada: incluye {ref_sec}.",
            es_interno=True,
        )
        return JsonResponse(
            {
                "ok": True,
                "mensaje": f"{combinados} solicitud(es) combinada(s) bajo {principal.codigo}.",
                "combinados": combinados,
            }
        )

    if accion == "vincular":
        comentario = request.POST.get("comentario", "").strip()
        principal = min(tickets, key=lambda t: t.fecha_creacion or timezone.now())
        secundarios = [t for t in tickets if t.pk != principal.pk]
        if not secundarios:
            return JsonResponse(
                {"ok": False, "error": "Selecciona al menos dos solicitudes para vincular."},
                status=400,
            )
        ref = ", ".join(t.codigo for t in tickets)
        vinculados = 0
        for sec in secundarios:
            _, creado = TicketVinculo.objects.get_or_create(
                ticket_principal=principal,
                ticket_secundario=sec,
                tipo=TicketVinculo.Tipo.VINCULAR,
                defaults={"comentario": comentario, "creado_por": request.user},
            )
            TicketComentario.objects.create(
                ticket=sec,
                usuario=request.user,
                autor_nombre=request.user.nombre,
                comentario=(
                    f"Solicitudes vinculadas: {ref}."
                    + (f" {comentario}" if comentario else "")
                ),
                es_interno=True,
            )
            vinculados += 1
        TicketComentario.objects.create(
            ticket=principal,
            usuario=request.user,
            autor_nombre=request.user.nombre,
            comentario=(
                f"Solicitudes vinculadas: {ref}."
                + (f" {comentario}" if comentario else "")
            ),
            es_interno=True,
        )
        return JsonResponse(
            {
                "ok": True,
                "mensaje": f"{vinculados} solicitud(es) vinculada(s) bajo {principal.codigo}.",
                "vinculados": vinculados,
            }
        )

    return JsonResponse({"ok": False, "error": "Acción no válida."}, status=400)


@staff_required
def mis_tickets_tecnico(request):
    """Unificado con la lista general de tickets: redirige a tickets:lista."""
    return redirect("tickets:lista")


@staff_required
def panel_tecnico_msgs_ajax(request, pk):
    """JSON con los mensajes del ticket para refrescar el chat sin recargar."""
    try:
        ticket = Ticket.objects.select_related("tecnico_asignado").get(
            pk=pk,
            tecnico_asignado=request.user,
        )
    except Ticket.DoesNotExist:
        return JsonResponse({"ok": False, "error": "Ticket no encontrado o no asignado."}, status=404)
    return JsonResponse({"ok": True, "mensajes": _respuestas_para(ticket, include_internos=True)})


@staff_required
@require_POST
def panel_tecnico_chat_ajax(request, pk):
    """Envía un mensaje del técnico al solicitante en el chat del panel."""
    try:
        ticket = Ticket.objects.select_related("tecnico_asignado").get(
            pk=pk,
            tecnico_asignado=request.user,
        )
    except Ticket.DoesNotExist:
        return JsonResponse({"ok": False, "error": "Ticket no encontrado o no asignado."}, status=404)
    comentario = request.POST.get("comentario", "").strip()
    if not comentario:
        return JsonResponse({"ok": False, "error": "Escribe un mensaje para responder."}, status=400)
    es_interno = request.POST.get("interno") in ("1", "true", "on")

    c = TicketComentario.objects.create(
        ticket=ticket,
        usuario=request.user,
        autor_nombre=request.user.nombre,
        comentario=comentario,
        es_interno=es_interno,
    )

    notificado = False
    if not es_interno:
        notificar_comentario(ticket, request.user.nombre, comentario, actor=request.user)
        if ticket.glpi_id:
            try:
                sync_followup_to_glpi(ticket, comentario)
                notificado = True
            except GlpiError:
                notificado = False
        GlpiEvento.objects.create(
            ticket=ticket,
            tipo=GlpiEvento.Tipo.SEGUIMIENTO,
            descripcion=f"{ticket.codigo}: respuesta del técnico registrada",
            payload_bruto={"usuario": request.user.email, "comentario": comentario},
        )

    return JsonResponse({
        "ok": True,
        "notificado": notificado,
        "mensaje": {
            "rol": "interno" if es_interno else "soporte",
            "autor": c.autor_nombre or request.user.nombre,
            "fecha_label": DateFormat(timezone.now()).format("d/m/Y H:i"),
            "texto": comentario,
        },
    })


# =====================================================================
# Monitoreo e historial del técnico
# =====================================================================
def _filtro_ticket(palabras, prefijo=""):
    """Cada palabra debe salir en el código o en el título del ticket.

    `prefijo` es "" cuando se busca sobre `Ticket` y "ticket__" cuando la
    búsqueda va sobre un comentario que apunta al ticket.
    """
    filtro = Q()
    for p in palabras:
        filtro &= Q(**{f"{prefijo}codigo__icontains": p}) | Q(
            **{f"{prefijo}titulo__icontains": p}
        )
    return filtro


def _historial_fuentes(tecnico, tipo="todo", q=""):
    """Las dos fuentes del historial, ya filtradas y ordenadas por su cuenta.

    Los mensajes que escribió y los tickets que resolvió salen aquí como dos
    consultas normales y se combinan después en Python, nunca en la base.

    Eso es a propósito: la línea de tiempo se hacía con `union` y SQL Server
    la rompía, porque en un `union` la ordenación que Django necesita para
    contar filas acaba dentro de una subconsulta, y SQL Server no admite
    `ORDER BY` en una subconsulta sin `TOP` u `OFFSET` (`42000`, error 1033).
    Con dos consultas aparte cada una se ordena en la sentencia que le toca
    y no hay nada anidado.
    """
    campos = ("fecha", "codigo", "titulo", "texto", "tipo", "tid", "registro_pk")
    palabras = q.split()[:5]

    mensajes = TicketComentario.objects.filter(
        usuario=tecnico,
        ticket__eliminado_en__isnull=True,
    )
    resueltos = Ticket.objects.filter(
        tecnico_asignado=tecnico,
        fecha_resolucion__isnull=False,
    )
    if palabras:
        mensajes = mensajes.filter(_filtro_ticket(palabras, "ticket__"))
        resueltos = resueltos.filter(_filtro_ticket(palabras))

    # El orden va después del `annotate`: en `Ticket` no existe un campo
    # llamado `fecha`, solo el alias que se le pone más abajo, y si el
    # ordenamiento se resuelve antes Django no encuentra por dónde ordenar.
    mensajes = (
        mensajes.annotate(
            codigo=F("ticket__codigo"),
            titulo=F("ticket__titulo"),
            texto=F("comentario"),
            tipo=Value("respuesta"),
            tid=F("ticket_id"),
            registro_pk=F("pk"),
        )
        .order_by("-fecha")
        .values(*campos)
    )
    resueltos = (
        resueltos.annotate(
            fecha=F("fecha_resolucion"),
            texto=Value("Marcado como resuelto", output_field=CharField()),
            tipo=Value("resuelto"),
            tid=F("pk"),
            registro_pk=F("pk"),
        )
        .order_by("-fecha")
        .values(*campos)
    )
    if tipo == "respuestas":
        resueltos = resueltos.none()
    elif tipo == "resueltos":
        mensajes = mensajes.none()
    return mensajes, resueltos


def _pagina_historial(mensajes, resueltos, tipo, desde, hasta):
    """Una ventana de la línea de tiempo, combinando las dos fuentes a mano.

    Cada fuente viene ordenada de más reciente a más antiguo, así que sus
    `hasta` primeras filas contienen los `hasta` primeros de la mezcla: con
    eso el trozo que toca sale exacto sin tener que cargar el historial
    entero. Cuando `tipo` apunta a una sola fuente no hay nada que mezclar.
    """
    if tipo == "respuestas":
        return list(mensajes[desde:hasta])
    if tipo == "resueltos":
        return list(resueltos[desde:hasta])
    filas = list(mensajes[:hasta]) + list(resueltos[:hasta])
    filas.sort(key=lambda e: e["fecha"] or timezone.now(), reverse=True)
    return filas[desde:hasta]


def _enriquecer_entradas_historial(entradas):
    """Añade a cada acción los datos disponibles de su ticket."""
    ticket_ids = {entrada["tid"] for entrada in entradas}
    if not ticket_ids:
        return entradas

    tickets = {
        ticket.pk: ticket
        for ticket in Ticket.objects.filter(pk__in=ticket_ids).select_related(
            "categoria", "tecnico_asignado"
        )
    }
    primeras_acciones = dict(
        TicketComentario.objects.filter(
            ticket_id__in=ticket_ids,
            usuario__rol__in=(Usuario.Rol.ADMIN, Usuario.Rol.TECNICO),
        )
        .values("ticket_id")
        .annotate(fecha_primera=Min("fecha"))
        .values_list("ticket_id", "fecha_primera")
    )

    for entrada in entradas:
        ticket = tickets.get(entrada["tid"])
        if not ticket:
            entrada.update({
                "registro_id": f"ACC-{entrada['registro_pk']:06d}",
                "accion": "Respuesta" if entrada["tipo"] == "respuesta" else "Cierre",
                "solicitante": "No disponible",
                "tecnico": "No asignado",
                "supervisor": "No registrado",
                "estado_actual": "No disponible",
                "categoria": "No especificada",
                "prioridad_sla": "No disponible",
                "tiempo_respuesta": "No disponible",
                "tiempo_resolucion": "No disponible",
                "version_sistema": "No registrada",
            })
            continue

        fecha_primera = primeras_acciones.get(ticket.pk)
        fecha_finalizacion = ticket.fecha_cierre or ticket.fecha_resolucion
        categoria = ticket.categoria
        entrada.update({
            "registro_id": (
                f"COM-{entrada['registro_pk']:06d}"
                if entrada["tipo"] == "respuesta"
                else f"RES-{entrada['registro_pk']:06d}"
            ),
            "accion": "Respuesta" if entrada["tipo"] == "respuesta" else "Cierre / resolución",
            "solicitante": ticket.solicitante_nombre or ticket.solicitante_email or "No registrado",
            "tecnico": (
                ticket.tecnico_asignado.nombre or ticket.tecnico_asignado.email
                if ticket.tecnico_asignado else "No asignado"
            ),
            "supervisor": "No registrado para este ticket",
            "estado_actual": ticket.get_estado_display(),
            "categoria": (
                f"{categoria.grupo} › {categoria.nombre}" if categoria else "Sin categoría"
            ),
            "prioridad_sla": (
                f"{ticket.get_prioridad_display()} · {ticket.ans_horas or horas_por_prioridad(ticket.prioridad)} h"
            ),
            "tiempo_respuesta": (
                formatear_duracion(fecha_primera - ticket.fecha_creacion)
                if fecha_primera and ticket.fecha_creacion else "Sin respuesta registrada"
            ),
            "tiempo_resolucion": (
                formatear_duracion(fecha_finalizacion - ticket.fecha_creacion)
                if fecha_finalizacion and ticket.fecha_creacion else "Aún sin resolver"
            ),
            "version_sistema": "No registrada en el ticket",
        })
    return entradas


HISTORIAL_POR_PAGINA = 20


@staff_required
def tec_historial(request):
    """Lo que el técnico dejó hecho en la plataforma, en orden.

    No es el registro de auditoría del administrador, que guarda cambios de
    zonas y de cuentas: aquí está lo que hizo él — cada respuesta que dio en
    el hilo de un ticket y cada ticket que cerró como resuelto.
    """
    tipo = (request.GET.get("tipo") or "todo").strip()
    if tipo not in ("todo", "respuestas", "resueltos"):
        tipo = "todo"
    q = (request.GET.get("q", "") or "")[:80].strip()
    mensajes, resueltos = _historial_fuentes(request.user, tipo=tipo, q=q)

    # El total se cuenta en dos consultas aparte y no sobre la mezcla: es lo
    # que evita el `union` y con él el error de SQL Server.
    if tipo == "respuestas":
        total = mensajes.count()
    elif tipo == "resueltos":
        total = resueltos.count()
    else:
        total = mensajes.count() + resueltos.count()

    # Aquí no manda `PER_PAGE_OPCIONES`: ese conjunto es de las tablas de
    # tickets (6, 5, 9, 10, 20, 50) y el historial es una línea de tiempo que
    # se pagina distinto. Cualquier tamaño positivo vale, con un tope para
    # que nadie pida una ventana enorme de un solo golpe.
    try:
        por_pagina = int(request.GET.get("per_page", HISTORIAL_POR_PAGINA))
    except (ValueError, TypeError):
        por_pagina = HISTORIAL_POR_PAGINA
    if por_pagina <= 0:
        por_pagina = HISTORIAL_POR_PAGINA
    por_pagina = min(por_pagina, 200)

    num_paginas = max(-(-total // por_pagina), 1)
    try:
        pagina = int(request.GET.get("page") or 1)
    except (ValueError, TypeError):
        pagina = 1
    pagina = min(max(pagina, 1), num_paginas)

    desde = (pagina - 1) * por_pagina
    entradas = _pagina_historial(
        mensajes, resueltos, tipo, desde, desde + por_pagina
    )
    entradas = _enriquecer_entradas_historial(entradas)

    resueltos_total = (
        Ticket.objects.filter(
            tecnico_asignado=request.user, fecha_resolucion__isnull=False
        ).count()
    )
    respuestas_total = TicketComentario.objects.filter(
        usuario=request.user
    ).count()
    inicio_hist = timezone.localdate() - timedelta(days=6)
    series_hist = {key: [0] * 7 for key in ("registros", "respuestas", "resueltos")}
    def acumular_historial(query, campo, claves):
        for fecha in query.filter(**{campo + "__gte": timezone.now() - timedelta(days=8)}).values_list(campo, flat=True):
            dia = _key_fecha(fecha)
            if dia and 0 <= (dia - inicio_hist).days < 7:
                for clave in claves:
                    series_hist[clave][(dia - inicio_hist).days] += 1
    acumular_historial(mensajes, "fecha", ("registros",))
    acumular_historial(resueltos, "fecha_resolucion", ("registros",))
    acumular_historial(TicketComentario.objects.filter(usuario=request.user), "fecha", ("respuestas",))
    acumular_historial(Ticket.objects.filter(tecnico_asignado=request.user, fecha_resolucion__isnull=False), "fecha_resolucion", ("resueltos",))

    return render(
        request,
        "tickets/tec_historial.html",
        {
            "entradas": entradas,
            "total": total,
            "pagina": pagina,
            "num_paginas": num_paginas,
            "tiene_anterior": pagina > 1,
            "pagina_anterior": pagina - 1,
            "tiene_siguiente": pagina < num_paginas,
            "pagina_siguiente": pagina + 1,
            "por_pagina": por_pagina,
            "resueltos_total": resueltos_total,
            "respuestas_total": respuestas_total,
            "historial_series": {"series": series_hist, "labels": [(inicio_hist + timedelta(days=i)).strftime("%d/%m") for i in range(7)]},
            "tipo": tipo,
            "q": q,
            "nav_tec_historial": True,
        },
    )


def _zonas_de_mirada(mensajes, tickets):
    """Etiqueta cada presión y cada ticket con la zona desde la que se mira.

    Hasta ahora el técnico veía los mensajes pero no desde qué carpeta
    salían. Hay dos caminos reales y ninguno se inventa:

    * quien presiona puede ser el observador que creó una zona, o una cuenta
      de tu lista (entonces la zona sale de `ElementoMiLista`);
    * el punto de venta del ticket puede estar metido en una zona, y eso
      dice desde dónde se vigila ese caso concreto.

    Se hacen tres consultas en total, sin importar cuántos mensajes haya, y
    se devuelve además un resumen por zona para poder pintarlas juntas.
    """
    autores = {}
    for m in mensajes:
        u = m.usuario
        if u is not None and u.pk and u.pk not in autores:
            autores[u.pk] = u

    puntos = set()
    correos_tickets = set()
    for m in mensajes:
        nombre = (m.ticket.solicitante_punto or "").strip()
        if m.ticket.solicitante_email:
            correos_tickets.add(m.ticket.solicitante_email.strip().lower())
        if nombre:
            puntos.add(nombre)
    for t in tickets:
        nombre = (t.solicitante_punto or "").strip()
        if t.solicitante_email:
            correos_tickets.add(t.solicitante_email.strip().lower())
        if nombre:
            puntos.add(nombre)

    por_id, por_correo, por_punto = {}, {}, {}
    if autores:
        ids = list(autores)
        for z in ZonaObservador.objects.filter(
            observador_id__in=ids
        ).select_related("observador"):
            por_id.setdefault(z.observador_id, []).append(z)
        correos = [u.email for u in autores.values() if u.email]
        condicion = Q(usuario_id__in=ids)
        if correos:
            condicion |= Q(usuario_email__in=correos)
        for e in (
            ElementoMiLista.objects.filter(condicion, zona__isnull=False)
            .select_related("zona", "zona__observador")
        ):
            if e.usuario_id:
                por_id.setdefault(e.usuario_id, []).append(e.zona)
            correo = (e.usuario_email or "").strip().lower()
            if correo:
                por_correo.setdefault(correo, []).append(e.zona)
    if puntos:
        for e in (
            ElementoMiLista.objects.filter(
                punto__nombre__in=list(puntos), zona__isnull=False
            )
            .select_related("zona", "zona__observador")
        ):
            por_punto.setdefault(
                (e.punto.nombre or "").strip(), []
            ).append(e.zona)

    if correos_tickets:
        # La zona también puede contener personas, sin un punto asociado.
        # Normalizar en Python mantiene la comparación independiente de la
        # colación de la base de datos.
        elementos = ElementoMiLista.objects.filter(zona__isnull=False).exclude(
            usuario_email="", usuario__isnull=True
        ).select_related("zona", "zona__observador", "usuario")
        for elemento in elementos:
            correos_elemento = {str(valor).strip().lower() for valor in (
                elemento.usuario_email, elemento.usuario.email if elemento.usuario else ""
            ) if valor}
            for correo in correos_elemento & correos_tickets:
                por_correo.setdefault(correo, []).append(elemento.zona)

    def _una_vez(*grupos, tope=None):
        salida, vistos = [], set()
        for grupo in grupos:
            for z in grupo:
                if z.pk not in vistos:
                    vistos.add(z.pk)
                    salida.append(z)
        return salida[:tope] if tope is not None else salida

    def _del_autor(u):
        if u is None:
            return []
        return _una_vez(
            por_id.get(u.pk, []),
            por_correo.get((u.email or "").strip().lower(), []),
        )

    def _del_punto(nombre):
        return _una_vez(por_punto.get((nombre or "").strip(), []))

    for m in mensajes:
        m.zonas = _una_vez(
            _del_autor(m.usuario), _del_punto(m.ticket.solicitante_punto),
            por_correo.get((m.ticket.solicitante_email or "").strip().lower(), []),
        )
    for t in tickets:
        t.zonas = _una_vez(_del_punto(t.solicitante_punto), por_correo.get((t.solicitante_email or "").strip().lower(), []))

    resumen = {}
    for m in mensajes:
        for z in m.zonas:
            fila = resumen.setdefault(
                z.pk,
                {"zona": z, "presiones": 0, "presiones_enviadas": 0, "tickets": 0, "quien": []},
            )
            fila["presiones"] += 1
            if m.usuario_id and m.usuario_id == z.observador_id:
                fila["presiones_enviadas"] += 1
            quien = (m.usuario.nombre or m.usuario.email) if m.usuario else ""
            if quien and quien not in fila["quien"]:
                fila["quien"].append(quien)
    for t in tickets:
        for z in t.zonas:
            fila = resumen.setdefault(
                z.pk,
                {"zona": z, "presiones": 0, "presiones_enviadas": 0, "tickets": 0, "quien": []},
            )
            fila["tickets"] += 1
    return sorted(
        resumen.values(),
        key=lambda f: (-f["presiones"], -f["tickets"], f["zona"].nombre),
    )


@staff_required
def tec_monitoreo(request):
    """La presión que recibe y los tickets que se le va el tiempo de resolver.

    Es el mismo panel del observador, pero mirando solo lo suyo: los
    supervisores no ven esto — el técnico sí, para saber qué le están
    pidiendo y qué tiene a punto de vencer antes de que se lo diga alguien.
    """
    from . import ans_avisos

    asignados = Ticket.objects.filter(tecnico_asignado=request.user)
    abiertos = asignados.filter(
        estado__in=[Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO]
    )
    por_vencer = ans_avisos.por_vencer(
        consulta=asignados, solo_sin_avisar=False
    )
    total_vencidos = sum(1 for t in por_vencer if t.ans_estado == "vencido")
    total_por_vencer = len(por_vencer) - total_vencidos
    ans_graficas = {}
    for estado_ans in ("vencido", "por-vencer"):
        grupos = Counter()
        for ticket_ans in por_vencer:
            if ticket_ans.ans_estado == estado_ans and ticket_ans.fecha_limite_ans:
                limite = ticket_ans.fecha_limite_ans
                fecha_local = timezone.localdate(limite) if timezone.is_aware(limite) else limite.date()
                grupos[fecha_local] += 1
        ultimo_dia = max(grupos) if grupos else timezone.localdate()
        fechas_ans = [ultimo_dia - timedelta(days=9-i) for i in range(10)]
        ans_graficas[estado_ans] = {"labels": [fecha.strftime("%d/%m/%Y") for fecha in fechas_ans], "values": [grupos.get(fecha, 0) for fecha in fechas_ans]}

    consulta_presion = TicketComentario.objects.filter(
        es_presion=True, ticket__tecnico_asignado=request.user
    )
    inicio_presiones = timezone.localdate() - timedelta(days=9)
    presiones_dias = [0] * 10
    for fecha in consulta_presion.filter(fecha__gte=timezone.now() - timedelta(days=11)).values_list("fecha", flat=True):
        dia = timezone.localdate(fecha) if timezone.is_aware(fecha) else fecha.date()
        indice = (dia - inicio_presiones).days
        if 0 <= indice < 10:
            presiones_dias[indice] += 1
    from django.db.models import Max
    puntos_presion = list(consulta_presion.exclude(ticket__solicitante_punto__isnull=True).exclude(ticket__solicitante_punto="").values("ticket__solicitante_punto").annotate(total=Count("pk"), ultima=Max("fecha")).order_by("-total", "ticket__solicitante_punto"))
    max_presiones_punto = max(3, max((p["total"] for p in puntos_presion), default=0))
    for punto in puntos_presion:
        punto["porcentaje"] = round(punto["total"] * 100 / max_presiones_punto)
        punto["intensidad"] = "alta" if punto["porcentaje"] >= 75 else "media" if punto["porcentaje"] >= 45 else "baja"
    todas_presiones = list(consulta_presion.select_related("ticket", "usuario").order_by("-fecha"))
    presiones = todas_presiones[:20]
    # `ans_estado` no es un campo del ticket: lo pone `por_vencer` sobre cada
    # objeto que devuelve. Aquí se lo pasamos a los tickets de los mensajes,
    # que son los mismos, para que la tarjeta pueda pintar el aviso.
    ans_de_ticket = {t.pk: t.ans_estado for t in por_vencer}
    for m in presiones:
        m.ticket.ans_estado = ans_de_ticket.get(m.ticket.pk, "")
    resueltos_hoy = asignados.filter(
        fecha_resolucion__date=timezone.localdate()
    ).count()

    # De qué zona sale cada mirada, y el listado que sirve de destino a los
    # indicadores de arriba (el que apunta a «Abiertos» tiene que enseñar
    # abiertos, no un listado indiferente).
    tickets_zonas = list(asignados.select_related("categoria"))
    zonas_mirada = _zonas_de_mirada(todas_presiones, tickets_zonas)
    _zonas_de_mirada([], por_vencer)
    hoy = timezone.localdate()
    tickets_lista = list(
        asignados.select_related("categoria").order_by("-fecha_actualizacion")[:60]
    )
    for t in tickets_lista:
        t.resuelto_hoy = bool(
            t.fecha_resolucion
            # `localdate` convierte a la hora activa: `fecha_resolucion` está
            # en UTC y su `.date()` crudo saldría en otra cuando en la
            # oficina ya cambió de día.
            and timezone.localdate(t.fecha_resolucion) == hoy
        )

    return render(
        request,
        "tickets/tec_monitoreo.html",
        {
            "total_asignados": asignados.count(),
            "total_abiertos": abiertos.count(),
            "por_vencer": por_vencer,
            "total_por_vencer": total_por_vencer,
            "total_vencidos": total_vencidos,
            "presiones": presiones,
            "total_presiones": consulta_presion.count(),
            "puntos_presion": puntos_presion,
            "presiones_dias": presiones_dias,
            "ans_graficas": ans_graficas,
            "resueltos_hoy": resueltos_hoy,
            "zonas_mirada": zonas_mirada,
            "tickets_lista": tickets_lista,
            "ans_modal": True,
            "nav_tec_monitoreo": True,
        },
    )


# =====================================================================
# Manual de uso y categorías explicativas
# =====================================================================
@login_required
def categorias_publico(request):
    """Categorías explicadas para el usuario: qué hace cada una y cuándo usarla.

    Es la versión de solo lectura del árbol que ve el administrador: sirve
    para que cualquiera sepa en qué casillar reportar antes de crear el ticket.
    """
    if request.user.rol == Usuario.Rol.TECNICO:
        return redirect("tickets:categorias_arbol")

    arbol = Categoria.arbol()
    inactivas = list(Categoria.objects.filter(activo=False).order_by("grupo", "nombre"))
    # Prioriza el significado que definió el administrador; el catálogo de
    # descripciones queda como respaldo para categorías aún no personalizadas.
    for grupo in arbol:
        grupo["cubre"] = que_cubre_grupo(grupo["grupo"])
        for sub in grupo["subcategorias"]:
            sub.cubre = sub.descripcion or que_cubre(sub.grupo, sub.nombre)
            sub.clave_crear = f"{reverse('tickets:crear_ticket')}?categoria={sub.pk}"
    return render(
        request,
        "tickets/categorias_publico.html",
        {
            "arbol": arbol,
            "inactivas": inactivas,
            "total_categorias": sum(len(g["subcategorias"]) for g in arbol),
            "total_grupos": len(arbol),
        },
    )
