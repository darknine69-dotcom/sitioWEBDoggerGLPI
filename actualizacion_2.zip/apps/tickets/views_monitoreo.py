"""Armar desde el administrador la lista de monitoreo del observador.

El observador solo puede agregar a su lista los usuarios que ya encuentra por
su cuenta. Desde aquí el administrador ve el tabla completa de usuarios
activos, con filtros, y los guarda en la zona que le toca para que el
observador los vea en su panel.
"""

from collections import Counter
from datetime import timedelta

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Q
from django.db.models.functions import Lower
from django.http import Http404, JsonResponse
from django.shortcuts import redirect, render
from django.urls import reverse
from django.utils import timezone
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.http import require_GET, require_POST

from apps.accounts.models import Usuario


def _retorno_monitoreo(request):
    destino = (request.POST.get("volver") or "").strip()
    if destino and url_has_allowed_host_and_scheme(destino, {request.get_host()}, require_https=request.is_secure()):
        return destino
    return reverse("tickets:monitoreo_admin")

from . import ans_avisos
from .decorators import admin_required
from .models import (
    ElementoMiLista,
    MonitoreoAuditoria,
    ObservadorPunto,
    Punto,
    Ticket,
    TicketComentario,
    ZonaObservador,
)


def _auditar(actor, accion, observador=None, zona_nombre="", detalle="",
             request=None, resultado="exito", motivo="", comentarios="",
             cuenta=""):
    """Deja constancia de un cambio del monitoreo para el registro visible.

    Guarda IP, resultado, motivo, versión y cuenta cuando se conocen; el
    motivo sale de la acción si no se indica uno.
    """
    from apps.accounts.seguridad import ip_del_request

    if not motivo:
        motivo = {
            "agregar_lista": "Seguimiento manual del administrador",
            "agregar_miembro": "Seguimiento manual del administrador",
            "quitar_miembro": "Salida del seguimiento",
            "quitar_lista": "Salida del seguimiento",
            "crear_zona": "Organización del monitoreo",
            "renombrar_zona": "Organización del monitoreo",
            "eliminar_zona": "Limpieza del monitoreo",
            "asignar_punto": "Cobertura del supervisor",
            "quitar_punto": "Cobertura del supervisor",
            "alertas_ans": "Alertas de cumplimiento ANS",
        }.get(accion, "Gestión del monitoreo")
    return MonitoreoAuditoria.objects.create(
        actor=actor if getattr(actor, "pk", None) else None,
        observador=observador if getattr(observador, "pk", None) else None,
        zona_nombre=(zona_nombre or "")[:80],
        accion=accion,
        detalle=(detalle or "")[:200],
        cuenta=(cuenta or "")[:150],
        ip_origen=(ip_del_request(request) if request is not None else "")[:45],
        resultado=(resultado or "exito")[:10],
        motivo=motivo[:200],
        version_sistema=_version_equipo(request),
        comentarios=comentarios or "",
    )


def _version_equipo(request):
    """Windows del equipo donde se ejecutó la acción (User-Agent).

    Ej: 'Windows 11', 'Windows 10', 'Windows 7'. Si no es Windows,
    devuelve el SO detectado ('Android', 'Linux', …) o ''.
    Máx 30 caracteres (columna VersionSistema).
    """
    ua = ""
    try:
        ua = (request.META.get("HTTP_USER_AGENT") or "") if request is not None else ""
    except AttributeError:
        ua = ""
    bajo = ua.lower()
    if "windows nt 10.0" in bajo:
        # Win10 y Win11 reportan NT 10.0; el 11 trae el token 'WindowsWechat'?
        # Sin JS no se distinguen 100%: se marca 10/11.
        return "Windows 10/11"
    if "windows nt 6.3" in bajo:
        return "Windows 8.1"
    if "windows nt 6.2" in bajo:
        return "Windows 8"
    if "windows nt 6.1" in bajo:
        return "Windows 7"
    if "windows" in bajo:
        return "Windows"
    for so in ("Android", "iPhone", "iPad", "Mac OS", "Linux"):
        if so.lower() in bajo:
            return so
    return ""


MOTIVOS_SACAR = [
    "Ya no está disponible",
    "Cambio de cuenta",
    "Cambio de zona",
    "Novedad administrativa",
]

MOTIVOS_INGRESAR = [
    "Nueva asignación",
    "Reemplazo",
    "Cambio de zona",
    "Retorno / reactivación",
]


def _motivo_post(request):
    """Motivo que eligió el admin/observador en la ventana emergente.

    Acepta los 4 estándar de sacar/ingresar o un texto libre corto.
    Vacío = _auditar pone el motivo automático de la acción.
    """
    motivo = (request.POST.get("motivo") or "").strip()[:200]
    return motivo


def _avisar_supervisor(observador, titulo, mensaje, actor=None):
    """Avisa por campana al supervisor; nunca rompe el flujo del admin."""
    try:
        from apps.notificaciones import services as avisos

        nombre_actor = ""
        if actor is not None and getattr(actor, "pk", None):
            nombre_actor = getattr(actor, "nombre", "") or getattr(actor, "email", "")
        avisos.crear(
            observador, "sistema", titulo, mensaje,
            url=reverse("tickets:obs_monitoreo") + "#zonas-monitoreo",
            icono="i-users",
            actor=nombre_actor,
            actor_rol="Administrador",
        )
    except Exception:
        pass


def _norm_zona(nombre):
    """Normaliza nombres de zona para comparar (tildes aparte)."""
    return (nombre or "").strip().lower()


def _zonas_de(observador):
    return list(
        ObservadorPunto.objects.filter(observador=observador)
        .order_by("punto__nombre")
        .values_list("punto__nombre", flat=True)
    )


def _elementos_de(observador):
    """Los usuarios y zonas que el observador ya tiene en su lista."""
    return ElementoMiLista.objects.filter(observador=observador)


def _hace(dt, ahora):
    """Etiqueta relativa corta: hace 5 min, hace 2 h, hace 3 d."""
    segundos = max(0, int((ahora - dt).total_seconds()))
    if segundos < 60:
        return "ahora mismo"
    minutos = segundos // 60
    if minutos < 60:
        return f"hace {minutos} min"
    horas = minutos // 60
    if horas < 24:
        return f"hace {horas} h"
    dias = horas // 24
    if dias < 30:
        return f"hace {dias} d"
    return dt.strftime("%d/%m/%Y")


@admin_required
def monitoreo_admin(request):
    """Tabla de usuarios activos para guardarlos en una zona a monitorear."""
    observador_id = (request.GET.get("observador") or "").strip()
    q = (request.GET.get("q") or "")[:120].strip()
    rol = (request.GET.get("rol") or "").strip()
    zona = (request.GET.get("zona") or "").strip()
    estado = (request.GET.get("estado") or "").strip()

    observadores = list(
        Usuario.objects.filter(rol=Usuario.Rol.OBSERVADOR, activo=True)
        .order_by("nombre")
        .values_list("pk", "nombre")
    )

    observador = None
    if observador_id.isdigit():
        observador = Usuario.objects.filter(
            pk=int(observador_id), rol=Usuario.Rol.OBSERVADOR
        ).first()

    # Sin observador elegido se toma el primero, para que la vista siempre
    # muestre a alguien.
    if observador is None and observadores:
        observador = Usuario.objects.filter(pk=observadores[0][0]).first()

    observers_ids = {pk for pk, _ in observadores}
    elementos_por_correo = {
        (e.usuario_email or "").strip().lower(): e.pk
        for e in _elementos_de(observador) if (e.usuario_email or "").strip()
    } if observador else {}
    zona_por_correo = {}
    if observador:
        carpetas_sup = {}
        for n in ZonaObservador.objects.filter(
                observador=observador).values_list("nombre", flat=True):
            clave = _norm_zona(n)
            if clave and clave not in carpetas_sup:
                carpetas_sup[clave] = n.strip()
        for e in ElementoMiLista.objects.filter(observador=observador).select_related("zona", "punto"):
            c = (e.usuario_email or "").strip().lower()
            if not c or c in zona_por_correo:
                continue
            # Solo carpetas creadas: un punto suelto (ej. "Bogotá") no es zona,
            # salvo que exista la carpeta con ese mismo nombre.
            # getattr porque el FK puede estar huérfano en datos viejos.
            zona_nombre = getattr(e.zona, "nombre", "") if e.zona_id else ""
            punto_nombre = getattr(e.punto, "nombre", "") if e.punto_id else ""
            if zona_nombre.strip():
                zona_por_correo[c] = zona_nombre.strip()
            elif punto_nombre and _norm_zona(punto_nombre) in carpetas_sup:
                zona_por_correo[c] = carpetas_sup[_norm_zona(punto_nombre)]
    # La columna «Zona» refleja a qué zona pertenece cada cuenta aunque la
    # zona sea de OTRO supervisor: primero manda la del supervisor elegido,
    # y de ahí se rellena con el resto de zonas creadas del sistema.
    for correo_e, nombre_z in (
        ElementoMiLista.objects.exclude(zona__isnull=True)
        .exclude(usuario_email="")
        .values_list("usuario_email", "zona__nombre")
        .iterator()
    ):
        c = (correo_e or "").strip().lower()
        if not c or c in zona_por_correo:
            continue
        nombre_z = (nombre_z or "").strip()
        if nombre_z:
            zona_por_correo[c] = nombre_z
    ya_mis_lista = set(elementos_por_correo)
    zonas_ya = {
        (getattr(e.punto, "nombre", "") or "").strip()
        for e in _elementos_de(observador).select_related("punto")
    } if observador else set()
    carpetas_ya = {
        (getattr(e.zona, "nombre", "") or "").strip()
        for e in ElementoMiLista.objects.filter(
            observador=observador).select_related("zona")
        if e.zona_id
    } if observador else set()

    # Zonas que ve el observador elegido: las asignadas, las de su lista
    # y las carpetas con gente (aunque aún no tengan punto).
    _todas = {}
    for fuente in (set(_zonas_de(observador)), zonas_ya, carpetas_ya):
        for nombre in fuente:
            clave = _norm_zona(nombre)
            if clave and clave not in _todas:
                _todas[clave] = nombre.strip()
    zonas = sorted(_todas.values()) if observador else []
    if not zonas:
        zonas = sorted(Punto.objects.values_list("nombre", flat=True))

    # Lugares de donde salen los tickets: el filtro "zona" mira orígenes
    # reales (solicitante_punto), no las zonas ya asignadas.
    _vistos_pt = set()
    puntos_ticket = []
    for p in (
        Ticket.objects.exclude(solicitante_punto__isnull=True)
        .exclude(solicitante_punto="")
        .values_list("solicitante_punto", flat=True)
        .distinct().order_by("solicitante_punto")[:200]
    ):
        nombre = (p or "").strip()
        if nombre and nombre.lower() not in _vistos_pt:
            _vistos_pt.add(nombre.lower())
            puntos_ticket.append(nombre)
    puntos_por_correo = {}
    for email, punto in (
        Ticket.objects.exclude(solicitante_email__isnull=True)
        .exclude(solicitante_email="")
        .exclude(solicitante_punto__isnull=True)
        .exclude(solicitante_punto="")
        .values_list("solicitante_email", "solicitante_punto")
        .distinct()[:10000]
    ):
        clave = (email or "").strip().lower()
        if clave:
            puntos_por_correo.setdefault(clave, set()).add(punto)

    usuarios = Usuario.objects.filter(activo=True, is_active=True).exclude(
        pk__in=observers_ids
    )
    if rol:
        usuarios = usuarios.filter(rol=rol)
    if q:
        usuarios = usuarios.filter(
            Q(nombre__icontains=q) | Q(email__icontains=q)
            | Q(ubicacion__icontains=q)
        )

    # Tickets por solicitante, para ver a quien hay que mirar.
    abiertos = {
        fila["solicitante_email"]: fila["n"]
        for fila in Ticket.objects.filter(
            estado__in=[Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO]
        )
        .exclude(solicitante_email__in=[None, ""])
        .values("solicitante_email")
        .annotate(n=Count("pk"))
    }

    filas = []
    zona_buscada = (zona or "").strip().lower()
    for u in usuarios.order_by("nombre"):
        correo = (u.email or "").strip().lower()
        puntos = sorted(puntos_por_correo.get(correo, ()))
        if zona_buscada and zona_buscada not in {p.lower() for p in puntos}:
            continue
        puntos_txt = ", ".join(puntos[:2])
        if len(puntos) > 2:
            puntos_txt += f" +{len(puntos) - 2}"
        filas.append(
            {
                "obj": u,
                "nombre": u.nombre or u.email,
                "email": correo,
                "rol": u.get_rol_display(),
                "ubicacion": u.ubicacion or (puntos[0] if puntos else "") or "—",
                "zona_badge": zona_por_correo.get(correo, ""),
                "puntos": puntos_txt or "—",
                "abiertos": abiertos.get(correo, 0),
                "ya_agregado": correo in ya_mis_lista,
                "elemento_id": elementos_por_correo.get(correo),
            }
        )

    if estado == "agregados":
        filas = [f for f in filas if f["ya_agregado"]]
    elif estado == "pendientes":
        filas = [f for f in filas if not f["ya_agregado"]]
    elif estado == "con_tickets":
        filas = [f for f in filas if f["abiertos"] > 0]

    vistos_destino = set()
    carpetas_ord = []
    for n in ZonaObservador.objects.filter(observador=observador).order_by("-creado_en", "-pk").values_list("nombre", flat=True)[:50] if observador else []:
        clave = _norm_zona(n)
        if clave and clave not in vistos_destino:
            vistos_destino.add(clave)
            carpetas_ord.append(n.strip())
    zonas_destino = list(carpetas_ord)
    zonas_destino += [p.strip() for p in (zonas or []) if _norm_zona(p) not in vistos_destino][:50]
    zona_elegida = zona or (zonas_destino[0] if zonas_destino else "")
    creadas = _zonas_creadas_por_observador()

    # Serie real para las tarjetas de Monitoreo.  Se conservan las cifras
    # actuales de ``dash`` y se agrega únicamente su evolución reciente para
    # las minigráficas y las comparaciones con el período anterior.
    hoy = timezone.localdate()
    inicio_kpi = hoy - timedelta(days=13)
    dias_kpi = [inicio_kpi + timedelta(days=i) for i in range(14)]
    registros_zona_kpi = list(
        ZonaObservador.objects.values("observador_id", "creado_en")
    )

    def _fecha_kpi(valor):
        if not valor:
            return None
        return (
            timezone.localtime(valor).date()
            if timezone.is_aware(valor) else valor.date()
        )

    def _acumulada_kpi(fechas):
        antes = sum(1 for fecha in fechas if fecha and fecha < inicio_kpi)
        salida = []
        for dia in dias_kpi:
            antes += sum(1 for fecha in fechas if fecha == dia)
            salida.append(antes)
        return salida

    fechas_zona_kpi = [_fecha_kpi(z["creado_en"]) for z in registros_zona_kpi]
    fechas_cuenta_kpi = [
        _fecha_kpi(fecha)
        for fecha in ElementoMiLista.objects.filter(zona__isnull=False)
        .values_list("creado_en", flat=True)
    ]
    supervisores_por_dia = []
    vistos_supervisor = {
        registro["observador_id"] for registro in registros_zona_kpi
        if _fecha_kpi(registro["creado_en"]) and _fecha_kpi(registro["creado_en"]) < inicio_kpi
    }
    for dia in dias_kpi:
        for registro in registros_zona_kpi:
            fecha = _fecha_kpi(registro["creado_en"])
            if fecha and fecha <= dia:
                vistos_supervisor.add(registro["observador_id"])
        supervisores_por_dia.append(len(vistos_supervisor))
    abiertos_por_dia = Counter()
    for fecha in Ticket.objects.filter(
        estado__in=[Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO],
        fecha_creacion__date__gte=inicio_kpi,
    ).values_list("fecha_creacion", flat=True):
        dia = _fecha_kpi(fecha)
        if dia in dias_kpi:
            abiertos_por_dia[dia] += 1
    primeras_zonas = {}
    for registro in registros_zona_kpi:
        fecha = _fecha_kpi(registro["creado_en"])
        supervisor_id = registro["observador_id"]
        if fecha and (supervisor_id not in primeras_zonas or fecha < primeras_zonas[supervisor_id]):
            primeras_zonas[supervisor_id] = fecha
    altas_supervisores = Counter(primeras_zonas.values())
    altas_zonas = Counter(fecha for fecha in fechas_zona_kpi if fecha)
    altas_cuentas = Counter(fecha for fecha in fechas_cuenta_kpi if fecha)
    series_completas = {
        "supervisores": [altas_supervisores[dia] for dia in dias_kpi],
        "zonas": [altas_zonas[dia] for dia in dias_kpi],
        "cuentas": [altas_cuentas[dia] for dia in dias_kpi],
        "abiertos": [abiertos_por_dia[dia] for dia in dias_kpi],
    }

    # Para el porcentaje no se suman curvas acumuladas: eso duplicaría el
    # mismo registro por cada día. Se comparan únicamente las altas reales
    # de cada semana, o los tickets aún abiertos creados en ese lapso.
    def _tendencia_kpi(anterior, actual, desfavorable=False, detalle="vs. 7 días anteriores"):
        if not anterior and not actual:
            return None
        if not anterior:
            return {
                "texto": "Nuevo", "clase": "is-neutral",
                "detalle": "sin actividad previa",
            }
        cambio = round((actual - anterior) * 100 / anterior)
        favorable = cambio <= 0 if desfavorable else cambio >= 0
        return {
            "texto": f"{cambio:+d}%",
            "clase": "is-positive" if favorable else "is-negative",
            "detalle": detalle,
        }

    zonas_semana_anterior = sum(
        1 for fecha in fechas_zona_kpi if fecha and dias_kpi[0] <= fecha < dias_kpi[7]
    )
    zonas_semana_actual = sum(
        1 for fecha in fechas_zona_kpi if fecha and fecha >= dias_kpi[7]
    )
    cuentas_semana_anterior = sum(
        1 for fecha in fechas_cuenta_kpi if fecha and dias_kpi[0] <= fecha < dias_kpi[7]
    )
    cuentas_semana_actual = sum(
        1 for fecha in fechas_cuenta_kpi if fecha and fecha >= dias_kpi[7]
    )
    supervisores_semana_anterior = {
        registro["observador_id"] for registro in registros_zona_kpi
        if (fecha := _fecha_kpi(registro["creado_en"])) and dias_kpi[0] <= fecha < dias_kpi[7]
    }
    supervisores_semana_actual = {
        registro["observador_id"] for registro in registros_zona_kpi
        if (fecha := _fecha_kpi(registro["creado_en"])) and fecha >= dias_kpi[7]
    }

    dash_series = {
        "labels": [dia.strftime("%d/%m") for dia in dias_kpi[7:]],
        "series": {clave: valores[7:] for clave, valores in series_completas.items()},
    }
    dash_tendencias = {
        "supervisores": _tendencia_kpi(
            len(supervisores_semana_anterior), len(supervisores_semana_actual),
            detalle="altas vs. 7 días anteriores",
        ),
        "zonas": _tendencia_kpi(
            zonas_semana_anterior, zonas_semana_actual,
            detalle="altas vs. 7 días anteriores",
        ),
        "cuentas": _tendencia_kpi(
            cuentas_semana_anterior, cuentas_semana_actual,
            detalle="altas vs. 7 días anteriores",
        ),
        "abiertos": _tendencia_kpi(
            sum(series_completas["abiertos"][:7]),
            sum(series_completas["abiertos"][7:]),
            desfavorable=True,
            detalle="creados vs. 7 días anteriores",
        ),
    }
    return render(
        request,
        "tickets/monitoreo_admin.html",
        {
            "filas": filas,
            "observadores": observadores,
            "observador": observador,
            "observador_id": str(observador.pk) if observador else "",
            "q": q,
            "rol_sel": rol,
            "zona_sel": zona,
            "estado_sel": estado,
            "zonas": zonas,
            "puntos_ticket": puntos_ticket,
            "zonas_destino": zonas_destino,
            "zona_elegida": zona_elegida,
            "total": len(filas),
            "zonas_creadas": creadas,
            "auditoria": _auditoria_enriquecida(),
            "aud_hoy": MonitoreoAuditoria.objects.filter(
                fecha__date=timezone.localdate()).count(),
            "aud_semana": MonitoreoAuditoria.objects.filter(
                fecha__gte=timezone.now() - timedelta(days=7)).count(),
            "dash": {
                "supervisores": len(creadas),
                "zonas": sum(len(b["zonas"]) for b in creadas),
                "cuentas": sum(
                    len(z["miembros"]) for b in creadas for z in b["zonas"]
                ),
                "abiertos": sum(
                    z["abiertos"] for b in creadas for z in b["zonas"]
                ),
            },
            "dash_series": dash_series,
            "dash_tendencias": dash_tendencias,
        },
    )


@admin_required
def monitoreo_zona_detalle(request, pk):
    """Abre en modo de solo lectura las cuentas de una zona para el admin."""
    try:
        zona = ZonaObservador.objects.select_related("observador").get(pk=pk)
    except ZonaObservador.DoesNotExist:
        raise Http404

    from .views_observador import _cuentas_y_tickets_de_zona

    filas, _ = _cuentas_y_tickets_de_zona(zona, global_scope=True)
    total_tickets = sum(fila["total"] for fila in filas)
    orden = {"verde": 0, "amarillo": 1, "rojo": 2}
    estado = "verde"
    for fila in filas:
        if orden[fila["estado"]] > orden[estado]:
            estado = fila["estado"]
    resumen = {
        "cuentas": len(filas),
        "total": total_tickets,
        "abiertos": sum(fila["abiertos"] for fila in filas),
        "resueltos": sum(fila["cerrados_total"] for fila in filas),
        "avance": (
            int(round(
                100.0 * sum(fila["cerrados_total"] for fila in filas)
                / total_tickets
            ))
            if total_tickets else 0
        ),
        "estado": estado,
    }
    resumen["falta"] = 100 - resumen["avance"]
    return render(
        request,
        "observador/zona_detalle.html",
        {"zona": zona, "filas": filas, "resumen": resumen, "admin": True},
    )


def _auditoria_enriquecida(limite=20, consulta=None):
    """Últimos cambios con etiqueta relativa de tiempo para la tabla."""
    ahora = timezone.now()
    filas = list(
        (consulta if consulta is not None else MonitoreoAuditoria.objects.all()).select_related("actor", "observador")[:limite]
    )
    for a in filas:
        a.hace = _hace(a.fecha, ahora)
    return filas


@admin_required
@require_GET
def monitoreo_actividad_supervisor(request, pk):
    """Actividad reciente de las zonas actualmente asignadas al supervisor."""
    from apps.notificaciones.models import AlertaOperativa
    from .models import TicketTransicionANS

    zonas = list(ZonaObservador.objects.filter(observador_id=pk).values_list("pk", "nombre"))
    if not zonas:
        raise Http404
    nombres = [nombre for _, nombre in zonas]
    miembros = ElementoMiLista.objects.filter(zona_id__in=[identificador for identificador, _ in zonas])
    correos = set(miembros.exclude(usuario_email="").values_list("usuario_email", flat=True))
    correos = {correo.strip().lower() for correo in correos if correo and correo.strip()}
    tickets = Ticket.objects.annotate(_correo_zona=Lower("solicitante_email")).filter(_correo_zona__in=correos)
    eventos = []
    def agregar(fecha, titulo, detalle, url=""):
        if fecha:
            eventos.append((fecha, {"titulo": titulo, "detalle": detalle, "url": url, "fecha": timezone.localtime(fecha).strftime("%d/%m/%Y %I:%M %p")}))
    for registro in MonitoreoAuditoria.objects.filter(observador_id=pk, zona_nombre__in=nombres)[:30]:
        agregar(registro.fecha, registro.get_accion_display(), f"{registro.zona_nombre} · {registro.detalle or registro.cuenta}")
    for ticket in tickets.order_by("-fecha_creacion")[:30]:
        agregar(ticket.fecha_creacion, f"Nuevo ticket {ticket.codigo}", ticket.titulo, reverse("tickets:detalle", args=[ticket.pk]))
    for comentario in TicketComentario.objects.filter(ticket__in=tickets).select_related("ticket").order_by("-fecha")[:30]:
        agregar(comentario.fecha, f"Respuesta en {comentario.ticket.codigo}", comentario.comentario[:180], reverse("tickets:detalle", args=[comentario.ticket_id]))
    for cambio in TicketTransicionANS.objects.filter(ticket__in=tickets).select_related("ticket").order_by("-ocurrido_en")[:30]:
        agregar(cambio.ocurrido_en, f"Cambio de estado · {cambio.ticket.codigo}", f"{cambio.estado_anterior} → {cambio.estado_nuevo}", reverse("tickets:detalle", args=[cambio.ticket_id]))
    for alerta in AlertaOperativa.objects.filter(ticket__in=tickets, tipo="ans_vencido").select_related("ticket").order_by("-creada_en")[:30]:
        agregar(alerta.creada_en, f"ANS vencido · {alerta.codigo_ticket}", alerta.titulo_ticket, reverse("tickets:detalle", args=[alerta.ticket_id]))
    eventos.sort(key=lambda evento: evento[0], reverse=True)
    return JsonResponse({"eventos": [evento for _, evento in eventos[:30]]})


def _zonas_creadas_por_observador():
    """Zonas que creó cada observador, con su gente y sus números.

    Es lo que el administrador ve y administra: el supervisor a cargo de
    cada zona (el observador que la creó), las cuentas que tiene dentro y
    el estado de sus tickets. Sin zonas creadas, va vacío.
    """
    # Se agrupa por quien creó la zona, no solo por quien hoy tiene el rol:
    # si al supervisor le cambian el rol, su zona seguía sin aparecer aquí
    # (o la página reventaba con KeyError). Con el dueño real siempre sale.
    zonas = list(
        ZonaObservador.objects.select_related("observador")
        .prefetch_related("elementos__usuario")
        .order_by("observador__nombre", "nombre")
    )
    if not zonas:
        return []
    supervisores = list(
        Usuario.objects.filter(rol=Usuario.Rol.OBSERVADOR).order_by("nombre")
    )
    correos = {
        (e.usuario_email or "").strip().lower()
        for z in zonas for e in z.elementos.all()
        if (e.usuario_email or "").strip()
    }
    totales, abiertos, urgentes, tecnicos = {}, {}, {}, {}
    ids_usuarios = {e.usuario_id for z in zonas for e in z.elementos.all() if e.usuario_id}
    presiones = {}
    if ids_usuarios:
        for fila in (TicketComentario.objects.filter(es_presion=True, usuario_id__in=ids_usuarios)
                     .values("usuario_id", "ticket__solicitante_email").annotate(n=Count("pk"))):
            clave = (fila["usuario_id"], (fila["ticket__solicitante_email"] or "").strip().lower())
            presiones[clave] = presiones.get(clave, 0) + fila["n"]
    if correos:
        for fila in (
            Ticket.objects.exclude(solicitante_email__in=[None, ""])
            .values("solicitante_email")
            .annotate(n=Count("pk"))
        ):
            totales[(fila["solicitante_email"] or "").strip().lower()] = fila["n"]
        for fila in (
            Ticket.objects.filter(
                estado__in=[Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO]
            )
            .exclude(solicitante_email__in=[None, ""])
            .values("solicitante_email")
            .annotate(n=Count("pk"))
        ):
            abiertos[(fila["solicitante_email"] or "").strip().lower()] = fila["n"]
        for fila in (
            Ticket.objects.filter(
                estado__in=[Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO],
                prioridad=Ticket.Prioridad.URGENTE,
            )
            .exclude(solicitante_email__in=[None, ""])
            .values("solicitante_email")
            .annotate(n=Count("pk"))
        ):
            urgentes[(fila["solicitante_email"] or "").strip().lower()] = fila["n"]
        for t in Ticket.objects.exclude(
            solicitante_email__in=[None, ""]
        ).select_related("tecnico_asignado").only(
            "solicitante_email", "tecnico_asignado__nombre"
        ):
            correo = (t.solicitante_email or "").strip().lower()
            nombre = ((t.tecnico_asignado.nombre if t.tecnico_asignado_id else "") or "").strip()
            if correo in correos and nombre:
                tecnicos.setdefault(correo, {}).setdefault(nombre, 0)
                tecnicos[correo][nombre] += 1
    conteos_ans = {}
    tickets_ans_por_correo = {}
    ans_por_ticket = {}
    if correos:
        consulta_ans = Ticket.objects.annotate(
            correo_normalizado=Lower("solicitante_email")
        ).filter(correo_normalizado__in=correos)
        tickets_ans = ans_avisos.por_vencer(
            consulta=consulta_ans,
            limite=max(consulta_ans.count(), 1),
            solo_sin_avisar=False,
        )
        for ticket in tickets_ans:
            correo = (ticket.solicitante_email or "").strip().lower()
            conteos = conteos_ans.setdefault(
                correo, {"vencidos": 0, "por_vencer": 0}
            )
            clave = "vencidos" if ticket.ans_estado == "vencido" else "por_vencer"
            conteos[clave] += 1
            ans_por_ticket[ticket.pk] = {
                "estado": ticket.ans_estado,
                "texto": ticket.ans_texto,
            }
            if ticket.tecnico_asignado_id:
                tickets_ans_por_correo.setdefault(correo, []).append(
                    {
                        "pk": ticket.pk,
                        "codigo": ticket.codigo,
                        "titulo": ticket.titulo,
                        "tecnico": ticket.tecnico_asignado.nombre or ticket.tecnico_asignado.email,
                        "estado": ticket.ans_estado,
                        "ans_texto": ticket.ans_texto,
                    }
                )
    detalles_tickets = {}
    if correos:
        for ticket in (
            Ticket.objects.annotate(
                correo_normalizado=Lower("solicitante_email")
            ).filter(correo_normalizado__in=correos)
            .select_related("tecnico_asignado", "categoria")
            .order_by("-fecha_creacion")
        ):
            correo = (ticket.solicitante_email or "").strip().lower()
            ans = ans_por_ticket.get(ticket.pk)
            detalles_tickets.setdefault(correo, []).append(
                {
                    "pk": ticket.pk,
                    "codigo": ticket.codigo,
                    "titulo": ticket.titulo,
                    "estado": ticket.estado,
                    "fue_resuelto": ticket.fue_resuelto,
                    "estado_display": ticket.get_estado_display(),
                    "fecha": timezone.localtime(ticket.fecha_creacion).strftime("%d/%m/%Y"),
                    "tecnico": (
                        ticket.tecnico_asignado.nombre
                        if ticket.tecnico_asignado_id else ""
                    ),
                    "ans_estado": ans["estado"] if ans else "",
                    "ans_texto": ans["texto"] if ans else "",
                }
            )
    por_supervisor = {}
    for sup in supervisores:
        por_supervisor[sup.pk] = {
            "supervisor": sup,
            "puntos": _zonas_de(sup),
            "zonas": [],
        }
    for z in zonas:
        if z.observador_id not in por_supervisor:
            # Dueño sin rol de observador (se lo cambiaron): igual se muestra,
            # marcando su rol actual en la tarjeta.
            por_supervisor[z.observador_id] = {
                "supervisor": z.observador,
                "puntos": _zonas_de(z.observador),
                "zonas": [],
            }
    for z in zonas:
        miembros = []
        for e in z.elementos.all():
            correo = (e.usuario_email or "").strip().lower()
            cuentas_tec = tecnicos.get(correo, {})
            tickets = detalles_tickets.get(correo, [])
            resueltos = sum(
                1 for ticket in tickets
                if ticket["fue_resuelto"]
            )
            cerrados = sum(
                1 for ticket in tickets
                if ticket["estado"] in (Ticket.Estado.CERRADO, Ticket.Estado.RESUELTO)
            )
            abiertos_cuenta = abiertos.get(correo, 0)
            total_cuenta = totales.get(correo, 0)
            miembros.append(
                {
                    "elemento_id": e.pk,
                    "nombre": (e.usuario.nombre if e.usuario_id else "") or correo or "—",
                    "avatar": e.usuario.avatar if e.usuario_id else None,
                    "email": correo,
                    "presiones": presiones.get((e.usuario_id, correo), 0),
                    "rol": e.usuario.get_rol_display() if e.usuario_id else "Sin cuenta",
                    "ubicacion": (e.usuario.ubicacion if e.usuario_id else "") or "—",
                    "horario_atencion": (e.usuario.horario_atencion if e.usuario_id else ""),
                    "cuenta_activa": e.usuario.activo and e.usuario.is_active if e.usuario_id else None,
                    "total": total_cuenta,
                    "abiertos": abiertos_cuenta,
                    "resueltos": resueltos,
                    "cerrados": cerrados,
                    "avance": (
                        int(round(100.0 * (total_cuenta - abiertos_cuenta) / total_cuenta))
                        if total_cuenta else 0
                    ),
                    "urgentes": urgentes.get(correo, 0),
                    "ans_vencidos": conteos_ans.get(correo, {}).get("vencidos", 0),
                    "ans_por_vencer": conteos_ans.get(correo, {}).get("por_vencer", 0),
                    "ans_tickets": tickets_ans_por_correo.get(correo, []),
                    "tickets": tickets,
                    "tecnico": max(cuentas_tec.items(), key=lambda kv: kv[1])[0] if cuentas_tec else "—",
                }
            )
        miembros.sort(key=lambda m: (-m["abiertos"], m["nombre"].lower()))
        total_zona = sum(m["total"] for m in miembros)
        abiertos_zona = sum(m["abiertos"] for m in miembros)
        urgentes_zona = sum(urgentes.get(m["email"], 0) for m in miembros)
        por_supervisor[z.observador_id]["zonas"].append(
            {
                "zona": z,
                "miembros": miembros,
                "abiertos": abiertos_zona,
                "total": total_zona,
                "cerrados": total_zona - abiertos_zona,
                "urgentes": urgentes_zona,
                "avance": (
                    int(round(100.0 * (total_zona - abiertos_zona) / total_zona))
                    if total_zona else 0
                ),
            }
        )
    return [v for v in por_supervisor.values() if v["zonas"]]


@admin_required
@login_required
@require_POST
def monitoreo_zona_color(request, pk):
    """Actualiza el color de una zona desde la tira del panel administrador."""
    from apps.tickets.views_observador import PALETA_ZONA

    volver = _retorno_monitoreo(request)
    zona = ZonaObservador.objects.filter(pk=pk).first()
    if zona is None:
        raise Http404
    color = (request.POST.get("color") or "").strip().upper()
    if color and color not in PALETA_ZONA:
        raise Http404
    zona.color = color
    zona.save(update_fields=["color"])
    return redirect(volver)


@admin_required
@login_required
@require_POST
def monitoreo_presionar_tecnico(request, pk):
    """Permite al administrador enviar una presión visible a un técnico."""
    from .notifications import notificar_comentario

    try:
        ticket = Ticket.objects.select_related("tecnico_asignado").get(pk=pk)
    except (Ticket.DoesNotExist, ValueError, TypeError):
        raise Http404

    volver = reverse("tickets:monitoreo_admin")
    mensaje = (request.POST.get("mensaje") or "").strip()[:500]
    if not mensaje:
        messages.error(request, "Escribe el mensaje para el técnico.")
        return redirect(volver)
    if ticket.estado not in (Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO):
        messages.error(request, "Solo se puede presionar por tickets activos.")
        return redirect(volver)
    if not ticket.tecnico_asignado_id:
        messages.error(request, "El ticket no tiene un técnico asignado.")
        return redirect(volver)
    estado_ans = ticket.datos_ans[0]
    if estado_ans not in ans_avisos.AVISABLES:
        messages.error(request, "El ticket ya no está próximo a vencer ni vencido según su ANS.")
        return redirect(volver)

    TicketComentario.objects.create(
        ticket=ticket,
        usuario=request.user,
        autor_nombre=request.user.nombre,
        comentario=mensaje,
        es_interno=False,
        es_presion=True,
    )
    notificar_comentario(ticket, request.user.nombre, mensaje, actor=request.user)
    messages.success(request, f"Mensaje enviado al técnico del {ticket.codigo}.")
    return redirect(volver)


@admin_required
@login_required
def monitoreo_agregar(request):
    """Guarda un usuario en la zona elegida para que el observador lo vigile."""
    if request.method != "POST":
        return redirect(reverse("tickets:monitoreo_admin"))

    observador_id = request.POST.get("observador") or ""
    correo = (request.POST.get("email") or "").strip().lower()
    nombre_zona = (request.POST.get("zona") or "").strip()
    volver = _retorno_monitoreo(request)

    observador = Usuario.objects.filter(
        pk=observador_id, rol=Usuario.Rol.OBSERVADOR
    ).first() if observador_id.isdigit() else None
    if observador is None or not correo:
        return redirect(volver)

    # Un usuario en zona no entra a otra.
    if nombre_zona:
        otra = ElementoMiLista.objects.filter(
            usuario_email__iexact=correo, zona__isnull=False
        ).exclude(
            zona__observador=observador, zona__nombre__iexact=nombre_zona
        ).select_related("zona").first()
        if otra is not None:
            messages.error(
                request, f"{correo} ya está en la zona «{(otra.zona.nombre if otra.zona else '')}»."
            )
            return redirect(volver)

    punto = None
    carpeta = None
    if nombre_zona:
        # Sin crear puntos fantasma: solo se enlaza lo que ya existe.
        punto = Punto.objects.filter(nombre__iexact=nombre_zona).first()
        carpeta = ZonaObservador.objects.filter(
            observador=observador, nombre__iexact=nombre_zona).first()

    # Si ya estaba en la lista, se actualiza la zona en vez de duplicarlo.
    datos = {
        "tipo": ElementoMiLista.TIPO_USUARIO,
        "usuario": Usuario.objects.filter(email__iexact=correo).first(),
        "punto": punto,
    }
    if carpeta is not None:
        datos["zona"] = carpeta
    ElementoMiLista.objects.update_or_create(
        observador=observador,
        usuario_email=correo,
        defaults=datos,
    )
    _auditar(
        request.user, MonitoreoAuditoria.AGREGAR_LISTA, observador,
        nombre_zona, f"Entró a la zona {nombre_zona or 'sin zona'}",
        request=request, cuenta=correo, motivo=_motivo_post(request),
    )
    _avisar_supervisor(
        observador,
        f"{correo} entró a tu zona {nombre_zona or 'sin zona'}",
        f"El administrador la agregó al seguimiento.",
        request.user,
    )

    # La zona tambien queda asignada al observador para que pueda verla.
    if punto is not None:
        ObservadorPunto.objects.get_or_create(observador=observador, punto=punto)

    return redirect(volver)


@admin_required
@require_GET
def monitoreo_cuentas_buscar(request):
    """Cuentas activas por nombre o correo, para asignar a una zona.

    Devuelve hasta 8 coincidencias (nombre, correo): el desplegable de
    asignar elige de ahí en vez de pedir el correo a mano.
    """
    from django.db.models import Q

    q = (request.GET.get("q") or "").strip()[:120]
    rol = (request.GET.get("rol") or "").strip()
    resultados = []
    if len(q) >= 2:
        consulta = Usuario.objects.filter(
            Q(nombre__icontains=q) | Q(email__icontains=q),
            activo=True, is_active=True,
        )
        if rol:
            consulta = consulta.filter(rol=rol)
        for u in consulta.order_by("nombre")[:8]:
            resultados.append({
                "nombre": u.nombre or u.email,
                "email": u.email,
                "rol": u.rol,
            })
    return JsonResponse({"ok": True, "cuentas": resultados})


@admin_required
@require_POST
def monitoreo_quitar_zona(request):
    """Saca una cuenta del seguimiento del supervisor.

    No depende de la zona elegida en el desplegable: se quita de donde
    esté (su zona real) y se avisa cuál era, para que el botón siempre
    responda.
    """
    observador_id = request.POST.get("observador") or ""
    correo = (request.POST.get("email") or "").strip().lower()
    volver = _retorno_monitoreo(request)
    observador = Usuario.objects.filter(
        pk=observador_id, rol=Usuario.Rol.OBSERVADOR
    ).first() if observador_id.isdigit() else None
    if observador is None or not correo:
        return redirect(volver)
    elemento = ElementoMiLista.objects.filter(
        observador=observador, usuario_email__iexact=correo
    ).select_related("punto", "zona").first()
    if elemento is None:
        messages.info(request, "Esa cuenta ya no está en el seguimiento.")
        return redirect(volver)
    zona_real = ((getattr(elemento.zona, "nombre", "") or "").strip()
                 or (getattr(elemento.punto, "nombre", "") or "").strip())
    elemento.delete()
    _auditar(request.user, MonitoreoAuditoria.QUITAR_MIEMBRO,
             observador, zona_real, f"Salió de la zona {zona_real or 'sin zona'}",
             request=request, cuenta=correo, motivo=_motivo_post(request))
    _avisar_supervisor(
        observador,
        f"{correo} salió de tu zona {zona_real or 'sin zona'}",
        "El administrador la sacó del seguimiento.",
        request.user,
    )
    if zona_real:
        messages.success(request, f"{correo} fuera de {zona_real}.")
    else:
        messages.success(request, f"{correo} fuera del seguimiento.")
    return redirect(volver)


@admin_required
@login_required
def monitoreo_quitar(request, pk):
    """Saca un elemento de la lista del observador."""
    if request.method != "POST":
        return redirect(reverse("tickets:monitoreo_admin"))
    observador_id = request.POST.get("observador") or ""
    volver = _retorno_monitoreo(request)
    sacado = ElementoMiLista.objects.filter(
        pk=pk, observador__pk=observador_id if observador_id.isdigit() else 0
    ).select_related("zona").first()
    correo_sacado = (sacado.usuario_email or "") if sacado else ""
    zona_sacada = (sacado.zona.nombre if sacado and sacado.zona_id else "")
    borrados, _ = ElementoMiLista.objects.filter(
        pk=pk, observador__pk=observador_id if observador_id.isdigit() else 0
    ).delete()
    if borrados:
        _auditar(
            request.user, MonitoreoAuditoria.QUITAR_LISTA,
            Usuario.objects.filter(pk=observador_id).first() if observador_id.isdigit() else None,
            zona_sacada, "Salió del seguimiento",
            request=request, cuenta=correo_sacado, motivo=_motivo_post(request),
            comentarios=f"elemento {pk}",
        )
    return redirect(volver)


@admin_required
@login_required
def monitoreo_zona_miembro_quitar(request, pk):
    """Saca una cuenta de la zona (queda en la lista, sin zona)."""
    if request.method != "POST":
        return redirect(reverse("tickets:monitoreo_admin"))
    volver = _retorno_monitoreo(request)
    elemento = ElementoMiLista.objects.filter(pk=pk).select_related("zona", "punto").first()
    if elemento is None or elemento.zona_id is None:
        return redirect(volver)
    nombre_zona = elemento.zona.nombre if elemento.zona else ""
    supervisor = elemento.observador
    elemento.zona = None
    punto = getattr(elemento, "punto", None)
    if punto is not None and _norm_zona(getattr(punto, "nombre", "")) == _norm_zona(nombre_zona):
        elemento.punto = None
    elemento.save(update_fields=["zona", "punto"])
    _auditar(
        request.user, MonitoreoAuditoria.QUITAR_MIEMBRO, supervisor,
        nombre_zona, f"Salió de la zona {nombre_zona or 'sin zona'}",
        request=request, cuenta=elemento.usuario_email or "",
        motivo=_motivo_post(request),
    )
    return redirect(volver)


@admin_required
@login_required
@require_POST
def monitoreo_zona_miembros_quitar(request):
    """Saca las cuentas seleccionadas de una zona sin borrarlas de la lista."""
    from django.contrib import messages

    volver = _retorno_monitoreo(request)
    zona_id = request.POST.get("zona_id") or ""
    ids = {valor for valor in request.POST.getlist("elemento_ids") if valor.isdigit()}
    zona = ZonaObservador.objects.filter(pk=zona_id).first() if zona_id.isdigit() else None
    if zona is None or not ids:
        messages.error(request, "Selecciona al menos una cuenta de la zona.")
        return redirect(volver)

    elementos = list(
        ElementoMiLista.objects.filter(pk__in=ids, zona=zona)
        .select_related("observador", "punto")
    )
    for elemento in elementos:
        punto = elemento.punto
        elemento.zona = None
        update_fields = ["zona"]
        if punto is not None and _norm_zona(punto.nombre) == _norm_zona(zona.nombre):
            elemento.punto = None
            update_fields.append("punto")
        elemento.save(update_fields=update_fields)
        _auditar(
            request.user, MonitoreoAuditoria.QUITAR_MIEMBRO, elemento.observador,
            zona.nombre, f"Salió de la zona {zona.nombre}",
            request=request, cuenta=elemento.usuario_email or "",
            motivo=_motivo_post(request),
        )
    if elementos:
        messages.success(request, f"Se quitaron {len(elementos)} cuenta(s) de la zona.")
    else:
        messages.error(request, "Las cuentas seleccionadas ya no pertenecen a esa zona.")
    return redirect(volver)


@admin_required
@login_required
def monitoreo_zona_eliminar(request, pk):
    """Elimina una zona creada por un observador (su gente no se borra)."""
    if request.method != "POST":
        return redirect(reverse("tickets:monitoreo_admin"))
    volver = _retorno_monitoreo(request)
    zona = ZonaObservador.objects.select_related("observador").filter(pk=pk).first()
    if zona is not None:
        _auditar(
            request.user, MonitoreoAuditoria.ELIMINAR_ZONA, zona.observador,
            zona.nombre, f"Zona «{zona.nombre}» eliminada ({zona.elementos.count()} cuentas)",
            request=request,
        )
        zona.delete()
    return redirect(volver)


@admin_required
@login_required
def monitoreo_zona_renombrar(request, pk):
    """Renombra una zona desde el panel del administrador."""
    if request.method != "POST":
        return redirect(reverse("tickets:monitoreo_admin"))
    volver = _retorno_monitoreo(request)
    zona = ZonaObservador.objects.select_related("observador").filter(pk=pk).first()
    if zona is None:
        return redirect(volver)
    nombre = (request.POST.get("nombre") or "").strip()[:80]
    if not nombre:
        messages.error(request, "El nombre nuevo no puede quedar vacío.")
        return redirect(volver)
    if ZonaObservador.objects.filter(
        observador=zona.observador, nombre__iexact=nombre
    ).exclude(pk=zona.pk).exists():
        messages.error(
            request, f"{zona.observador.nombre} ya tiene una zona llamada «{nombre}»."
        )
        return redirect(volver)
    anterior = zona.nombre
    zona.nombre = nombre
    zona.save(update_fields=["nombre"])
    _auditar(
        request.user, MonitoreoAuditoria.RENOMBRAR_ZONA, zona.observador,
        nombre, f"Zona «{anterior}» ahora se llama «{nombre}»", request=request,
        comentarios=f"Nombre anterior: {anterior}",
    )
    messages.success(request, f"Zona «{anterior}» ahora se llama «{nombre}».")
    return redirect(volver)


@admin_required
@login_required
def monitoreo_zona_crear(request):
    """Crea una zona para un supervisor desde el panel del administrador."""
    if request.method != "POST":
        return redirect(reverse("tickets:monitoreo_admin"))
    volver = _retorno_monitoreo(request)
    observador_id = request.POST.get("observador") or ""
    nombre = (request.POST.get("nombre") or "").strip()[:80]
    observador = Usuario.objects.filter(
        pk=observador_id, rol=Usuario.Rol.OBSERVADOR
    ).first() if observador_id.isdigit() else None
    if observador is None:
        messages.error(request, "Elige un supervisor válido para la zona.")
        return redirect(volver)
    if not nombre:
        messages.error(request, "Ponle un nombre a la zona para crearla.")
        return redirect(volver)
    if ZonaObservador.objects.filter(
        observador=observador, nombre__iexact=nombre
    ).exists():
        messages.error(
            request, f"{observador.nombre} ya tiene una zona llamada «{nombre}»."
        )
        return redirect(volver)
    zona = ZonaObservador.objects.create(
        observador=observador, nombre=nombre,
        version_sistema=_version_equipo(request),
        notif_correo=request.POST.get("notif_correo", "on") == "on",
        notif_popup=request.POST.get("notif_popup", "on") == "on",
        perm_exportar=request.POST.get("perm_exportar", "on") == "on",
        perm_historial=request.POST.get("perm_historial", "on") == "on",
    )
    agregados = 0
    omitidos = []
    vistos = set()
    for correo in (request.POST.get("miembros") or "").split(","):
        correo = correo.strip().lower()[:150]
        if not correo or "@" not in correo or correo in vistos:
            continue
        vistos.add(correo)
        if len(vistos) > 50:
            break
        # Un usuario en zona no entra a otra: se omite y se avisa.
        otra = ElementoMiLista.objects.filter(
            usuario_email__iexact=correo, zona__isnull=False
        ).exclude(zona__pk=zona.pk).select_related("zona").first()
        if otra is not None:
            omitidos.append(f"{correo} (ya está en «{(otra.zona.nombre if otra.zona else '')}»)")
            continue
        elemento, _ = ElementoMiLista.objects.get_or_create(
            observador=observador,
            usuario_email=correo,
            defaults={
                "tipo": ElementoMiLista.TIPO_USUARIO,
                "usuario": Usuario.objects.filter(email__iexact=correo).first(),
                "zona": zona,
            },
        )
        if elemento.zona_id != zona.pk:
            elemento.zona = zona
            elemento.save(update_fields=["zona"])
        _auditar(
            request.user, MonitoreoAuditoria.AGREGAR_MIEMBRO, observador,
            nombre, f"Entró a la zona «{nombre}»",
            request=request, cuenta=correo,
        )
        agregados += 1
    _auditar(request.user, MonitoreoAuditoria.CREAR_ZONA, observador, nombre,
             f"Zona «{nombre}» creada para {observador.nombre}",
             request=request)
    _avisar_supervisor(
        observador,
        f"Te crearon la zona {nombre}",
        "El administrador te habilitó una carpeta nueva.",
        request.user,
    )
    messages.success(
        request, f"Zona «{nombre}» creada para {observador.nombre}."
        + (f" ({agregados} cuenta{'s' if agregados != 1 else ''})" if agregados else "")
    )
    if omitidos:
        messages.warning(
            request, "No entraron (ya están en otra zona): " + ", ".join(omitidos[:5])
            + ("…" if len(omitidos) > 5 else "")
        )
    return redirect(volver)


@admin_required
@login_required
def monitoreo_zona_miembro_agregar(request, pk):
    """Mete una cuenta a la zona desde el panel del administrador."""
    if request.method != "POST":
        return redirect(reverse("tickets:monitoreo_admin"))
    volver = _retorno_monitoreo(request)
    zona = ZonaObservador.objects.select_related("observador").filter(pk=pk).first()
    if zona is None:
        return redirect(volver)
    correo = (request.POST.get("email") or "").strip().lower()
    if not correo:
        messages.error(request, "Escribe el correo de la cuenta para agregarla.")
        return redirect(volver)
    # Un usuario en zona no entra a otra.
    otra = ElementoMiLista.objects.filter(
        usuario_email__iexact=correo, zona__isnull=False
    ).exclude(zona__pk=zona.pk).select_related("zona").first()
    if otra is not None:
        messages.error(
            request, f"{correo} ya está en la zona «{(otra.zona.nombre if otra.zona else '')}»."
        )
        return redirect(volver)
    elemento, creado = ElementoMiLista.objects.get_or_create(
        observador=zona.observador,
        usuario_email=correo,
        defaults={
            "tipo": ElementoMiLista.TIPO_USUARIO,
            "usuario": Usuario.objects.filter(email__iexact=correo).first(),
            "zona": zona,
        },
    )
    if not creado and elemento.zona_id != zona.pk:
        elemento.zona = zona
        elemento.save(update_fields=["zona"])
    _auditar(
        request.user, MonitoreoAuditoria.AGREGAR_MIEMBRO, zona.observador,
        zona.nombre, f"Entró a la zona «{zona.nombre}»",
        request=request, cuenta=correo, motivo=_motivo_post(request),
    )
    messages.success(request, f"{correo} quedó en la zona «{zona.nombre}».")
    return redirect(volver)


_VISTA_PRINCIPAL_POR_ROL = {
    "admin": "Panel de administración",
    "tecnico": "Panel Técnico",
    "usuario": "Mis solicitudes",
    "observador": "Monitoreo",
}


@admin_required
def monitoreo_cuenta_detalle(request, pk):
    """Vista principal de la cuenta en seguimiento, según su rol.

    Al darle clic al nombre (o a la fila) se abre lo mismo que ve esa
    cuenta al entrar, pero con todo lo suyo: si es usuario, sus
    solicitudes creadas; si es técnico, sus asignados y su calificación;
    si es observador, su lista y sus zonas. Lo creado siempre sale, y lo
    asignado sale cuando tiene asignaciones.
    """
    from django.http import Http404

    elemento = (
        ElementoMiLista.objects.filter(pk=pk)
        .select_related("observador", "usuario", "punto", "zona")
        .first()
    )
    if elemento is None:
        raise Http404
    cuenta = elemento.usuario
    correo = (elemento.usuario_email or "").strip().lower()
    rol = getattr(cuenta, "rol", None) or "usuario"
    tickets = list(
        Ticket.objects.filter(solicitante_email__iexact=correo)
        .select_related("tecnico_asignado", "categoria")
        .prefetch_related("adjuntos", "comentarios__usuario")
        .order_by("-fecha_creacion") if correo else []
    )
    tecnicos = {}
    for t in tickets:
        nombre = (
            (t.tecnico_asignado.nombre if t.tecnico_asignado_id else "") or ""
        ).strip()
        if nombre:
            tecnicos[nombre] = tecnicos.get(nombre, 0) + 1
    # Lo asignado: lo que atiende esa cuenta como técnico (o admin de apoyo).
    asignados = list(
        Ticket.objects.filter(tecnico_asignado=cuenta)
        .select_related("tecnico_asignado")
        .prefetch_related("adjuntos", "comentarios__usuario")
        .order_by("-fecha_creacion") if cuenta is not None else []
    )
    calificacion = None
    if rol == Usuario.Rol.TECNICO and cuenta is not None:
        from apps.tickets.views import _calificacion_de

        calificacion = _calificacion_de(cuenta)
    # Lo vigilado: si la cuenta es observadora, su lista y sus zonas.
    lista_total = 0
    zonas_obs = []
    if rol == Usuario.Rol.OBSERVADOR and cuenta is not None:
        lista_total = ElementoMiLista.objects.filter(observador=cuenta).count()
        zonas_obs = list(
            ZonaObservador.objects.filter(observador=cuenta).order_by("nombre")
        )
    return render(
        request,
        "tickets/monitoreo_cuenta.html",
        {
            "elemento": elemento,
            "cuenta": cuenta,
            "correo": correo,
            "rol": rol,
            "vista_principal": _VISTA_PRINCIPAL_POR_ROL.get(rol, "Mis solicitudes"),
            "tickets": tickets,
            "total": len(tickets),
            "abiertos": sum(
                1 for t in tickets
                if t.estado in (Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO)
            ),
            "en_progreso": sum(
                1 for t in tickets if t.estado == Ticket.Estado.EN_PROGRESO
            ),
            "resueltos": sum(
                1 for t in tickets
                if t.estado in (Ticket.Estado.RESUELTO, Ticket.Estado.CERRADO)
            ),
            "tecnicos": sorted(tecnicos.items(), key=lambda kv: (-kv[1], kv[0])),
            "asignados": asignados,
            "asignados_total": len(asignados),
            "asignados_abiertos": sum(
                1 for t in asignados
                if t.estado in (Ticket.Estado.ABIERTO, Ticket.Estado.EN_PROGRESO)
            ),
            "calificacion": calificacion,
            "lista_total": lista_total,
            "zonas_obs": zonas_obs,
        },
    )


@admin_required
@login_required
def monitoreo_zonas(request):
    """Asigna o quita una zona completa a un observador."""
    if request.method != "POST":
        return redirect(reverse("tickets:monitoreo_admin"))
    volver = _retorno_monitoreo(request)
    observador_id = request.POST.get("observador") or ""
    nombre_zona = (request.POST.get("punto") or "").strip()
    accion = request.POST.get("accion") or "asignar"

    observador = Usuario.objects.filter(
        pk=observador_id, rol=Usuario.Rol.OBSERVADOR
    ).first() if observador_id.isdigit() else None
    punto = Punto.objects.filter(nombre=nombre_zona).first() if nombre_zona else None
    if observador is None or punto is None:
        return redirect(volver)

    if accion == "quitar":
        ObservadorPunto.objects.filter(observador=observador, punto=punto).delete()
        _auditar(
            request.user, MonitoreoAuditoria.QUITAR_PUNTO, observador,
            nombre_zona, f"Punto «{nombre_zona}» quitado a {observador.nombre}",
            request=request,
        )
    else:
        ObservadorPunto.objects.get_or_create(observador=observador, punto=punto)
        _auditar(
            request.user, MonitoreoAuditoria.ASIGNAR_PUNTO, observador,
            nombre_zona, f"Punto «{nombre_zona}» asignado a {observador.nombre}",
            request=request,
        )
    return redirect(volver)


@admin_required
@login_required
def monitoreo_zona_alertas(request, pk):
    """Activa/desactiva las alertas ANS de una zona (resaltado de urgentes)."""
    if request.method != "POST":
        return redirect(reverse("tickets:monitoreo_admin"))
    volver = _retorno_monitoreo(request)
    zona = ZonaObservador.objects.select_related("observador").filter(pk=pk).first()
    if zona is None:
        return redirect(volver)
    zona.alertas_ans = not zona.alertas_ans
    zona.save(update_fields=["alertas_ans"])
    _auditar(
        request.user, MonitoreoAuditoria.ALERTAS_ANS, zona.observador,
        zona.nombre,
        f"Alertas ANS {'activadas' if zona.alertas_ans else 'desactivadas'} en «{zona.nombre}»",
        request=request,
    )
    messages.success(
        request, f"Alertas ANS {'activadas' if zona.alertas_ans else 'desactivadas'} en «{zona.nombre}»."
    )
    return redirect(volver)


def _xlsx_auditoria(
    filas,
    titulo="Dogger · Auditoría de monitoreo",
    nombre="dogger_auditoria",
):
    """Monta la descarga .xlsx de la auditoría, para los dos paneles.

    Columnas: ID, Fecha, Acción, Zona, Supervisor, Cuenta, Hecho por,
    Detalle, Motivo, Resultado, IP, Versión. La fila de encabezados lleva
    autofiltro para filtrar/ordenar dentro de Excel.

    Lo único que cambia de un panel a otro es el conjunto de filas que
    entra: el del administrador baja todo el registro y el del observador
    solo lo suyo, pero la hoja que sale es la misma.
    """
    from io import BytesIO

    from django.http import HttpResponse
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter

    filas = list(filas)
    wb = Workbook()
    ws = wb.active
    ws.title = "Auditoría"
    NEGRO = PatternFill(start_color="171412", end_color="171412", fill_type="solid")
    BLANCO = Font(name="Arial", bold=True, color="FFFFFF", size=11)
    CUERPO = Font(name="Arial", size=10)
    fino = Side(style="thin", color="D9CFC2")
    borde = Border(left=fino, right=fino, top=fino, bottom=fino)
    zebra = PatternFill(start_color="FBF6EC", end_color="FBF6EC", fill_type="solid")

    headers = [
        ("ID", 8), ("Fecha", 18), ("Acción", 22), ("Zona", 20),
        ("Supervisor", 24), ("Cuenta", 30), ("Hecho por", 24),
        ("Detalle", 44), ("Motivo", 30), ("Resultado", 12),
        ("IP", 16), ("Versión", 10),
    ]
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(headers))
    ws.cell(row=1, column=1, value=titulo).font = Font(
        name="Arial", bold=True, color="FFFFFF", size=14
    )
    ws.cell(row=1, column=1).fill = NEGRO
    ws.cell(row=1, column=1).alignment = Alignment(horizontal="center")
    for i, (encabezado, ancho) in enumerate(headers, start=1):
        c = ws.cell(row=2, column=i, value=encabezado)
        c.font = BLANCO
        c.fill = NEGRO
        c.border = borde
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.column_dimensions[get_column_letter(i)].width = ancho
    ws.auto_filter.ref = f"A2:{get_column_letter(len(headers))}2"
    ws.freeze_panes = "A3"
    for n, a in enumerate(filas, start=3):
        vals = [
            a.pk,
            timezone.localtime(a.fecha).strftime("%d/%m/%Y %I:%M %p") if a.fecha else "",
            a.get_accion_display(),
            a.zona_nombre or "",
            getattr(a.observador, "nombre", "") or "",
            a.cuenta or "",
            getattr(a.actor, "nombre", "") or "",
            ((a.detalle or "") + (f" — {a.comentarios}" if a.comentarios else ""))[:500],
            a.motivo or "",
            a.resultado or "",
            a.ip_origen or "",
            a.version_sistema or "",
        ]
        for i, v in enumerate(vals, start=1):
            c = ws.cell(row=n, column=i, value=v)
            c.font = CUERPO
            c.border = borde
            c.alignment = Alignment(vertical="center", wrap_text=True)
            if n % 2 == 0:
                c.fill = zebra
    from .exports import preparar_libro_reunion

    preparar_libro_reunion(wb)
    buffer = BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    nombre_archivo = f"{nombre}_{timezone.localtime(timezone.now()).strftime('%Y%m%d_%H%M')}.xlsx"
    resp = HttpResponse(
        buffer.read(),
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
    resp["Content-Disposition"] = f'attachment; filename="{nombre_archivo}"'
    return resp


@admin_required
@require_GET
def monitoreo_auditoria_exportar(request):
    """Descarga **toda** la auditoría de monitoreo en Excel.

    Es el registro completo, sin filtro de zonas: lo ve quien administra el
    sistema. El observador baja el suyo desde su propia vista.
    """
    filas = (
        MonitoreoAuditoria.objects.select_related("actor", "observador")
        .order_by("-fecha", "-id")[:2000]
    )
    return _xlsx_auditoria(filas)
