from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
import re

User = get_user_model()

EMAIL_STRICT = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9\-]+(\.[A-Za-z0-9\-]+)*\.[A-Za-z]{2,}$")
EMAIL_STRICT_MSG = "Ingresa un correo válido, por ejemplo: nombre@dogger.com.co"


class LoginForm(AuthenticationForm):
    username = forms.EmailField(
        label="Correo corporativo",
        widget=forms.EmailInput(
            attrs={
                "placeholder": "correo@dogger.com.co",
                "autocomplete": "username",
                "autofocus": True,
            }
        ),
    )
    password = forms.CharField(
        label="Contraseña",
        widget=forms.PasswordInput(
            attrs={"placeholder": "••••••••", "autocomplete": "current-password"}
        ),
    )
    remember_me = forms.BooleanField(
        label="Recordarme",
        required=False,
        initial=True,
        widget=forms.CheckboxInput(attrs={"class": "checkbox-recordar"}),
    )
    modo_observador = forms.BooleanField(
        label="Modo Observador",
        required=False,
        widget=forms.CheckboxInput(attrs={"class": "checkbox-modo-observador"}),
        help_text="Entra al panel de observacion, en modo lectura.",
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # El aviso solo tiene sentido cuando se elige el modo a proposito.
        if self.is_bound:
            modo = self.data.get("modo_observador")
            if not modo:
                self.fields["modo_observador"].help_text = ""

    error_messages = {
        "invalid_login": "Correo o contraseña incorrectos.",
        "inactive": "Esta cuenta está desactivada.",
    }


class UserRegisterForm(forms.Form):
    nombre = forms.CharField(
        label="Nombre completo",
        max_length=100,
        widget=forms.TextInput(attrs={"placeholder": "Tu nombre completo", "autofocus": True}),
    )
    email = forms.EmailField(
        label="Correo electrónico",
        widget=forms.EmailInput(
            attrs={
                "placeholder": "usuario@correo.com",
                "pattern": r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9\-]+(\.[A-Za-z0-9\-]+)*\.[A-Za-z]{2,}",
                "title": EMAIL_STRICT_MSG,
                "autocomplete": "email",
            }
        ),
    )
    password1 = forms.CharField(
        label="Contraseña",
        widget=forms.PasswordInput(attrs={"placeholder": "••••••••", "autocomplete": "new-password", "minlength": 8, "aria-describedby": "registro-password-ayuda"}),
    )
    password2 = forms.CharField(
        label="Confirmar contraseña",
        widget=forms.PasswordInput(attrs={"placeholder": "Repite tu contraseña", "autocomplete": "new-password"}),
    )

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()
        if not EMAIL_STRICT.match(email):
            raise forms.ValidationError(EMAIL_STRICT_MSG)
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("Este correo ya está registrado. Intenta iniciar sesión.")
        return email

    def clean(self):
        cleaned_data = super().clean()
        password1 = cleaned_data.get("password1")
        password2 = cleaned_data.get("password2")
        if password1:
            usuario = User(email=cleaned_data.get("email", ""), nombre=cleaned_data.get("nombre", ""))
            try:
                validate_password(password1, user=usuario)
            except ValidationError as exc:
                self.add_error("password1", exc)
        if password1 and password2 and password1 != password2:
            self.add_error("password2", "Las contraseñas no coinciden.")
        return cleaned_data

    def save(self):
        user = User.objects.create_user(
            email=self.cleaned_data["email"],
            nombre=self.cleaned_data["nombre"],
            password=self.cleaned_data["password1"],
            rol="usuario",
            is_staff=False,
        )
        return user


class PerfilForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance.rol != "usuario":
            self.fields.pop("horario_atencion", None)

    class Meta:
        model = User
        fields = ["nombre", "email", "telefono", "avatar", "horario_atencion"]
        widgets = {
            "nombre": forms.TextInput(attrs={"placeholder": "Tu nombre completo"}),
            "email": forms.EmailInput(attrs={"placeholder": "correo@dogger.com.co"}),
            "telefono": forms.TextInput(attrs={"placeholder": "Ej: 310 371 6129"}),
            "horario_atencion": forms.TextInput(attrs={"placeholder": "Ej: Lunes a sábado · 8:00 a. m. – 6:00 p. m."}),
        }

    def clean_avatar(self):
        foto = self.cleaned_data.get("avatar")
        if foto and getattr(foto, "size", 0) > 2 * 1024 * 1024:
            raise forms.ValidationError("La foto no debe pesar más de 2 MB.")
        return foto

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()
        if User.objects.filter(email=email).exclude(pk=self.instance.pk).exists():
            raise forms.ValidationError("Este correo ya está en uso por otra cuenta.")
        return email


class CambiarPasswordForm(forms.Form):
    password_actual = forms.CharField(
        label="Contraseña actual",
        widget=forms.PasswordInput(attrs={"placeholder": "••••••••", "autocomplete": "current-password"}),
    )
    password_nueva = forms.CharField(
        label="Nueva contraseña",
        widget=forms.PasswordInput(attrs={"placeholder": "Mínimo 8 caracteres"}),
        min_length=8,
    )
    password_confirmar = forms.CharField(
        label="Confirmar nueva contraseña",
        widget=forms.PasswordInput(attrs={"placeholder": "Repite la nueva contraseña"}),
    )

    def __init__(self, user, *args, **kwargs):
        self.user = user
        super().__init__(*args, **kwargs)

    def clean_password_actual(self):
        password = self.cleaned_data.get("password_actual")
        if not self.user.check_password(password):
            raise forms.ValidationError("La contraseña actual es incorrecta.")
        return password

    def clean(self):
        cleaned_data = super().clean()
        nueva = cleaned_data.get("password_nueva")
        confirmar = cleaned_data.get("password_confirmar")
        if nueva and confirmar and nueva != confirmar:
            self.add_error("password_confirmar", "Las contraseñas no coinciden.")
        return cleaned_data

    def save(self):
        self.user.set_password(self.cleaned_data["password_nueva"])
        self.user.save()
        return self.user


class SolicitarResetForm(forms.Form):
    email = forms.EmailField(
        label="Correo corporativo",
        widget=forms.EmailInput(
            attrs={
                "placeholder": "correo@dogger.com.co",
                "autocomplete": "username",
                "autofocus": True,
            }
        ),
    )

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()
        # No revelar si la cuenta existe o no (seguridad).
        self.usuario = User.objects.filter(email__iexact=email, activo=True, is_active=True).first()
        return email


class CodigoResetForm(forms.Form):
    """Paso 2 (confirmar): solo se ingresa el código de verificación."""
    codigo = forms.CharField(
        label="Código de verificación",
        max_length=6,
        min_length=6,
        widget=forms.TextInput(
            attrs={"placeholder": "000000", "autocomplete": "one-time-code", "inputmode": "numeric"}
        ),
    )


class CambiarPasswordForzadoForm(forms.Form):
    """Ventana emergente tras validar el código: nueva contraseña sin pedir la actual.

    El formulario es intencionalmente pequeño (modal), con los dos campos
    de contraseña y su confirmación.
    """
    password_nueva = forms.CharField(
        label="Nueva contraseña",
        widget=forms.PasswordInput(attrs={"placeholder": "Mínimo 8 caracteres", "autocomplete": "new-password"}),
        min_length=8,
    )
    password_confirmar = forms.CharField(
        label="Confirmar nueva contraseña",
        widget=forms.PasswordInput(attrs={"placeholder": "Repite la nueva contraseña", "autocomplete": "new-password"}),
    )

    def clean(self):
        cleaned_data = super().clean()
        nueva = cleaned_data.get("password_nueva")
        confirmar = cleaned_data.get("password_confirmar")
        if nueva and confirmar and nueva != confirmar:
            self.add_error("password_confirmar", "Las contraseñas no coinciden.")
        return cleaned_data
