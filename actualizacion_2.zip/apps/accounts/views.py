from django.contrib.auth import get_user_model, login, logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView
from django.conf import settings
from django.contrib import messages
from django.db.models import Q
from django.utils import timezone
from django.utils.http import url_has_allowed_host_and_scheme
from django.http import FileResponse, Http404, JsonResponse
from django.shortcuts import redirect, render, reverse
from django.views import View
from django.views.decorators.http import require_POST
from datetime import timedelta
import json
import logging
import os

from .forms import (
    CambiarPasswordForzadoForm,
    CambiarPasswordForm,
    CodigoResetForm,
    LoginForm,
    PerfilForm,
    SolicitarResetForm,
    UserRegisterForm,
)
from .models import ResetPasswordToken, Usuario
from .routing import landing_por_rol
from .seguridad import bloqueado, ip_del_request, limpiar, registrar_intento

logger = logging.getLogger(__name__)

User = Usuario


def _ruta_retorno_segura(request, parametro, fallback):
    ruta = (request.POST.get(parametro) or "").strip()
    if ruta.startswith("/") and url_has_allowed_host_and_scheme(ruta, {request.get_host()}, require_https=request.is_secure()):
        return ruta
    return fallback


def _id_intento(request):
    """Llave anti-fuerza-bruta: IP + cuenta (para no bloquear a todos)."""
    email = (request.POST.get("username") or "").strip().lower()
    return f"{ip_del_request(request)}|{email}"


def _glpi_available():
    from django.conf import settings
    cfg = getattr(settings, "GLPI", {}) or {}
    return bool(cfg.get("enabled") and cfg.get("base_url"))


def _glpi_base_url():
    from django.conf import settings
    cfg = getattr(settings, "GLPI", {}) or {}
    url = cfg.get("base_url") or ""
    return url.split("/apirest.php")[0].rstrip("/") if url else ""


class BaseRoleLoginView(LoginView):
    template_name = "accounts/login.html"
    authentication_form = LoginForm
    redirect_authenticated_user = True
    role_name = "staff"
    role_label = "Staff"
    modo_observador = False

    def dispatch(self, request, *args, **kwargs):
        # Freno temprano: bloqueado ni siquiera llega a hashear.
        if request.method == "POST" and bloqueado("login", _id_intento(request)):
            form = self.authentication_form(data=request.POST)
            form.add_error(
                None,
                "Demasiados intentos fallidos. Espera 15 minutos e inténtalo de nuevo.",
            )
            return self.render_to_response(self.get_context_data(form=form))
        return super().dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["login_role"] = self.role_label
        context["login_role_slug"] = self.role_name
        return context

    def form_valid(self, form):
        # Entró bien: se olvidan los fallos anteriores de esta IP+cuenta.
        limpiar("login", _id_intento(self.request))
        # Con "Modo Observador" marcado se revisa el rol ANTES de iniciar
        # sesion. form.get_user() solo comprueba las credenciales: no crea
        # sesion ni rota el token CSRF, asi que un rechazo no deja al
        # navegador con un token distinto al de la pagina.
        if form.cleaned_data.get("modo_observador"):
            user = form.get_user()
            if user is None or not user.is_active:
                return super().form_valid(form)
            if getattr(user, "rol", None) != "observador":
                form.add_error(
                    "modo_observador",
                    "Esta cuenta no tiene el modo Observador. "
                    "Pídele a un administrador que te lo asigne.",
                )
                return self.form_invalid(form)
            self.modo_observador = True

        response = super().form_valid(form)
        if not form.cleaned_data.get("remember_me"):
            self.request.session.set_expiry(0)
        else:
            self.request.session.set_expiry(1209600)
        return response

    def form_invalid(self, form):
        # Credenciales malas: se cuenta para el freno de fuerza bruta.
        registrar_intento("login", _id_intento(self.request))
        return super().form_invalid(form)

    def get_success_url(self):
        # El modo Observador ya está comprobado como rol observador, así que
        # el mismo enrutado por rol cubre ese caso y cualquier otro.
        return landing_por_rol(self.request.user)


class StaffLoginView(BaseRoleLoginView):
    role_name = "staff"
    role_label = "Staff"


class UserLoginView(BaseRoleLoginView):
    role_name = "usuario"
    role_label = "Usuario"


class UserRegisterView(View):
    template_name = "accounts/register.html"

    def get(self, request, *args, **kwargs):
        form = UserRegisterForm()
        return self.render_view(request, form)

    def post(self, request, *args, **kwargs):
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect("tickets:mi_panel")
        return self.render_view(request, form)

    def render_view(self, request, form):
        return render(request, self.template_name, {"form": form, "login_role": "Usuario", "login_role_slug": "usuario"})


class StaffLogoutView(View):
    def post(self, request):
        logout(request)
        return redirect("tickets:portal")

    def get(self, request):
        logout(request)
        return redirect("tickets:portal")


@login_required
@require_POST
def configuracion_glpi(request):
    """Guarda y prueba la conexión con la web de GLPI.

    Solo administradores. Vacío = manda el .env (GLPI_*); con valores, el
    panel manda. "Probar" abre sesión contra la API y la cierra.
    """
    if request.user.rol != "admin":
        from django.http import Http404

        raise Http404("Solo los administradores configuran GLPI.")
    from apps.tickets.models import ConfigSitio

    cfg = ConfigSitio.cargar()
    modo = (request.POST.get("modo") or "auto").strip()
    cfg.glpi_habilitado = {"on": True, "off": False}.get(modo)
    base_url = (request.POST.get("base_url") or "").strip()
    if base_url:
        cfg.glpi_base_url = base_url[:250]
    app_token = (request.POST.get("app_token") or "").strip()
    if app_token:
        cfg.glpi_app_token = app_token[:250]
    user_token = (request.POST.get("user_token") or "").strip()
    if user_token:
        cfg.glpi_user_token = user_token[:250]
    timeout = (request.POST.get("timeout") or "").strip()
    cfg.glpi_timeout = int(timeout) if timeout.isdigit() else None
    cfg.save()
    if (request.POST.get("accion") or "guardar") == "probar":
        from apps.tickets.services.glpi_client import GlpiClient, GlpiError

        try:
            cliente = GlpiClient()
            if not cliente.available:
                messages.warning(
                    request, "Faltan datos: URL y los dos tokens para probar.")
            else:
                cliente.init_session()
                try:
                    cliente.kill_session()
                except GlpiError:
                    pass
                messages.success(request, "Conexión con GLPI verificada.")
        except GlpiError as exc:
            messages.error(request, f"No se pudo conectar: {exc}")
        except Exception:  # noqa: BLE001 - red caída no rompe ajustes
            messages.error(request, "No se pudo conectar con la web de GLPI.")
    else:
        messages.success(request, "Conexión con GLPI actualizada.")
    return redirect(reverse("accounts:ajustes") + "#glpi")


@login_required
def permisos_roles(request):
    """Guarda los permisos por cuenta desde la sección Página de Ajustes.

    Solo administradores. La vista vive en Ajustes (#pagina); el GET
    redirige allá para no tener dos páginas de configuración.
    """
    from django.http import Http404

    if request.user.rol != "admin":
        raise Http404("Solo los administradores gestionan los permisos.")
    if request.method != "POST":
        return redirect(reverse("accounts:ajustes") + "#pagina")
    User = get_user_model()
    from django.contrib.admin.models import CHANGE, LogEntry
    from django.contrib.contenttypes.models import ContentType
    from django.db import transaction
    from django.http import JsonResponse

    if request.POST.get("modulo_individual"):
        from .modulos import CLAVES, POR_ROL, restringidos
        clave = request.POST.get("modulo_individual")
        uid = request.POST.get("cuenta_modulos", "")
        valor = request.POST.get("valor")
        if clave not in CLAVES or not uid.isdigit() or valor not in ("0", "1") or int(uid) == request.user.pk:
            return JsonResponse({"ok": False, "error": "Configuración inválida."}, status=400)
        with transaction.atomic():
            u = User.objects.select_for_update().filter(pk=int(uid)).first()
            if u is None:
                return JsonResponse({"ok": False, "error": "Cuenta no encontrada."}, status=404)
            if clave not in POR_ROL.get(u.rol, set()):
                return JsonResponse({"ok": False, "error": "El módulo no corresponde al rol."}, status=400)
            prefs = dict(u.preferencias_notificaciones or {})
            anteriores = restringidos(u)
            actuales = set(anteriores)
            if valor == "1": actuales.add(clave)
            else: actuales.discard(clave)
            if actuales != anteriores:
                prefs["modulos_restringidos"] = sorted(actuales)
                u.preferencias_notificaciones = prefs
                u.save(update_fields=["preferencias_notificaciones"])
                LogEntry.objects.log_action(user_id=request.user.pk, content_type_id=ContentType.objects.get_for_model(User).pk, object_id=str(u.pk), object_repr=str(u)[:200], action_flag=CHANGE, change_message=f"Módulo {clave}: {'restringido' if valor == '1' else 'habilitado'}")
        return JsonResponse({"ok": True})

    if request.POST.get("modulos_cuenta") == "1":
        from .modulos import CLAVES
        uid = request.POST.get("cuenta_modulos", "")
        valores = request.POST.getlist("modulos_restringidos")
        if not uid.isdigit() or not set(valores) <= CLAVES:
            return JsonResponse({"ok": False, "error": "Configuración inválida."}, status=400)
        if int(uid) == request.user.pk:
            messages.error(request, "No puedes restringir tu propia cuenta.")
            return redirect(reverse("accounts:ajustes") + "#pagina")
        with transaction.atomic():
            u = User.objects.select_for_update().filter(pk=int(uid)).first()
            if u is None:
                raise Http404("Cuenta no encontrada")
            prefs = dict(u.preferencias_notificaciones or {})
            anteriores = prefs.get("modulos_restringidos", [])
            prefs["modulos_restringidos"] = sorted(set(valores))
            u.preferencias_notificaciones = prefs
            u.save(update_fields=["preferencias_notificaciones"])
            if anteriores != prefs["modulos_restringidos"]:
                LogEntry.objects.log_action(user_id=request.user.pk, content_type_id=ContentType.objects.get_for_model(User).pk, object_id=str(u.pk), object_repr=str(u)[:200], action_flag=CHANGE, change_message="Restricciones de módulos: " + ", ".join(prefs["modulos_restringidos"]))
        messages.success(request, "Restricciones de módulos actualizadas.")
        return redirect(reverse("accounts:ajustes") + "#pagina")

    permiso_unico = request.POST.get("permiso_unico")
    mapa_permisos = {
        "cerrar": "puede_cerrar_tickets", "eliminar": "puede_eliminar_tickets",
        "crear": "puede_crear_tickets",
        "responder": "puede_responder_chat", "editar_anuncios": "puede_editar_anuncios",
    }
    if permiso_unico is not None:
        campo = mapa_permisos.get(permiso_unico)
        uid = request.POST.get("uid", "")
        valor = request.POST.get("valor")
        if not campo or not uid.isdigit() or valor not in ("0", "1"):
            return JsonResponse({"ok": False, "error": "El cambio de permiso no es válido."}, status=400)
        with transaction.atomic():
            u = User.objects.select_for_update().filter(pk=int(uid)).first()
            if u is None:
                return JsonResponse({"ok": False, "error": "La cuenta no existe."}, status=404)
            anterior = getattr(u, campo)
            nuevo = valor == "1"
            if anterior != nuevo:
                setattr(u, campo, nuevo)
                u.save(update_fields=[campo])
                LogEntry.objects.log_action(user_id=request.user.pk, content_type_id=ContentType.objects.get_for_model(User).pk, object_id=str(u.pk), object_repr=str(u)[:200], action_flag=CHANGE, change_message=f"Permiso {campo}: {'activado' if anterior else 'desactivado'} → {'activado' if nuevo else 'desactivado'}")
        return JsonResponse({"ok": True})
    vistos = {
        int(pk) for pk in request.POST.getlist("uid") if str(pk).isdigit()
    }
    for u in User.objects.filter(pk__in=vistos):
        anteriores = {campo: getattr(u, campo) for campo in (
            "puede_cerrar_tickets", "puede_eliminar_tickets", "puede_reabrir_tickets",
            "puede_crear_tickets", "puede_responder_chat", "puede_editar_anuncios",
        )}
        for campo, llave in (
            ("puede_cerrar_tickets", "cerrar"),
            ("puede_eliminar_tickets", "eliminar"),
            ("puede_crear_tickets", "crear"),
            ("puede_responder_chat", "responder"),
        ):
            setattr(
                u, campo,
                request.POST.get(f"perm_{u.pk}_{llave}") in ("1", "on", "true"),
            )
        campos = [
            "puede_cerrar_tickets", "puede_eliminar_tickets",
            "puede_crear_tickets",
            "puede_responder_chat",
        ]
        if request.POST.get("incluye_permiso_anuncios") == "1":
            u.puede_editar_anuncios = request.POST.get(f"perm_{u.pk}_editar_anuncios") in ("1", "on", "true")
            campos.append("puede_editar_anuncios")
        with transaction.atomic():
            u.save(update_fields=campos)
            for campo in campos:
                if anteriores[campo] != getattr(u, campo):
                    LogEntry.objects.log_action(user_id=request.user.pk, content_type_id=ContentType.objects.get_for_model(User).pk, object_id=str(u.pk), object_repr=str(u)[:200], action_flag=CHANGE, change_message=f"Permiso {campo}: {'activado' if anteriores[campo] else 'desactivado'} → {'activado' if getattr(u, campo) else 'desactivado'}")
    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        from django.http import JsonResponse
        return JsonResponse({"ok": True})
    messages.success(request, "Permisos guardados.")
    return redirect(reverse("accounts:ajustes") + "#pagina")


@login_required
def ajustes_cuenta(request):
    user = request.user
    glpi_enabled = _glpi_available() and bool(getattr(user, "glpi_user_id", None))

    if request.method == "POST":
        if request.POST.get("guardar_notificaciones") == "1":
            claves = ("tickets_nuevos", "cambios_ticket", "tickets_cerrados", "recordatorios", "eventos")
            from django.db import transaction
            with transaction.atomic():
                cuenta = User.objects.select_for_update().get(pk=user.pk)
                preferencias = dict(cuenta.preferencias_notificaciones or {})
                preferencias.update({clave: request.POST.get(clave) == "1" for clave in claves})
                if request.POST.get("incluir_preferencias_correo") == "1":
                    preferencias.update({clave: request.POST.get(clave) == "1" for clave in ("correo_tickets", "correo_ans", "correo_resumen")})
                cuenta.preferencias_notificaciones = preferencias
                cuenta.save(update_fields=["preferencias_notificaciones"])
            messages.success(request, "Preferencias de notificaciones guardadas.")
            return redirect(reverse("accounts:ajustes") + "#notificaciones")
        es_staff = bool(getattr(user, "es_staff_helpdesk", False))
        if es_staff and request.POST.get("borrar_glpi_al_eliminar") in ("1", "on", "true"):
            user.borrar_glpi_al_eliminar = True
        elif es_staff:
            user.borrar_glpi_al_eliminar = False
        form = PerfilForm(request.POST, request.FILES, instance=user)
        if form.is_valid():
            try:
                form.save()
            except OSError:
                form.add_error("avatar", "No se pudo guardar la foto. Comprueba que el almacenamiento de archivos esté disponible y vuelve a intentarlo.")
            else:
            # Sync Dogger → GLPI: perfil + avatar
                if glpi_enabled:
                    try:
                        from apps.tickets.services.glpi_client import sync_perfil_to_glpi, sync_avatar_to_glpi
                        sync_perfil_to_glpi(user)
                        avatar_result = sync_avatar_to_glpi(user)
                        if avatar_result and not avatar_result.get("ok"):
                            messages.warning(request, f"Foto GLPI: {avatar_result.get('detalle', '')}")
                    except Exception:
                        pass
                messages.success(request, "Perfil actualizado correctamente.")
                return redirect(reverse("accounts:ajustes") + "#perfil")
    else:
        form = PerfilForm(instance=user)

    from .atajos import (
        ICONOS_ENLACE,
        POR_ROL,
        disponibles_para,
        normaliza_enlaces,
    )

    elegidos = list(getattr(user, "atajos_rapidos", None) or [])
    if not elegidos:
        elegidos = list(POR_ROL.get(user.rol, ()))
    ctx = {
        "form": form,
        "glpi_enabled": glpi_enabled,
        "glpi_base_url": _glpi_base_url(),
        # Manual de uso: la vista previa y el archivo de Word del rol.
        "manual_disponible": archivo_manual(user.rol) is not None,
        "manual_archivo": nombre_manual(user.rol),
        # Personalización del botón X: qué atajos del catálogo puede marcar
        # este rol, cuáles tiene elegidos y los enlaces propios guardados.
        "atajos_catalogo": disponibles_para(user.rol),
        "atajos_elegidos": elegidos,
        "atajos_enlaces": normaliza_enlaces(getattr(user, "atajos_enlaces", None)),
        "atajos_iconos": ICONOS_ENLACE,
        "preferencias_avisos": {clave: (user.preferencias_notificaciones or {}).get(clave, True) for clave in ("tickets_nuevos", "cambios_ticket", "tickets_cerrados", "recordatorios", "eventos", "correo_tickets", "correo_ans")},
        "correo_resumen_activo": (user.preferencias_notificaciones or {}).get("correo_resumen", False),
    }
    from apps.tickets.models import Categoria, Ticket

    if user.rol == "admin":
        ctx["perfil_ticket_total"] = Ticket.objects.count()
        ctx["perfil_categoria_total"] = Categoria.objects.filter(activo=True).count()
    elif user.rol == "tecnico":
        ctx["perfil_ticket_total"] = Ticket.objects.filter(tecnico_asignado=user).count()
    elif user.rol == "usuario":
        ctx["perfil_ticket_total"] = Ticket.objects.filter(solicitante_email__iexact=user.email).count()
    if user.rol == "admin":
        from apps.tickets.models import ConfigSitio

        ctx["config_sitio"] = ConfigSitio.cargar()
        from django.conf import settings as dj_settings
        horario_guardado = ctx["config_sitio"].horario_detalle
        filas_horario = horario_guardado if horario_guardado is not None else dj_settings.DOGGER.get("horario_detalle", [])
        ctx["horario_filas"] = list(filas_horario) + [{} for _ in range(max(0, 8 - len(filas_horario)))]
        limites = {"urgente": 1, "alta": 4, "media": 12, "baja": 24}
        limites.update(ctx["config_sitio"].limites_inactividad or {})
        ctx["limites_inactividad"] = limites
        ctx["escalamiento_inactividad"] = ctx["config_sitio"].escalamiento_inactividad or {}
        # Si falta la migracion, el interruptor de GLPI no tendria efecto: se
        # avisa en vez de dejar al administrador creyendo que si lo guardo.
        try:
            ConfigSitio.objects.only("panel_mostrar_actividad_glpi").exists()
            ctx["config_sitio_sin_migracion"] = False
        except Exception:
            ctx["config_sitio"] = None
            ctx["config_sitio_sin_migracion"] = True
        rol_perm = (request.GET.get("rol_perm") or "").strip()
        cuentas = get_user_model().objects.all().order_by("nombre")
        if rol_perm:
            cuentas = cuentas.filter(rol=rol_perm)
        ctx["cuentas_permisos"] = cuentas
        from .modulos import MODULOS
        ctx["modulos_restringibles"] = MODULOS
        ctx["rol_perm_sel"] = rol_perm
        from django.conf import settings as dj_settings

        env = dict(getattr(dj_settings, "GLPI", {}) or {})
        efectivo = ConfigSitio.glpi_efectivo()
        panel = ctx["config_sitio"]
        ctx["glpi_panel"] = None
        if panel is not None:
            ctx["glpi_panel"] = {
                "modo": (
                    "auto" if panel.glpi_habilitado is None
                    else ("on" if panel.glpi_habilitado else "off")
                ),
                "vigente": bool(efectivo["config"].get("enabled")),
                "fuente": efectivo["fuente"],
                "env_url": env.get("base_url", ""),
                "env_timeout": env.get("timeout", 30),
                "tiene_app": bool((panel.glpi_app_token or "").strip()),
                "tiene_user": bool((panel.glpi_user_token or "").strip()),
            }
    return render(request, "accounts/ajustes.html", ctx)

# Un archivo del manual por rol. Se guardan en apps/accounts/documentos/.
# El observador ve el manual del tecnico: su sesion es de solo lectura y
# trabaja sobre las mismas listas y fichas.
MANUALES_POR_ROL = {
    "admin": "manual-administrador.docx",
    "tecnico": "manual-tecnico.docx",
    "observador": "manual-tecnico.docx",
    "usuario": "manual-usuario.docx",
}


def archivo_manual(rol, extension="docx"):
    """Ruta del manual del rol, o None si no esta el archivo.

    El .docx es el original que se edita; el .pdf es esa misma maqueta con
    las capturas al dia, y es lo que se muestra en pantalla.
    """
    nombre = MANUALES_POR_ROL.get(rol or "", MANUALES_POR_ROL["usuario"])
    base, _ = os.path.splitext(nombre)
    ruta = os.path.join(os.path.dirname(__file__), "documentos", base + "." + extension)
    return ruta if os.path.isfile(ruta) else None


def nombre_manual(rol, extension="docx"):
    base = os.path.splitext(MANUALES_POR_ROL.get(rol or "", MANUALES_POR_ROL["usuario"]))[0]
    return base + "." + extension


@login_required
def descargar_manual(request):
    """Descarga el manual de uso que corresponde al rol de la cuenta."""
    ruta = archivo_manual(getattr(request.user, "rol", ""))
    if not ruta:
        raise Http404("El manual de este rol todavia no esta disponible.")
    respuesta = FileResponse(
        open(ruta, "rb"),
        as_attachment=True,
        filename=nombre_manual(getattr(request.user, "rol", "")),
        content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    )
    return respuesta


@login_required
def ver_manual(request):
    """Muestra el manual en pantalla: el PDF con la maqueta y las capturas.

    Se abre dentro del marco de la vista previa de los ajustes, asi que va
    en linea (no como descarga) y sin cache para que el cambio se vea ya.
    """
    ruta = archivo_manual(getattr(request.user, "rol", ""), "pdf")
    if not ruta:
        raise Http404("El manual de este rol todavia no esta disponible.")
    respuesta = FileResponse(open(ruta, "rb"), content_type="application/pdf")
    respuesta["Content-Disposition"] = 'inline; filename="%s"' % nombre_manual(
        getattr(request.user, "rol", ""), "pdf")
    respuesta["Cache-Control"] = "no-store"
    return respuesta


@login_required
@require_POST
def tour_preferencia(request):
    """Activa o desactiva el tour guiado de la cuenta.

    Se llama desde los ajustes y también desde el propio tour, para poder
    apagarlo sin tener que buscarlo en la configuración.
    """
    user = request.user
    accion = request.POST.get("accion", "")
    if accion == "activar":
        user.tour_habilitado = True
        user.tour_visto = False
        mensaje = "El tour guiado quedo activado para tu cuenta."
    elif accion == "desactivar":
        user.tour_habilitado = False
        mensaje = "El tour guiado quedo desactivado."
    else:
        # Sin accion explicita se invierte el estado actual.
        user.tour_habilitado = not user.tour_habilitado
        if user.tour_habilitado:
            user.tour_visto = False
        mensaje = (
            "El tour guiado quedo activado."
            if user.tour_habilitado
            else "El tour guiado quedo desactivado."
        )
    user.save(update_fields=["tour_habilitado", "tour_visto"])
    if request.POST.get("ajax") == "1":
        return JsonResponse(
            {"ok": True, "tour_habilitado": user.tour_habilitado}
        )
    messages.success(request, mensaje)
    destino = _ruta_retorno_segura(request, "next", reverse("accounts:ajustes"))
    return redirect(destino)


@login_required
@require_POST
def cambiar_rol_cuenta(request):
    """Cambia el rol de la propia cuenta, si el administrador lo habilitó.

    Es la contraparte del casillero «Cambiar de rol» de la ficha del panel:
    quien tiene `cambio_rol_habilitado` encendido ve el botón junto a su
    nombre en la barra superior de cualquier vista, y con esto pasa al rol
    que elija. Solo se puede usar sobre uno mismo: nadie cambia el rol de
    otra persona desde aquí, eso sigue siendo del panel del administrador.

    Al terminar se manda al panel del rol nuevo, que es el destino que decide
    `landing_por_rol`, el mismo que usa el login.
    """
    user = request.user
    if not getattr(user, "cambio_rol_habilitado", False):
        messages.error(request, "Tu cuenta no tiene habilitado cambiar de rol.")
        return redirect(landing_por_rol(user))

    nuevo = (request.POST.get("rol") or "").strip()
    if nuevo not in dict(Usuario.Rol.choices):
        messages.error(request, "Ese rol no existe.")
        return redirect(landing_por_rol(user))

    if nuevo == user.rol:
        messages.info(request, f"Ya tienes el rol {user.get_rol_display()}.")
        return redirect(landing_por_rol(user))

    # Mismo guardia que la eliminación de cuentas: no se puede dejar al sistema
    # sin administrador. El rol de administrador sale solo desde la ficha.
    if user.rol == Usuario.Rol.ADMIN and nuevo != Usuario.Rol.ADMIN:
        restantes = Usuario.objects.filter(
            rol=Usuario.Rol.ADMIN, activo=True
        ).exclude(pk=user.pk).count()
        if restantes == 0:
            messages.error(
                request,
                "No puedes salir del rol administrador: eres el único "
                "administrador activo. Pasa el rol a otra cuenta primero.",
            )
            return redirect(landing_por_rol(user))

    anterior = user.get_rol_display()
    if not user.rol_base:
        user.rol_base = user.rol
    user.rol = nuevo
    user.is_staff = nuevo in (Usuario.Rol.ADMIN, Usuario.Rol.TECNICO)
    from apps.tickets.services.autoasignacion_transaccional import coordinacion_asignacion
    with coordinacion_asignacion():
        user.save(update_fields=["rol", "rol_base", "is_staff"])
    messages.success(
        request,
        f"Vista cambiada de {anterior} a {user.get_rol_display()}; "
        f"tu rol base sigue siendo {user.get_rol_base_display()}.",
    )
    return redirect(landing_por_rol(user))


@login_required
@require_POST
def tooltips_preferencia(request):
    """Activa o desactiva los tooltips de ayuda de la cuenta."""
    user = request.user
    accion = request.POST.get("accion", "")
    if accion == "activar":
        user.tooltips_habilitado = True
        mensaje = "Los tooltips de ayuda quedaron activados."
    elif accion == "desactivar":
        user.tooltips_habilitado = False
        mensaje = "Los tooltips de ayuda quedaron desactivados."
    else:
        user.tooltips_habilitado = not user.tooltips_habilitado
        mensaje = (
            "Los tooltips de ayuda quedaron activados."
            if user.tooltips_habilitado
            else "Los tooltips de ayuda quedaron desactivados."
        )
    user.save(update_fields=["tooltips_habilitado"])
    if request.POST.get("ajax") == "1":
        return JsonResponse(
            {"ok": True, "tooltips_habilitado": user.tooltips_habilitado}
        )
    messages.success(request, mensaje)
    destino = _ruta_retorno_segura(request, "next", reverse("accounts:ajustes"))
    return redirect(destino)


@login_required
def glpi_pull_perfil(request):
    """Descarga perfil y foto desde GLPI al usuario local."""
    user = request.user
    if not getattr(user, "glpi_user_id", None):
        messages.warning(request, "Tu cuenta no está vinculada a GLPI.")
        return redirect("accounts:ajustes")

    try:
        from apps.tickets.services.glpi_client import sync_perfil_from_glpi, sync_avatar_from_glpi
        perfil_ok = sync_perfil_from_glpi(user)
        avatar_ok = sync_avatar_from_glpi(user)
        if perfil_ok or avatar_ok:
            messages.success(request, "Datos actualizados desde GLPI correctamente.")
        else:
            messages.info(request, "No se encontraron cambios en GLPI.")
    except Exception as exc:
        messages.error(request, f"Error al sincronizar con GLPI: {exc}")

    return redirect("accounts:ajustes")


@login_required
def glpi_push_avatar(request):
    """Sube el avatar local a GLPI."""
    user = request.user
    if not getattr(user, "glpi_user_id", None):
        messages.warning(request, "Tu cuenta no está vinculada a GLPI.")
        return redirect("accounts:ajustes")

    if not user.avatar:
        messages.warning(request, "Primero sube una foto de perfil.")
        return redirect("accounts:ajustes")

    try:
        from apps.tickets.services.glpi_client import sync_avatar_to_glpi
        ok = sync_avatar_to_glpi(user)
        if ok:
            messages.success(request, "Foto subida a GLPI correctamente.")
        else:
            messages.error(request, "No se pudo subir la foto a GLPI.")
    except Exception as exc:
        messages.error(request, f"Error al subir foto a GLPI: {exc}")

    return redirect("accounts:ajustes")


@login_required
def cambiar_password(request):
    """Cambio de contraseña. El formulario vive en ajustes.html (pestaña Contraseña),
    por lo que ambas rutas GET/POST de esta vista redirigen siempre a ajustes."""
    if request.method == "POST":
        form = CambiarPasswordForm(request.user, request.POST)
        if form.is_valid():
            form.save()
            update_session_auth_hash(request, request.user)
            request.session["pwd_cambiada_ok"] = True
        else:
            for err in form.non_field_errors():
                messages.error(request, err)
            for field, errs in form.errors.items():
                prefix = f"{form.fields[field].label}: " if field != "__all__" and field in form.fields else ""
                for err in errs:
                    messages.error(request, f"{prefix}{err}")
    return redirect(reverse("accounts:ajustes") + "#password")


def solicitar_reset(request):
    """Paso 1 — el usuario recibe un código de 6 dígitos.

    Cuando el correo ya se conoce (el del login con ?email=, el del usuario
    autenticado o el de un intento previo), la pantalla NO pide el correo:
    solo muestra "Enviar código". Si viene con ?manual= se vuelve a pedir.
    """
    if request.method == "GET" and request.GET.get("cancelar") == "1":
        request.session.pop("reset_pwd_destino_fijado", None)
        return redirect("accounts:login")

    if request.method == "POST" and request.POST.get("accion") == "preparar_correo":
        form = SolicitarResetForm(request.POST)
        if form.is_valid():
            anterior = request.session.get("reset_pwd_destino_fijado", "")
            if anterior and anterior.casefold() != form.cleaned_data["email"].casefold():
                form.add_error(None, "El correo ya está fijado para esta solicitud.")
                return render(request, "accounts/reset_solicitar.html", {
                    "form": form, "correo_fijado": True,
                    "correo_fijado_mostrado": _enmascarar_correo(anterior),
                    "correo_fijado_valor": anterior,
                })
            request.session["reset_pwd_destino_fijado"] = form.cleaned_data["email"]
            return redirect("accounts:reset_solicitar")
        return render(request, "accounts/reset_solicitar.html", {"form": form, "correo_fijado": False})

    if request.GET.get("manual"):
        request.session.pop("reset_pwd_destino_fijado", None)
        pre = ""
    else:
        pre = (
            request.session.get("reset_pwd_destino_fijado", "")
            or (request.GET.get("email") or "").strip()
            or (request.user.email if request.user.is_authenticated else "")
            or request.session.get("reset_pwd_email", "")
        )
    correo_fijado = bool(pre)
    correo_fijado_mostrado = _enmascarar_correo(pre) if correo_fijado else ""

    if request.method == "POST":
        form = SolicitarResetForm(request.POST)
        if correo_fijado:
            form.fields["email"].widget.attrs["readonly"] = True
            if request.POST.get("email", "").strip().casefold() != pre.strip().casefold():
                form.add_error(None, "El correo cambió. Actualiza la página o selecciona otro correo.")
        if form.is_valid():
            usuario = form.usuario
            if usuario is None:
                # No revelar si la cuenta existe: mismo mensaje general.
                request.session.pop("reset_pwd_destino_fijado", None)
                messages.success(request, "Si el correo está registrado, recibirás un código.")
                return redirect("accounts:login")
            try:
                token = ResetPasswordToken.generar(usuario)
                request.session["reset_pwd_email"] = usuario.email
                _enviar_codigo_reset(request, usuario, token)
            except Exception as exc:
                logger.exception("Error enviando código de reset a %s", usuario.email)
                messages.error(
                    request,
                    "No pudimos enviar el correo con el código. Revisa la configuración SMTP o inténtalo más tarde.",
                )
                return render(
                    request,
                    "accounts/reset_solicitar.html",
                    {
                        "form": form,
                        "correo_fijado": correo_fijado,
                        "correo_fijado_mostrado": correo_fijado_mostrado,
                        "correo_fijado_valor": pre,
                    },
                )
            request.session.pop("reset_pwd_destino_fijado", None)
            messages.success(
                request,
                "Te enviamos un código de verificación a tu correo (revisa también el spam).",
            )
            return redirect(reverse("accounts:restablecer_password"))
        return render(
            request,
            "accounts/reset_solicitar.html",
            {
                "form": form,
                "correo_fijado": correo_fijado,
                "correo_fijado_mostrado": correo_fijado_mostrado,
                "correo_fijado_valor": pre,
            },
        )

    form = SolicitarResetForm(initial={"email": pre})
    if correo_fijado:
        form.fields["email"].widget.attrs["readonly"] = True
    return render(
        request,
        "accounts/reset_solicitar.html",
        {
            "form": form,
            "correo_fijado": correo_fijado,
            "correo_fijado_mostrado": correo_fijado_mostrado,
            "correo_fijado_valor": pre,
        },
    )


def restablecer_password(request):
    """Paso 2 — solo se ingresa el código; al validarlo se inicia sesión
    y se fuerza el cambio de contraseña con una ventana emergente."""
    email = request.session.get("reset_pwd_email")
    if not email:
        messages.info(request, "Primero solicita un código de verificación.")
        return redirect("accounts:reset_solicitar")

    correo_mascara = _enmascarar_correo(email)

    if request.method == "POST":
        llave_reset = f"{ip_del_request(request)}|{email}"
        if bloqueado("reset", llave_reset):
            messages.error(
                request,
                "Demasiados códigos errados. Pide uno nuevo en 30 minutos.",
            )
            request.session.pop("reset_pwd_email", None)
            return redirect("accounts:reset_solicitar")
        form = CodigoResetForm(request.POST)
        if form.is_valid():
            codigo = form.cleaned_data["codigo"]
            usuario = User.objects.filter(email__iexact=email, activo=True, is_active=True).first()
            if usuario is None:
                messages.error(request, "El código no es válido para este correo.")
                request.session.pop("reset_pwd_email", None)
                return redirect("accounts:reset_solicitar")

            token = ResetPasswordToken.objects.filter(
                usuario=usuario, codigo=codigo, usado=False
            ).first()
            if not token:
                registrar_intento("reset", llave_reset, bloqueo_seg=1800)
                form.add_error("codigo", "El código es incorrecto.")
                return render(
                    request,
                    "accounts/reset_confirmar.html",
                    {"form": form, "correo_mascara": correo_mascara},
                )
            if token.expirado:
                registrar_intento("reset", llave_reset, bloqueo_seg=1800)
                token.delete()
                form.add_error("codigo", "El código ha expirado. Solicita uno nuevo.")
                return render(
                    request,
                    "accounts/reset_confirmar.html",
                    {"form": form, "correo_mascara": correo_mascara},
                )

            # El código es válido: hábilitalo y fuerza un cambio de contraseña
            limpiar("reset", llave_reset)
            token.usado = True
            token.save(update_fields=["usado"])
            usuario.set_unusable_password()
            usuario.save(update_fields=["password"])
            login(request, usuario)
            request.session.pop("reset_pwd_email", None)
            request.session["force_password_change"] = True
            return redirect(landing_por_rol(usuario))

        return render(
            request,
            "accounts/reset_confirmar.html",
            {"form": form, "correo_mascara": correo_mascara},
        )

    return render(
        request,
        "accounts/reset_confirmar.html",
        {"form": CodigoResetForm(), "correo_mascara": correo_mascara},
    )


def _enmascarar_correo(email):
    """Muestra el correo casi completo (solo el dominio), suficiente para que
    el usuario confirme a qué cuenta se envió el código sin que se edite."""
    local, sep, dominio = email.partition("@")
    if not sep:
        return email
    oculto = f"{local[:2]}…" if len(local) > 2 else local
    return f"{oculto}@{dominio}"


def _enviar_codigo_reset(request, usuario, token):
    """Envía el correo del código con la plantilla HTML corporativa de Dogger."""
    from django.template.loader import render_to_string
    from django.templatetags.static import static

    codigo = token.codigo

    texto_plano = (
        f"Hola {usuario.nombre}:\n\n"
        f"Tu código para restablecer la contraseña en Dogger HelpDesk es: {codigo}\n\n"
        "Este código es válido por 30 minutos.\n"
        "Si no solicitaste este cambio, ignora este mensaje."
    )
    html = render_to_string(
        "accounts/email_codigo_reset.html",
        {
            "usuario": usuario,
            "codigo": codigo,
            "logo_url": request.build_absolute_uri(static("images/dogger-logo.png")),
            "login_url": request.build_absolute_uri(reverse("accounts:login")),
        },
    )
    try:
        from django.core.mail import send_mail as _send

        from apps.tickets.services.fondo import en_fondo

        # El SMTP tarda segundos: va a fondo para no frenar el request.
        en_fondo(
            _send,
            "Dogger HelpDesk — Restablece tu contraseña",
            texto_plano,
            settings.DEFAULT_FROM_EMAIL,
            [usuario.email],
            _reset_token_id=token.pk,
            html_message=html,
            fail_silently=False,
        )
    except Exception:
        logger.exception("Error enviando código de reset a %s", usuario.email)
        raise


def pagina_no_autorizada(request, exception=None):
    """403 de la casa: el rol no alcanza para la URL que se pidió.

    Si el rol cambió en otra pestaña (el admin lo movió de grupo), se
    ofrece volver a la página del rol actual en vez de dejarlo varado.
    """
    from apps.accounts.routing import landing_por_rol

    usuario = getattr(request, "user", None)
    destino = landing_por_rol(usuario)
    return render(request, "forbidden.html",
                  {"destino_rol": destino}, status=403)


def pagina_no_encontrada(request, exception=None):
    """404 de la casa: la URL no existe, con salida al portal y al panel."""
    return render(request, "no_encontrado.html", status=404)


def pagina_error(request):
    """500 de la casa: algo falló sin culpar al usuario ni contar detalles."""
    return render(request, "error.html", status=500)


@login_required
def cambiar_password_forzado(request):
    """Vista que procesa el modal 'Debes actualizar tu contraseña'."""
    if not request.session.get("force_password_change"):
        return redirect(landing_por_rol(request.user))

    if request.method == "POST":
        form = CambiarPasswordForzadoForm(request.POST)
        if form.is_valid():
            request.user.set_password(form.cleaned_data["password_nueva"])
            request.user.save(update_fields=["password"])
            update_session_auth_hash(request, request.user)
            request.session.pop("force_password_change", None)
            request.session.pop("force_password_error", None)
            request.session["pwd_cambiada_ok"] = True
            return redirect(landing_por_rol(request.user))

        error_msg = next(
            (msg for msgs in form.errors.values() for msg in msgs),
            "No se pudo actualizar la contraseña.",
        )
        request.session["force_password_error"] = error_msg
        messages.error(request, "Revisa los errores en la ventana e inténtalo de nuevo.")
    return redirect(landing_por_rol(request.user))


@require_POST
def descartar_aviso(request):
    """Cierra el aviso emergente 'contraseña cambiada' para no volver a mostrarlo."""
    request.session.pop("pwd_cambiada_ok", None)
    return JsonResponse({"ok": True})


@login_required
def perfil_usuario(request):
    """Vista corporativa de perfil: información del usuario y preferencias.

    Las preferencias de visualización (modo, accesibilidad, navegación) se
    guardan en localStorage desde el cliente; aquí solo se exponen los datos
    del usuario para la tarjeta de perfil.
    """
    ctx = {
        "nav_perfil": "is-active",
        "correo_tickets_activo": (request.user.preferencias_notificaciones or {}).get("correo_tickets", True),
        "correo_ans_activo": (request.user.preferencias_notificaciones or {}).get("correo_ans", True),
        "correo_resumen_activo": (request.user.preferencias_notificaciones or {}).get("correo_resumen", False),
    }
    idioma = (request.user.preferencias_notificaciones or {}).get("idioma_perfil", "es")
    traducciones = {
        "es": ("Preferencias generales", "Idioma y notificaciones de la cuenta.", "Idioma", "Traducción disponible solo en esta sección.", "Notificaciones por correo", "Recibir avisos sobre el estado de mis tickets.", "Aviso de vencimientos ANS", "Recibir por correo alertas de tickets próximos a vencer.", "Resumen semanal", "Los lunes a las 8:00 a. m. (Colombia), cuando esté programado el envío."),
        "en": ("General preferences", "Account language and notifications.", "Language", "Translation is available only in this section.", "Email notifications", "Receive updates about my tickets by email.", "SLA deadline alerts", "Receive email alerts about tickets approaching their deadline.", "Weekly summary", "Mondays at 8:00 a.m. (Colombia), once delivery is scheduled."),
        "pt": ("Preferências gerais", "Idioma e notificações da conta.", "Idioma", "Tradução disponível apenas nesta seção.", "Notificações por e-mail", "Receber avisos sobre o estado dos meus chamados.", "Avisos de prazo ANS", "Receber alertas por e-mail de chamados próximos do vencimento.", "Resumo semanal", "Às segundas-feiras às 8h (Colômbia), quando o envio estiver programado."),
    }
    ctx["idioma_perfil"] = idioma if idioma in traducciones else "es"
    ctx["perfil_textos"] = traducciones[ctx["idioma_perfil"]]
    return render(request, "accounts/perfil.html", ctx)


@login_required
@require_POST
def preferencias_correo(request):
    """Actualiza exclusivamente la preferencia de correo de la cuenta autenticada."""
    from django.db import transaction

    clave = request.POST.get("clave")
    valor = request.POST.get("valor")
    es_idioma = clave == "idioma_perfil" and valor in ("es", "en", "pt")
    es_correo = clave in ("correo_tickets", "correo_ans", "correo_resumen") and valor in ("0", "1")
    if not (es_idioma or es_correo):
        return JsonResponse({"ok": False, "error": "Preferencia inválida"}, status=400)
    with transaction.atomic():
        usuario = User.objects.select_for_update().get(pk=request.user.pk)
        preferencias = dict(usuario.preferencias_notificaciones or {})
        preferencias[clave] = valor if es_idioma else valor == "1"
        usuario.preferencias_notificaciones = preferencias
        usuario.save(update_fields=["preferencias_notificaciones"])
    return JsonResponse({"ok": True, "valor": preferencias[clave]})


@login_required
def actividad_sesion(request):
    if request.method not in ("GET", "POST"):
        return JsonResponse({"ok": False}, status=405)
    if request.method == "POST":
        import time
        request.session["ultima_actividad_usuario"] = int(time.time())
    return JsonResponse({"ok": True})


@login_required
@require_POST
def configurar_cierre_inactividad(request):
    from django.db import transaction

    habilitado = request.POST.get("habilitado") == "1"
    try:
        minutos = int(request.POST.get("minutos", ""))
    except (ValueError, TypeError):
        minutos = 0
    if not 1 <= minutos <= 480:
        return JsonResponse({"ok": False, "error": "El tiempo debe estar entre 1 y 480 minutos."}, status=400)
    with transaction.atomic():
        usuario = User.objects.select_for_update().get(pk=request.user.pk)
        preferencias = dict(usuario.preferencias_notificaciones or {})
        preferencias.update(cierre_inactividad=habilitado, cierre_inactividad_minutos=minutos)
        usuario.preferencias_notificaciones = preferencias
        usuario.save(update_fields=["preferencias_notificaciones"])
    request.session.pop("ultima_actividad_usuario", None)
    return JsonResponse({"ok": True})


@require_POST
@login_required
def configuracion_pagina(request):
    """Guarda la configuración de la página (redes sociales) desde Ajustes.

    Solo administradores: controla qué botones de redes sociales se muestran
    en las vistas públicas y de usuario, y edita sus enlaces.
    """
    if request.user.rol != "admin":
        raise Http404("Solo los administradores pueden editar la configuración de la página.")

    from apps.tickets.models import ConfigSitio

    cfg = ConfigSitio.cargar()

    if request.POST.get("ajustes_escalamiento") == "1":
        habilitado = request.POST.get("habilitado") == "1"
        administradores = request.POST.get("administradores") == "1"
        observadores = request.POST.get("observadores") == "1"
        tecnico = request.POST.get("tecnico") == "1"
        solicitante = request.POST.get("solicitante") == "1"
        try:
            horas = int(request.POST.get("horas") or "0")
            if horas < 0 or horas > 8760 or (habilitado and (horas < 1 or not (administradores or observadores or tecnico or solicitante))):
                raise ValueError
        except (TypeError, ValueError):
            messages.error(request, "Para activar el escalamiento indica horas válidas y al menos un destinatario.")
            return redirect(reverse("accounts:ajustes") + "#pagina")
        cfg.escalamiento_inactividad = {"habilitado": habilitado, "horas": horas, "administradores": administradores, "observadores": observadores, "tecnico": tecnico, "solicitante": solicitante}
        cfg.save(update_fields=["escalamiento_inactividad", "fecha_actualizacion"])
        messages.success(request, "Configuración de escalamiento actualizada.")
        return redirect(reverse("accounts:ajustes") + "#pagina")

    if request.POST.get("ajustes_inactividad") == "1":
        limites = {}
        try:
            for prioridad in ("urgente", "alta", "media", "baja"):
                valor = int(request.POST.get("inactividad_" + prioridad, ""))
                if not 1 <= valor <= 8760:
                    raise ValueError
                limites[prioridad] = valor
        except (TypeError, ValueError):
            messages.error(request, "Los límites deben ser horas enteras entre 1 y 8760.")
            return redirect(reverse("accounts:ajustes") + "#pagina")
        cfg.limites_inactividad = limites
        cfg.save(update_fields=["limites_inactividad", "fecha_actualizacion"])
        messages.success(request, "Límites de inactividad actualizados.")
        return redirect(reverse("accounts:ajustes") + "#pagina")

    if request.POST.get("ajustes_horario") == "1":
        dias = request.POST.getlist("horario_dias")
        horas = request.POST.getlist("horario_hora")
        notas = request.POST.getlist("horario_nota")
        if not (len(dias) == len(horas) == len(notas)) or len(dias) > 8:
            messages.error(request, "No se pudo guardar el horario: revisa las filas enviadas.")
            return redirect(reverse("accounts:ajustes") + "#pagina")
        filas = []
        for dia, hora, nota in zip(dias, horas, notas):
            dia, hora, nota = dia.strip(), hora.strip(), nota.strip()
            if not (dia or hora or nota):
                continue
            if not dia or not hora or len(dia) > 80 or len(hora) > 80 or len(nota) > 120:
                messages.error(request, "Cada fila necesita días y horario válidos; la nota es opcional.")
                return redirect(reverse("accounts:ajustes") + "#pagina")
            filas.append({"dias": dia, "hora": hora, "nota": nota})
        cfg.horario_detalle = filas
        cfg.save(update_fields=["horario_detalle", "fecha_actualizacion"])
        messages.success(request, "Horario de atención publicado actualizado.")
        return redirect(reverse("accounts:ajustes") + "#pagina")

    if request.POST.get("ajustes_pagina") == "1":
        from django.core.exceptions import ValidationError
        from django.core.validators import validate_email, URLValidator
        from django.http import JsonResponse
        import re
        errores = []
        numero = request.POST.get("whatsapp_numero", "").strip()
        correo = request.POST.get("correo_soporte", "").strip()
        if numero and not re.fullmatch(r"[0-9]{7,20}", numero):
            errores.append("El número de WhatsApp debe contener entre 7 y 20 dígitos.")
        if correo:
            try:
                validate_email(correo)
            except ValidationError:
                errores.append("Introduce un correo electrónico válido.")
        validar_url = URLValidator(schemes=["https"])
        for campo in ("facebook_url", "instagram_url", "tiktok_url", "teams_url"):
            valor = request.POST.get(campo, "").strip()
            if valor:
                try:
                    validar_url(valor)
                except ValidationError:
                    errores.append("Los enlaces de redes sociales deben ser URL HTTPS válidas.")
                    break
        if errores:
            if request.headers.get("X-Requested-With") == "XMLHttpRequest":
                return JsonResponse({"ok": False, "error": " ".join(errores)}, status=400)
            messages.error(request, " ".join(errores))
            return redirect(reverse("accounts:ajustes") + "#pagina")

    def _bool(name, default=False):
        return request.POST.get(name) in ("1", "on", "true", "True")

    # La pestaña "GLPI" manda su propio formulario, que solo trae el
    # interruptor. Si se guardaran aquí los campos de redes y correo, cada
    # toque al interruptor vaciaría los enlaces que el administrador ya habia
    # configurado, asi que solo se tocan cuando viene el formulario completo.
    if request.POST.get("ajustes_pagina") == "1":
        cfg.pagina_mostrar_redes = _bool("pagina_mostrar_redes", True)
        cfg.correo_activo = _bool("correo_activo", True)
        cfg.correo_soporte = request.POST.get("correo_soporte", "").strip()
        cfg.whatsapp_activo = _bool("whatsapp_activo", True)
        cfg.whatsapp_numero = request.POST.get("whatsapp_numero", "").strip()
        cfg.tiktok_activo = _bool("tiktok_activo", True)
        cfg.tiktok_url = request.POST.get("tiktok_url", "").strip()
        cfg.instagram_activo = _bool("instagram_activo", True)
        cfg.instagram_url = request.POST.get("instagram_url", "").strip()
        cfg.facebook_activo = _bool("facebook_activo", True)
        cfg.facebook_url = request.POST.get("facebook_url", "").strip()
        cfg.teams_activo = _bool("teams_activo", True)
        cfg.teams_url = request.POST.get("teams_url", "").strip()
    # Interruptor con acción inmediata: si viene el checkbox apagado no se
    # toca, porque el navegador no envía el campo unchecked. Por eso el
    # formulario se guarda con JavaScript antes de enviarlo.
    if "panel_mostrar_actividad_glpi" in request.POST or "ajustes_actividad_glpi" in request.POST:
        cfg.panel_mostrar_actividad_glpi = _bool("panel_mostrar_actividad_glpi", True)
    try:
        cfg.full_clean(validate_unique=False)
    except Exception:
        pass
    cfg.save()
    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        from django.http import JsonResponse
        return JsonResponse({"ok": True})
    messages.success(request, "Configuración de la página actualizada.")
    siguiente = (request.POST.get("siguiente") or "").strip()
    if siguiente.startswith("/") and url_has_allowed_host_and_scheme(siguiente, {request.get_host()}, require_https=request.is_secure()):
        return redirect(siguiente)
    return redirect(reverse("accounts:ajustes") + "#" + request.POST.get("volver", "pagina"))


@login_required
@require_POST
def guardar_atajos(request):
    """Guarda los atajos del botón X: catálogo elegido + enlaces propios.

    Cada persona personaliza su propio botón desde Ajustes de cuenta. Las
    claves que no pertenezcan a su rol se descartan; los enlaces se limpian y
    se limitan (véase normaliza_enlaces). Si la petición es AJAX se responde
    en JSON para pintar el botón sin recargar; si no, se vuelve a Ajustes.
    """
    from .atajos import disponibles_para, normaliza_enlaces

    user = request.user
    rol = getattr(user, "rol", "") or ""
    validas = {e[0] for e in disponibles_para(rol)}

    crudas = request.POST.getlist("atajos")
    elegidos = [c for c in crudas if c in validas]
    user.atajos_rapidos = elegidos if elegidos else []

    # Los enlaces propios llegan como JSON en un campo oculto.
    enlaces = []
    crudo_enlaces = request.POST.get("enlaces", "")
    if crudo_enlaces:
        try:
            enlaces = normaliza_enlaces(json.loads(crudo_enlaces))
        except (TypeError, ValueError):
            enlaces = []
    user.atajos_enlaces = enlaces
    user.save(update_fields=["atajos_rapidos", "atajos_enlaces"])

    if request.POST.get("ajax") == "1":
        from .atajos import para_usuario

        return JsonResponse({"ok": True, "atajos": para_usuario(user)})
    messages.success(request, "Tus atajos quedaron guardados.")
    return redirect(reverse("accounts:ajustes") + "#atajos")


# =====================================================================
# Presencia en tiempo real: latido del navegador y consulta de estados
# =====================================================================
@login_required
@require_POST
def latido(request):
    """El navegador avisa que sigue aquí y guardamos la hora.

    Se llama cada pocos segundos mientras la pestaña está visible. Con esa
    marca el administrador ve el punto verde/rojo al día, y el propio
    usuario aparece como conectado en la vista de observador.
    """
    Usuario.objects.filter(pk=request.user.pk).update(ultima_actividad=timezone.now())
    return JsonResponse({"ok": True})


@login_required
def presencia(request):
    """Devuelve quién está conectado ahora mismo, para refrescar los puntos.

    Acepta `ids` separados por comas (los que hay pintados en pantalla) y
    opcionalmente `punto` para el módulo del observador. La respuesta es
    ligera: solo el estado, sin datos personales.
    """
    ids = [int(x) for x in request.GET.get("ids", "").split(",") if x.strip().isdigit()]
    ahora = timezone.now()
    desde = ahora - timedelta(minutes=5)

    consulta = Usuario.objects.filter(is_active=True)
    if ids:
        consulta = consulta.filter(pk__in=ids)
    else:
        consulta = consulta.filter(pk__in=[])  # sin ids no se devuelve nada

    en_linea = set(
        consulta.filter(ultima_actividad__gte=desde).values_list("pk", flat=True)
    )
    return JsonResponse({
        "ok": True,
        "en_linea": sorted(en_linea),
        "consultado": timezone.now().isoformat(),
    })
