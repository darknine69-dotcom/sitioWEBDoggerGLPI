/* Panel Técnico · Dashboard v2 (pivote + gráficos Chart.js) */
(function () {
    'use strict';
    var NS = 'http://www.w3.org/2000/svg';
    function temaOscuro() { return document.documentElement.getAttribute('data-theme') === 'dark'; }
    function colorArea(color) {
        var valor = /^#([\da-f]{6})$/i.exec(color || '');
        if (!valor) return 'rgba(59,130,246,.24)';
        var n = parseInt(valor[1], 16);
        return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',.24)';
    }

    var dataEl = document.getElementById('dashData');
    if (!dataEl) return;
    var D = null;
    try { D = JSON.parse(dataEl.textContent); } catch (e) { console.error('dashData inválido', e); }
    if (!D) return;

    var SERIE = D.colores_serie || {
        entrante: '#2563EB', completado: '#2F7D4F', vencido: '#D62B1F', riesgo: '#F2A900'
    };
    var PAL = ['#2563EB', '#2F7D4F', '#F2A900', '#B7791F', '#8A8A86', '#6B6259', '#D62B1F'];
    var COLS = { abrir: 'Abrir', espera: 'En Espera', vencido: 'Vencido', total: 'Total' };
    var ESTADOS = { abierto: 'Abierto', 'en-progreso': 'En progreso', resuelto: 'Resuelto', cerrado: 'Cerrado' };

    Chart.register({
        id: 'valorBarras',
        afterDatasetsDraw: function (chart) {
            if (chart.config.type !== 'bar') return;
            var stacked = chart.options.scales && chart.options.scales.y && chart.options.scales.y.stacked;
            var ctx = chart.ctx;
            chart.data.datasets.forEach(function (ds, di) {
                if (stacked && di > 0) return;
                var meta = chart.getDatasetMeta(di);
                meta.data.forEach(function (el, i) {
                    var v = ds.data[i];
                    if (!v) return;
                    ctx.save();
                    ctx.fillStyle = temaOscuro() ? '#d8e2ef' : '#4b5563';
                    ctx.font = 'bold 11px sans-serif';
                    ctx.textAlign = 'center';
                    ctx.fillText(v, el.x, (stacked ? el.y : el.base) - 5);
                    ctx.restore();
                });
            });
        }
    });

    /* Todos los tipos en todos los gráficos de solicitudes. */
    var TIPOS = ['bar', 'line', 'area', 'pie', 'donut', 'funnel', 'pyramid', 'count'];
    var TIPO_LABEL = {
        bar: 'Barras', line: 'Línea', area: 'Área', pie: 'Circular',
        donut: 'Dona', funnel: 'Embudo', pyramid: 'Pirámide', count: 'Recuento'
    };
    var DEFAULT_TIPO = { modo: 'pie', categoria: 'pie', prioridad: 'pie', linea: 'line', sla: 'bar', comp20: 'bar' };
    var estado = {};

    var charts = {};
    // ------------------------------------------------------------------
    // Datos por widget
    // ------------------------------------------------------------------
    // Cada torta (categoria/prioridad) trae una serie POR ÁMBITO en el JSON
    // (abiertas, en progreso, resueltos, cerrados, eliminados, todas), así
    // que el desplegable solo cambia de clave: no hace falta ir a pedir nada.
    var SCOPE_ID = { categoria: 'wCatScope', prioridad: 'wPrioScope' };
    var SCOPE_LABEL = { categoria: 'wCatLabel', prioridad: 'wPrioLabel' };
    var SCOPE_DEFAULT = 'abiertas';
    var AMBITO20_DEFAULT = 'recibidas';

    function scopeWidget(w) {
        var el = document.getElementById(SCOPE_ID[w]);
        return (el && el.value) || SCOPE_DEFAULT;
    }

    function ambito20() {
        var el = document.getElementById('wComp20');
        return (el && el.value) || AMBITO20_DEFAULT;
    }

    function vistaObservador(widget) {
        var card = document.querySelector('.chart-modal[data-widget="' + widget + '"]');
        var selector = card && card.querySelector('[data-obs-selector]');
        return (selector && selector.value) || '';
    }

    function actualizarTituloObservador(card) {
        var selector = card.querySelector('[data-obs-selector]');
        var titulo = card.querySelector('.chart-card-head h3');
        if (!selector || !titulo) return;
        titulo.textContent = selector.options[selector.selectedIndex].textContent;
    }

    function serieWidget(w) {
        var vistaObs = vistaObservador(w);
        if (vistaObs && D.observador && D.observador[vistaObs]) return D.observador[vistaObs];
        if (w === 'modo') return { pairs: D.pie_modo || [] };
        if (w === 'categoria') {
            var porCat = D.pie_categoria || {};
            return { pairs: porCat[scopeWidget(w)] || porCat[SCOPE_DEFAULT] || [] };
        }
        if (w === 'prioridad') {
            var porPri = D.pie_prioridad || {};
            return { pairs: porPri[scopeWidget(w)] || porPri[SCOPE_DEFAULT] || [] };
        }
        if (w === 'linea') {
            var rango = document.getElementById('wLineaRange');
            var d = D.linea[(rango && rango.value) || 'ultima_semana'];
            return {
                labels: d.labels,
                datasets: [
                    { key: 'entrante', label: 'Entrante', data: d.entrante, color: SERIE.entrante },
                    { key: 'completado', label: 'Completado', data: d.completado, color: SERIE.completado },
                    { key: 'vencido', label: 'Vencido', data: d.vencido, color: SERIE.vencido }
                ]
            };
        }
        if (w === 'sla') {
            var dim = document.getElementById('wSlaDim');
            var data = D.sla[(dim && dim.value) || 'por_tecnico'] || [];
            return {
                labels: data.map(function (r) { return r.label; }),
                datasets: [
                    { key: 'vencidos', label: 'Sanción', data: data.map(function (r) { return r.vencidos; }), color: SERIE.vencido },
                    { key: 'riesgo', label: 'Advertencia', data: data.map(function (r) { return r.riesgo; }), color: SERIE.riesgo }
                ]
            };
        }
        if (w === 'comp20') {
            var c20 = D.comparativo[ambito20()] || D.comparativo[AMBITO20_DEFAULT];
            return {
                labels: c20.labels,
                datasets: [
                    { key: 'ok', label: 'Sin infracción', data: c20.ok, color: '#2F7D4F' },
                    { key: 'brecha', label: 'Con infracción', data: c20.brecha, color: SERIE.vencido }
                ]
            };
        }
        var c = D.comparativo[ambito20()] || D.comparativo[AMBITO20_DEFAULT];
        return {
            labels: c.labels,
            datasets: [
                { key: 'ok', label: 'Sin infracción', data: c.ok, color: '#2F7D4F' },
                { key: 'brecha', label: 'Con infracción', data: c.brecha, color: SERIE.vencido }
            ]
        };
    }

    function pairs(widget) {
        var s = serieWidget(widget);
        if ((widget === 'modo' || widget === 'categoria' || widget === 'prioridad') && !s.labels) return s.pairs;
        return s.labels.map(function (l, i) {
            var v, color;
            if (vistaObservador(widget)) {
                v = s.datasets.reduce(function (total, ds) { return total + (ds.data[i] || 0); }, 0);
                color = (s.datasets[0].colors || [s.datasets[0].color || PAL[i % PAL.length]])[i] || s.datasets[0].color || PAL[i % PAL.length];
            } else if (widget === 'linea') {
                v = s.datasets[0].data[i];
                color = PAL[i % PAL.length];
            } else if (widget === 'sla') {
                v = s.datasets[0].data[i] + s.datasets[1].data[i];
                color = s.datasets[0].data[i] > 0 ? SERIE.vencido : SERIE.riesgo;
            } else {
                v = s.datasets[0].data[i] + s.datasets[1].data[i];
                color = s.datasets[1].data[i] > 0 ? SERIE.vencido : '#2F7D4F';
            }
            return { label: l, value: v, color: color };
        });
    }

    function countTitle(widget) {
        var vistaObs = vistaObservador(widget);
        if (vistaObs) {
            var card = document.querySelector('.chart-modal[data-widget="' + widget + '"]');
            var selector = card && card.querySelector('[data-obs-selector]');
            return selector ? selector.options[selector.selectedIndex].textContent : 'resumen de monitoreo';
        }
        if (widget === 'modo') return 'solicitudes abiertas por modo';
        if (widget === 'categoria' || widget === 'prioridad') {
            var dim = widget === 'categoria' ? 'categoría' : 'prioridad';
            var sc = scopeWidget(widget);
            if (sc === 'todas') return 'solicitudes por ' + dim;
            if (sc === 'eliminados') return 'solicitudes eliminadas por ' + dim;
            return 'solicitudes ' + sc.replace('_', ' ') + ' por ' + dim;
        }
        if (widget === 'linea') return 'entrantes en el período';
        if (widget === 'sla') return 'sanciones por vencimiento de ANS';
        if (widget === 'comp20') {
            return (D.etiquetas_20dias || {})[ambito20()] || 'solicitudes en los últimos 20 días';
        }
        return 'solicitudes en los últimos 20 días';
    }
    // ------------------------------------------------------------------
    // Renderers
    // ------------------------------------------------------------------
    function clearStage(stage) {
        stage.innerHTML = '';
    }

    function renderCount(stage, widget) {
        var tot = pairs(widget).reduce(function (s, p) { return s + p.value; }, 0);
        stage.appendChild(domEl('<div class="chart-count"><strong>' + tot + '</strong><small>' + countTitle(widget) + '</small></div>'));
    }

    function drawFunnelLike(stage, widget, pyramid) {
        /* El embudo/pirámide ordenan de mayor a menor: sin orden las
           franjas quedan arbitrarias y el gráfico no dice nada. */
        var prs = pairs(widget).filter(function (p) { return p.value > 0; })
            .sort(function (a, b) { return b.value - a.value; });
        if (!prs.length) { stage.appendChild(domEl('<p class="chart-empty">Sin datos.</p>')); return; }
        var max = Math.max.apply(null, prs.map(function (p) { return p.value; })) || 1;
        var W = 620, H = 260, top = 18, base = 330, n = prs.length;
        var step = (H - top * 2) / n;
        var svg = document.createElementNS(NS, 'svg');
        svg.setAttribute('class', 'funnel');
        svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
        /* Trama diagonal blanca para el realce al hover de cada franja. */
        var pid = 'dg-hatch-' + widget + (pyramid ? '-p' : '-f');
        var defs = document.createElementNS(NS, 'defs');
        var pat = document.createElementNS(NS, 'pattern');
        pat.setAttribute('id', pid);
        pat.setAttribute('width', '9'); pat.setAttribute('height', '9');
        pat.setAttribute('patternUnits', 'userSpaceOnUse');
        pat.setAttribute('patternTransform', 'rotate(45)');
        var pl = document.createElementNS(NS, 'line');
        pl.setAttribute('x1', '0'); pl.setAttribute('y1', '0');
        pl.setAttribute('x2', '0'); pl.setAttribute('y2', '9');
        pl.setAttribute('stroke', 'rgba(255,255,255,.55)');
        pl.setAttribute('stroke-width', '3');
        pat.appendChild(pl);
        defs.appendChild(pat);
        svg.appendChild(defs);
        prs.forEach(function (p, i) {
            var f = p.value / max;
            var fw = pyramid ? (i + 1) / n : (n - i) / n;
            var w = Math.max(14, 60 + f * base * fw);
            var x = (W - w) / 2;
            var y = top + i * step;
            var hh = Math.max(10, step - 6);
            var g = document.createElementNS(NS, 'g');
            g.setAttribute('class', 'funnel-seg');
            var r = document.createElementNS(NS, 'rect');
            r.setAttribute('x', x); r.setAttribute('y', y);
            r.setAttribute('width', w); r.setAttribute('height', hh);
            r.setAttribute('rx', 6); r.setAttribute('fill', p.color);
            var tt = document.createElementNS(NS, 'title');
            tt.textContent = p.label + ': ' + p.value;
            r.appendChild(tt);
            g.appendChild(r);
            var rayas = document.createElementNS(NS, 'rect');
            rayas.setAttribute('x', x); rayas.setAttribute('y', y);
            rayas.setAttribute('width', w); rayas.setAttribute('height', hh);
            rayas.setAttribute('rx', 6);
            rayas.setAttribute('fill', 'url(#' + pid + ')');
            rayas.setAttribute('class', 'funnel-hatch');
            g.appendChild(rayas);
            var t = document.createElementNS(NS, 'text');
            t.setAttribute('x', W / 2); t.setAttribute('y', y + hh / 2 + 4);
            t.setAttribute('text-anchor', 'middle'); t.setAttribute('fill', '#fff');
            t.setAttribute('font-size', '12'); t.setAttribute('font-weight', 'bold');
            t.textContent = p.value;
            g.appendChild(t);
            var lb = document.createElementNS(NS, 'text');
            lb.setAttribute('class', 'funnel-label');
            lb.setAttribute('x', x - 10); lb.setAttribute('y', y + hh / 2 + 4);
            lb.setAttribute('text-anchor', 'end'); lb.setAttribute('fill', '#6B6259');
            lb.setAttribute('font-size', '11');
            lb.textContent = p.label.length > 24 ? p.label.slice(0, 23) + '…' : p.label;
            g.appendChild(lb);
            svg.appendChild(g);
        });
        stage.appendChild(svg);
    }

    function tooltipPct(item) {
        var v = (typeof item.parsed === 'object') ? item.parsed.y : item.parsed;
        v = (typeof v === 'number') ? v : 0;
        var total = 0;
        item.chart.data.datasets.forEach(function (ds) {
            ds.data.forEach(function (d) { var n = (typeof d === 'number') ? d : 0; total += n; });
        });
        var name = (item.dataset && item.dataset.label) ? item.dataset.label : item.label;
        var pct = total ? Math.round(v / total * 100) : 0;
        return ' ' + name + ': ' + v + (pct ? ' (' + pct + '%)' : '');
    }

    /* Realce al hover: el segmento/barra activo se rellena con líneas
       diagonales blancas sobre su propio color. */
    var _hatchCache = {};
    var _hatchCtx = null;
    function hatchDe(color) {
        var key = String(color);
        if (_hatchCache[key]) { return _hatchCache[key]; }
        if (!_hatchCtx) { _hatchCtx = document.createElement('canvas').getContext('2d'); }
        var baldosa = document.createElement('canvas');
        baldosa.width = 10; baldosa.height = 10;
        var g = baldosa.getContext('2d');
        g.fillStyle = key;
        g.fillRect(0, 0, 10, 10);
        g.strokeStyle = 'rgba(255,255,255,.55)';
        g.lineWidth = 2.5;
        g.beginPath();
        g.moveTo(-3, 13); g.lineTo(13, -3);
        g.moveTo(-3, 3); g.lineTo(3, -3);
        g.stroke();
        var patron = null;
        try { patron = _hatchCtx.createPattern(baldosa, 'repeat'); } catch (e) { patron = null; }
        _hatchCache[key] = patron || key;
        return _hatchCache[key];
    }
    /* Fondo según estado: reposo = color plano, hover = diagonal. */
    function realcePorIndice(base) {
        return function (c) {
            var color = base[c.dataIndex];
            try { return c.active ? hatchDe(color) : color; }
            catch (e) { return color; }
        };
    }
    function realceFijo(color) {
        return function (c) {
            try { return c.active ? hatchDe(color) : color; }
            catch (e) { return color; }
        };
    }
    function cursorSegunHover(e, els) {
        var t = (e && e.native) ? e.native.target : null;
        if (t) { t.style.cursor = (els && els.length) ? 'pointer' : 'default'; }
    }
    var ANIM = { duration: 700, easing: 'easeOutQuart' };
    var TRANS_ACTIVA = { active: { animation: { duration: 250 } } };

    function configFor(widget, tipo, conLeyendaPropia) {
        var multi = serieWidget(widget);
        function single() {
            var prs = pairs(widget);
            var bg = prs.map(function (p) { return p.color; });
            return {
                labels: prs.map(function (p) { return p.label; }),
                datasets: [{
                    data: prs.map(function (p) { return p.value; }),
                    backgroundColor: realcePorIndice(bg),
                    borderColor: '#fff', borderWidth: 2, borderRadius: 4,
                    /* Al hover el segmento se separa un poco y se raya en
                       diagonal por dentro (ver realcePorIndice). */
                    hoverOffset: 6,
                    hoverBorderWidth: 3,
                    hoverBorderColor: '#fff'
                }]
            };
        }
        function multiDatasets(stacked) {
            var bw = tipo === 'bar' ? 1 : 2;
            return {
                labels: multi.labels,
                datasets: multi.datasets.map(function (ds) {
                    var colores = ds.colors || null;
                    return {
                        label: ds.label,
                        data: ds.data,
                        backgroundColor: tipo === 'area' ? colorArea(ds.color) : (colores ? realcePorIndice(colores) : realceFijo(ds.color)),
                        borderColor: colores || ds.color,
                        borderWidth: bw,
                        borderRadius: 4,
                        stack: stacked ? 's' : undefined,
                        fill: tipo === 'area' ? 'origin' : false,
                        tension: 0.35,
                        hoverBorderWidth: bw + 1,
                        pointRadius: 3,
                        pointHoverRadius: 5,
                        pointBackgroundColor: ds.color,
                        pointBorderColor: ds.color,
                        pointHoverBackgroundColor: ds.color,
                        pointHoverBorderColor: '#fff',
                        pointHoverBorderWidth: 2
                    };
                })
            };
        }

        var data, opts;
        var textoGrafico = temaOscuro() ? '#c2cddd' : '#53647a';
        var lineasGrafico = temaOscuro() ? 'rgba(190,205,225,.18)' : 'rgba(70,85,105,.16)';
        var scalesX = { grid: { display: false }, ticks: { color: textoGrafico, maxRotation: 0, autoSkip: true, maxTicksLimit: 14 } };
        var scalesY = { beginAtZero: true, grid: { color: lineasGrafico }, ticks: { color: textoGrafico, precision: 0 } };
        var hasMulti = (multi.datasets && multi.datasets.length > 1) || widget === 'linea' || widget === 'sla' || widget === 'comp20' || widget === 'recibidas' || widget === 'completadas';

        if (tipo === 'bar' || tipo === 'line' || tipo === 'area') {
            var stacked = false;
            if ((widget === 'comp20' || widget === 'recibidas' || widget === 'completadas') && tipo === 'bar') stacked = true;
            if (hasMulti) {
                data = multiDatasets(stacked);
            } else {
                var prs = pairs(widget);
                var bg2 = prs.map(function (p) { return p.color; });
                data = {
                    labels: prs.map(function (p) { return p.label; }),
                    datasets: [{
                        label: undefined,
                        data: prs.map(function (p) { return p.value; }),
                        backgroundColor: tipo === 'area' ? colorArea(bg2[0]) : realcePorIndice(bg2),
                        borderColor: tipo === 'bar' ? bg2 : (bg2[0] || '#3b82f6'),
                        borderWidth: tipo === 'bar' ? 1 : 2, borderRadius: 4,
                        fill: tipo === 'area' ? 'origin' : false,
                        tension: 0.35,
                        hoverBorderWidth: 2,
                        pointRadius: 3, pointHoverRadius: 5,
                        pointBackgroundColor: bg2,
                        pointBorderColor: bg2,
                        pointHoverBackgroundColor: bg2,
                        pointHoverBorderColor: '#fff',
                        pointHoverBorderWidth: 2
                    }]
                };
            }
            var scales = tipo === 'bar'
                ? { x: stacked ? { stacked: true, grid: { display: false }, ticks: { color: textoGrafico } } : scalesX, y: stacked ? { stacked: true, beginAtZero: true, grid: { color: lineasGrafico }, ticks: { color: textoGrafico, precision: 0 } } : scalesY }
                : { x: scalesX, y: scalesY };
            opts = {
                responsive: true, maintainAspectRatio: false,
                animation: ANIM,
                transitions: TRANS_ACTIVA,
                onHover: cursorSegunHover,
                scales: scales,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function (it) {
                                if (it.parsed.y !== undefined) {
                                    var nombre = (it.dataset && it.dataset.label) ? it.dataset.label : it.label;
                                    return ' ' + nombre + ': ' + it.parsed.y;
                                }
                                return tooltipPct(it);
                            }
                        }
                    }
                }
            };
        } else {
            data = single();
            opts = {
                responsive: true, maintainAspectRatio: false, cutout: tipo === 'donut' ? '58%' : 0,
                animation: ANIM,
                transitions: TRANS_ACTIVA,
                onHover: cursorSegunHover,
                plugins: {
                    /* Sin leyenda propia (sla/comp20) se usa la nativa abajo;
                       con leyenda propia se apaga para no duplicar. */
                    legend: conLeyendaPropia
                        ? { display: false }
                        : { position: 'bottom', labels: { boxWidth: 12, padding: 12, color: textoGrafico },
                            onHover: function (e) { if (e.native) { e.native.target.style.cursor = 'pointer'; } },
                            onLeave: function (e) { if (e.native) { e.native.target.style.cursor = 'default'; } } },
                    tooltip: { callbacks: { label: tooltipPct } }
                }
            };
        }
        var chartType = tipo === 'area' ? 'line' : (tipo === 'donut' ? 'doughnut' : tipo);
        return { type: chartType, data: data, options: opts };
    }

    function domEl(html) {
        var t = document.createElement('template');
        t.innerHTML = html.trim();
        return t.content.firstChild;
    }

    // Un canvas sin valores es un recuadro en blanco sin explicación: se
    // sustituye por un mensaje que dice qué falta.
    function sinDatosMsg(widget) {
        if (widget === 'sla') return 'Sin sanciones ni advertencias de ANS.';
        if (widget === 'linea') return 'Sin movimientos en el período.';
        if (widget === 'comp20') {
            return 'Sin tickets de "' + ((D.etiquetas_20dias || {})[ambito20()] || 'este ámbito') +
                '" en los últimos 20 días.';
        }
        if (widget === 'categoria' || widget === 'prioridad') {
            return 'Sin solicitudes ' + (scopeWidget(widget) === 'todas' ? '' : scopeWidget(widget).replace('_', ' ') + ' ') + 'en esta vista.';
        }
        return 'Sin datos.';
    }

    function tieneValores(cfg) {
        var ds = (cfg && cfg.data && cfg.data.datasets) || [];
        for (var i = 0; i < ds.length; i++) {
            var arr = ds[i].data || [];
            for (var j = 0; j < arr.length; j++) {
                var v = arr[j];
                if (v && typeof v === 'object') v = (v.y !== undefined) ? v.y : (v.v || 0);
                if (typeof v === 'number' && v > 0) return true;
            }
        }
        return false;
    }

    function render(card, widget) {
        var stage = card.querySelector('[data-stage]');
        function onPie(on) {
            var leg = card.querySelector('[data-pie-legend]');
            if (leg) leg.style.display = on ? '' : 'none';
        }
        var tipo = estado[widget] || DEFAULT_TIPO[widget];
        /* La leyenda fija de series solo vale en cartesianos; en torta o
           recuento confundiría (describe series que ahí no se ven). */
        var ley = card.querySelector('[data-legend]');
        if (ley) ley.style.display = (!vistaObservador(widget) && (tipo === 'bar' || tipo === 'line' || tipo === 'area')) ? '' : 'none';
        card.classList.toggle('is-count', tipo === 'count');
        clearStage(stage);
        if (charts[widget]) { charts[widget].destroy(); charts[widget] = null; }

        if (tipo === 'count') { renderCount(stage, widget); onPie(false); return; }
        if (tipo === 'funnel') { drawFunnelLike(stage, widget, false); onPie(false); return; }
        if (tipo === 'pyramid') { drawFunnelLike(stage, widget, true); onPie(false); return; }

        var canvas = document.createElement('canvas');
        var cfg = configFor(widget, tipo, Boolean(card.querySelector('[data-pie-legend]')));
        // Sin importarle si hay etiquetas: un canvas en blanco no le dice nada
        // al usuario. Si no hay ni un solo valor, se explica qué falta.
        if (!tieneValores(cfg)) {
            stage.appendChild(domEl('<p class="chart-empty">' + sinDatosMsg(widget) + '</p>'));
            onPie(false);
            return;
        }
        stage.appendChild(canvas);
        var chart = new Chart(canvas.getContext('2d'), cfg);
        var ct = cfg.type || tipo;
        if (ct === 'pie' || ct === 'doughnut') {
            onPie(true);
            bindPieCard(card, widget, chart);
        } else {
            onPie(false);
        }
        charts[widget] = chart;
    }

    function bindPieCard(card, widget, chart) {
        var leg = card.querySelector('[data-pie-legend]');
        if (!leg) return;
        var lis = Array.prototype.slice.call(leg.querySelectorAll('li'));
        function setHi(i) {
            lis.forEach(function (li, k) { li.classList.toggle('is-hi', k === i); });
        }
        /* La fila se subraya (CSS) y el segmento se raya en diagonal. */
        function resaltar(i) {
            try {
                chart.setActiveElements(i < 0 ? [] : [{ datasetIndex: 0, index: i }]);
                chart.update();
            } catch (e) { }
        }
        lis.forEach(function (li, i) {
            li.addEventListener('mouseenter', function () { setHi(i); resaltar(i); });
            li.addEventListener('mouseleave', function () { setHi(-1); resaltar(-1); });
        });
    }

    // ------------------------------------------------------------------
    // Menú de cambio de tipo
    // ------------------------------------------------------------------
    function prevSvg(tipo) {
        if (tipo === 'bar') return '<svg viewBox="0 0 20 14" class="csm-prev"><rect x="2" y="6" width="3.4" height="6" rx="1" fill="#D62B1F"/><rect x="8.3" y="3" width="3.4" height="9" rx="1" fill="#F26522"/><rect x="14.6" y="9" width="3.4" height="3" rx="1" fill="#FFC72C"/></svg>';
        if (tipo === 'line') return '<svg viewBox="0 0 20 14" class="csm-prev"><polyline points="1,12 6,8 10,10 15,4 19,2" stroke="#2563EB" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>';
        if (tipo === 'area') return '<svg viewBox="0 0 20 14" class="csm-prev"><path d="M1,12 L6,8 L10,10 15,4 19,2 L19,12 Z" fill="#2F7D4F" opacity=".25"/><polyline points="1,12 6,8 10,10 15,4 19,2" stroke="#2F7D4F" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>';
        if (tipo === 'donut') return '<svg viewBox="0 0 20 14" class="csm-prev"><circle cx="10" cy="7" r="5.4" fill="none" stroke="#D62B1F" stroke-width="2.4" stroke-dasharray="8 25"/><circle cx="10" cy="7" r="5.4" fill="none" stroke="#F2A900" stroke-width="2.4" stroke-dasharray="6 25" stroke-dashoffset="-8"/><circle cx="10" cy="7" r="5.4" fill="none" stroke="#2F7D4F" stroke-width="2.4" stroke-dasharray="11 25" stroke-dashoffset="-14"/></svg>';
        if (tipo === 'pie') return '<svg viewBox="0 0 20 14" class="csm-prev"><path d="M10 7 L10 1.8 A5.2 5.2 0 0 1 14.6 4.2 Z" fill="#D62B1F"/><path d="M10 7 L14.6 4.2 A5.2 5.2 0 0 1 13 11.6 Z" fill="#2563EB" opacity=".85"/><path d="M10 7 L13 11.6 A5.2 5.2 0 0 1 6.6 11.8 Z" fill="#2F7D4F" opacity=".85"/></svg>';
        if (tipo === 'funnel') return '<svg viewBox="0 0 20 14" class="csm-prev"><path d="M4 1 H16 L13 6 H7 Z" fill="#F26522" opacity=".9"/><path d="M6.4 7 H13.6 L12 12 H8 Z" fill="#F26522" opacity=".5"/></svg>';
        if (tipo === 'pyramid') return '<svg viewBox="0 0 20 14" class="csm-prev"><path d="M7 1 H13 L15 6 H5 Z" fill="#B7791F" opacity=".45"/><path d="M5.6 7 H14.4 L16 12 H4 Z" fill="#B7791F" opacity=".85"/></svg>';
        var s = 'stroke="#212121" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round';
        return '<svg viewBox="0 0 20 14" class="csm-prev"><text x="10" y="11" text-anchor="middle" font-size="9" font-weight="bold" fill="#212121">123</text></svg>';
    }

    function buildMenu(card, widget) {
        var wrap = card.querySelector('[data-switch]');
        if (!wrap) return;
        var btn = domEl('<button type="button" class="chart-switch-btn" data-toggle><svg class="icon icon-sm"><use href="#i-chart"/></svg> Tipo</button>');
        var menu = domEl('<div class="chart-switch-menu" hidden></div>');
        TIPOS.forEach(function (tp) {
            var b = domEl('<button type="button" data-type="' + tp + '">' + prevSvg(tp) + '<span>' + TIPO_LABEL[tp] + '</span></button>');
            b.addEventListener('click', function () {
                estado[widget] = tp;
                markActive();
                menu.hidden = true;
                wrap.removeAttribute('data-open');
                render(card, widget);
            });
            menu.appendChild(b);
        });
        wrap.appendChild(btn);
        wrap.appendChild(menu);
        var refrescar = domEl('<button type="button" class="chart-refresh-btn" title="Recargar el gráfico"><svg class="icon"><use href="#i-refresh"/></svg></button>');
        refrescar.setAttribute("aria-label", "Recargar el gráfico");
        refrescar.addEventListener("click", function () {
            refrescar.classList.add("is-girando");
            render(card, widget);
            setTimeout(function () { refrescar.classList.remove("is-girando"); }, 350);
        });
        wrap.appendChild(refrescar);
        function markActive() {
            var cur = estado[widget] || DEFAULT_TIPO[widget];
            /* El botón muestra el icono y nombre del tipo elegido. */
            btn.innerHTML = prevSvg(cur) + '<span>' + TIPO_LABEL[cur] + '</span>';
            Array.prototype.forEach.call(menu.querySelectorAll('button[data-type]'), function (b) {
                b.classList.toggle('is-active', b.dataset.type === cur);
            });
        }
        markActive();
        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            var open = !wrap.hasAttribute('data-open');
            document.querySelectorAll('.chart-switch-menu').forEach(function (m) { m.hidden = true; });
            Array.prototype.forEach.call(document.querySelectorAll('[data-switch]'), function (el) { el.removeAttribute('data-open'); });
            if (open) { wrap.setAttribute('data-open', ''); menu.hidden = false; }
        });
    }
    document.addEventListener('click', function (e) {
        if (!e.target.closest('.chart-switch')) {
            document.querySelectorAll('.chart-switch-menu').forEach(function (m) { m.hidden = true; });
            Array.prototype.forEach.call(document.querySelectorAll('[data-switch]'), function (el) { el.removeAttribute('data-open'); });
        }
    });

    // ------------------------------------------------------------------
    // Tabla dinámica pivote
    // ------------------------------------------------------------------
    function renderPivot(dim) {
        var meta = D.pivot.dimensiones[dim];
        var body = document.getElementById("pivotBody");
        document.getElementById("pivotCol1").textContent = meta.label;
        document.getElementById("pivotDimLabel").textContent = meta.label.toLowerCase();
        var rows = meta.rows.filter(function (r) {
            return meta.aggregate_only || r.total > 0 || r.vencido > 0;
        });
        var pop0 = document.getElementById("pivotPop");
        if (pop0) pop0.remove();
        if (!rows.length) {
            body.innerHTML = '<tr class="table-empty"><td colspan="6">Sin datos todavía.</td></tr>';
            return;
        }
        var tot = { label: 'Total', abrir: 0, espera: 0, vencido: 0, cerrado: 0, resueltos: 0, total: 0, totalRow: true };
        rows.forEach(function (r) {
            tot.abrir += r.abrir; tot.espera += r.espera; tot.vencido += r.vencido; tot.cerrado += r.cerrado; tot.resueltos += r.resueltos; tot.total += r.total;
        });
        var html = rows.map(function (r) {
            return '<tr>' +
                '<td class="pivot-lead">' + esc(r.label) + '</td>' +
                '<td class="num pivot-num" data-f="abierto" title="Ver abiertas">' + r.abrir + '</td>' +
                '<td class="num pivot-num" data-f="en-progreso" title="Ver en progreso">' + r.espera + '</td>' +
                '<td class="num col-vencido pivot-num" data-f="vencido" title="Ver vencidas">' + (r.vencido ? '<span class="badge-vencido">' + r.vencido + '</span>' : '—') + '</td>' +
                '<td class="num pivot-num" data-f="cerrado" title="Ver cerradas">' + r.cerrado + '</td>' +
                '<td class="num pivot-num" data-f="resuelto" title="Ver resueltas">' + r.resueltos + '</td>' +
                '</tr>';
        }).join('');
        html += '<tr class="pivot-total-row"><td>' + esc(tot.label) + '</td><td class="num">' + tot.abrir + '</td><td class="num">' + tot.espera + '</td><td class="num col-vencido">' + (tot.vencido ? '<span class="badge-vencido">' + tot.vencido + '</span>' : '—') + '</td><td class="num">' + tot.cerrado + '</td><td class="num"><strong>' + tot.resueltos + '</strong></td></tr>';
        body.innerHTML = html;
        if (meta.aggregate_only) return;
        Array.prototype.forEach.call(body.rows, function (tr, i) {
            if (!rows[i]) return;
            var lead = tr.querySelector('.pivot-lead');
            lead.addEventListener('click', function (e) {
                e.stopPropagation();
                showPivotPop(rows[i], lead);
            });
            Array.prototype.forEach.call(tr.querySelectorAll('.pivot-num'), function (cell) {
                cell.addEventListener('click', function (e) {
                    e.stopPropagation();
                    showPivotPop(rows[i], cell, cell.dataset.f);
                });
            });
        });
    }

    var FILTROS = [
        { key: 'abierto', label: 'Abiertas', color: '#2563EB', icono: 'i-inbox', tint: 'st-ic-abiertos', cuenta: function (r) { return r.abrir; } },
        { key: 'en-progreso', label: 'En progreso', color: '#B7791F', icono: 'i-wrench', tint: 'st-ic-progreso', cuenta: function (r) { return r.espera; } },
        { key: 'vencido', label: 'Vencidas', color: '#D62B1F', icono: 'i-alert', tint: 'st-ic-vencidos', cuenta: function (r) { return r.vencido; } },
        { key: 'cerrado', label: 'Cerradas', color: '#8A8A86', icono: 'i-lock', tint: 'st-ic-cerrados', cuenta: function (r) { return r.cerrado; } },
        { key: 'resuelto', label: 'Resueltas', color: '#2F7D4F', icono: 'i-check-circle', tint: 'st-ic-resueltos', cuenta: function (r) { return r.resueltos; } }
    ];
    function matchF(t, f) {
        if (f === 'vencido') return !!t.vencido;
        if (f === 'resuelto') return !!t.resuelto;
        return t.estado === f;
    }

    function showPivotPop(r, anchor, f) {
        var card = document.querySelector('[data-pivot-card]');
        if (!card) return;
        var vieja = document.getElementById('pivotPop');
        if (vieja) vieja.remove();
        var pop = domEl('<div class="pivot-pop" id="pivotPop"></div>');
        function por(key) {
            for (var i = 0; i < FILTROS.length; i++) if (FILTROS[i].key === key) return FILTROS[i];
            return FILTROS[0];
        }
        if (!f) {
            var mejor = FILTROS[0], mejorV = -1;
            FILTROS.forEach(function (F) { var v = F.cuenta(r); if (v > mejorV) { mejorV = v; mejor = F; } });
            f = mejor.key;
        }
        var activo = f;
        var pct = 0;
        var pendiente = (r.abrir || 0) + (r.espera || 0);
        if (pendiente) { pct = Math.round((r.vencido || 0) / pendiente * 100); }
        var ans = (r.vencido || r.riesgo) ? 'ANS: <strong class="ph-v">' + r.vencido + ' vencid' + (r.vencido === 1 ? 'a' : 'as') + '</strong> · <strong class="ph-r">' + r.riesgo + ' por vencer</strong>' : 'ANS ok';
        var base = card.getAttribute('data-detalle-url') || '';
        pop.innerHTML =
            '<div class="pivot-pop-head">' +
            '<strong class="pivot-pop-titulo">' + esc(r.label) + '</strong><span class="pivot-pop-sub"></span>' +
            '<button type="button" class="pivot-pop-close" title="Cerrar">&times;</button>' +
            '</div>' +
            '<div class="pivot-pop-stats"></div>' +
            '<div class="pivot-pop-foot"></div>' +
            '<div class="pivot-pop-cats"></div>' +
            '<div class="pivot-pop-list"></div>';
        var elStats = pop.querySelector('.pivot-pop-stats');
        var elSub = pop.querySelector('.pivot-pop-sub');
        var elFoot = pop.querySelector('.pivot-pop-foot');
        var elCats = pop.querySelector('.pivot-pop-cats');
        var elList = pop.querySelector('.pivot-pop-list');

        function pintar() {
            var F = por(activo);
            elSub.textContent = ' · ' + F.label + ' (' + F.cuenta(r) + ')';
            elStats.innerHTML = FILTROS.map(function (F2) {
                return '<button type="button" class="pivot-pop-stat st-btn' + (F2.key === activo ? ' is-activo' : '') + '" data-f="' + F2.key + '">' +
                    '<span class="pivot-pop-bola ' + F2.tint + '"><b>' + F2.cuenta(r) + '</b>' +
                    '<span class="pivot-pop-glyph"><svg class="icon"><use href="#' + F2.icono + '"/></svg></span></span>' +
                    '<span class="pivot-pop-nom">' + F2.label + '</span></button>';
            }).join('');
            var filtrados = (r.tickets || []).filter(function (t) { return matchF(t, activo); });
            var lista = filtrados.map(function (t) {
                var et = ESTADOS[t.estado] || t.estado;
                var pill = t.vencido
                    ? '<span class="pivot-pop-pill gr-v">Vencido</span>'
                    : '<span class="pivot-pop-pill gr-' + t.estado + '">' + et + '</span>';
                var ico = t.vencido ? 'i-alert' : 'i-ticket';
                var cls = t.vencido ? 'gr-v' : 'gr-' + t.estado;
                return '<a class="pivot-pop-ticket" href="' + base.replace('0', t.id) + '">' +
                    '<span class="pivot-pop-ico ' + cls + '"><svg class="icon"><use href="#' + ico + '"/></svg></span>' +
                    '<span class="pivot-pop-code">' + esc(t.codigo) + '</span>' +
                    '<span class="pivot-pop-title">' + esc(t.titulo) + '</span>' +
                    pill + '</a>';
            }).join('');
            var totalF = F.cuenta(r);
            if (lista && totalF > filtrados.length) lista += '<div class="pivot-pop-mas">y ' + (totalF - filtrados.length) + ' más…</div>';
            if (!lista) lista = totalF > 0
                ? '<div class="pivot-pop-mas">y ' + totalF + ' más…</div>'
                : '<div class="pivot-pop-vacio">Sin tickets en esta vista.</div>';
            elList.innerHTML = lista;
            var esAb = activo === 'abierto' || activo === 'en-progreso' || activo === 'vencido';
            elFoot.innerHTML = ans + ' · ' + pct + '% vencidas del pendiente';
            elFoot.style.display = esAb ? '' : 'none';
            elCats.innerHTML = (r.categorias || []).map(function (c) {
                return '<span class="pivot-pop-cat">' + esc(c) + '</span>';
            }).join('');
            elCats.style.display = (esAb && elCats.innerHTML) ? '' : 'none';
            Array.prototype.forEach.call(elStats.querySelectorAll('[data-f]'), function (b) {
                b.addEventListener('click', function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                    if (b.dataset.f !== activo) { activo = b.dataset.f; pintar(); }
                });
            });
        }
        pintar();
        card.appendChild(pop);
        var acr = anchor.getBoundingClientRect();
        pop.style.visibility = 'hidden';
        var w = pop.offsetWidth;
        var h = pop.offsetHeight;
        var x = Math.max(6, Math.min(acr.left + 8, window.innerWidth - w - 6));
        var y = Math.max(6, Math.min(acr.top - 2, window.innerHeight - h - 6));
        pop.style.left = x + 'px';
        pop.style.top = y + 'px';
        pop.style.visibility = '';
        requestAnimationFrame(function () { pop.classList.add('is-in'); });
        function cerrarScroll(e) {
            if (!e.target.closest || !e.target.closest('#pivotPop')) {
                var p = document.getElementById('pivotPop');
                if (p) p.remove();
                document.removeEventListener('scroll', cerrarScroll, true);
            }
        }
        document.addEventListener('scroll', cerrarScroll, true);
        pop.querySelector('.pivot-pop-close').addEventListener('click', function (e) {
            e.stopPropagation();
            pop.remove();
        });
    }

    function esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    // ------------------------------------------------------------------
    // Leyenda de pies (según datos)
    // ------------------------------------------------------------------
    function buildPieLegends(solo) {
        var widgets = solo || ['modo', 'categoria', 'prioridad'];
        widgets.forEach(function (widget) {
            var card = document.querySelector('.chart-modal[data-widget="' + widget + '"]');
            if (!card) return;
            var leg = card.querySelector('[data-pie-legend]');
            if (!leg) return;
            var prs = pairs(widget);
            var total = prs.reduce(function (s, p) { return s + p.value; }, 0);
            leg.innerHTML = prs.map(function (p) {
                var pct = total ? Math.round(p.value / total * 100) : 0;
                return '<li title="' + esc(p.label) + '" style="--seg:' + p.color + '"><span class="pl-dot" style="background:' + p.color + '"></span>' +
                    '<span class="pl-name">' + esc(p.label) + '</span>' +
                    '<span class="pl-val">' + p.value + '</span>' +
                    '<span class="pl-pct">' + pct + '%</span></li>';
            }).join('');
            if (!prs.length) leg.innerHTML = '<li class="chart-empty" style="border:0">Sin datos.</li>';
        });
    }

    // ------------------------------------------------------------------
    // Init
    // ------------------------------------------------------------------
    function init() {
        var pivotSel = document.getElementById("pivotDim");
        if (pivotSel) {
            renderPivot(pivotSel.value);
            pivotSel.addEventListener("change", function () { renderPivot(pivotSel.value); });
            var pivotCard = pivotSel.closest(".chart-card");
            if (pivotCard && pivotCard.querySelector(".chart-card-head")) {
                var tools = pivotCard.querySelector(".dash-head-tools");
                if (!tools) {
                    tools = document.createElement("div");
                    tools.className = "dash-head-tools";
                    pivotCard.querySelector(".chart-card-head").appendChild(tools);
                }
                var ref = document.createElement("button");
                ref.type = "button";
                ref.className = "chart-refresh-btn";
                ref.title = "Recargar la tabla";
                ref.setAttribute("aria-label", "Recargar la tabla");
                ref.innerHTML = '<svg class="icon"><use href="#i-refresh"/></svg>';
                ref.addEventListener("click", function () {
                    ref.classList.add("is-girando");
                    renderPivot(pivotSel.value);
                    setTimeout(function () { ref.classList.remove("is-girando"); }, 350);
                });
                tools.appendChild(ref);
            }
        }
        buildPieLegends();
        Array.prototype.forEach.call(document.querySelectorAll('.chart-modal'), function (card) {
            var widget = card.dataset.widget;
            estado[widget] = DEFAULT_TIPO[widget] || 'bar';
            buildMenu(card, widget);
            render(card, widget);
            var obsSelector = card.querySelector('[data-obs-selector]');
            if (obsSelector) {
                obsSelector.addEventListener('change', function () {
                    estado[widget] = obsSelector.value === 'estado_lista'
                        ? 'donut'
                        : (obsSelector.value ? 'bar' : (DEFAULT_TIPO[widget] || 'bar'));
                    actualizarTituloObservador(card);
                    // La leyenda se rehace antes de enlazar el hover del
                    // canvas: así ambos conservan el mismo realce diagonal
                    // y el cursor interactivo del panel administrador.
                    buildPieLegends([widget]);
                    render(card, widget);
                });
            }
        });
        if (window.MutationObserver) {
            new MutationObserver(function () {
                document.querySelectorAll('.chart-modal[data-widget]').forEach(function (card) {
                    render(card, card.dataset.widget);
                });
            }).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
        }
        // Selector de ámbito de las dos tortas (abiertas, en progreso, ...).
        // El título usa la etiqueta del <option> elegido para no duplicar
        // el diccionario de nombres en el JS.
        ['categoria', 'prioridad'].forEach(function (widget) {
            var sel = document.getElementById(SCOPE_ID[widget]);
            if (!sel) return;
            function etiquetar() {
                var opcion = sel.options[sel.selectedIndex];
                var lb = document.getElementById(SCOPE_LABEL[widget]);
                if (lb && opcion) lb.textContent = opcion.textContent.trim();
            }
            sel.addEventListener('change', function () {
                etiquetar();
                var card = document.querySelector('.chart-modal[data-widget="' + widget + '"]');
                if (card) render(card, widget);
                buildPieLegends([widget]);
            });
            etiquetar();
        });
        var range = document.getElementById('wLineaRange');
        if (range) range.addEventListener('change', function () {
            var card = document.querySelector('[data-widget="linea"]');
            if (card) render(card, 'linea');
        });
        var dim = document.getElementById('wSlaDim');
        if (dim) dim.addEventListener('change', function () {
            var card = document.querySelector('[data-widget="sla"]');
            if (card) render(card, 'sla');
        });
        var comp20 = document.getElementById('wComp20');
        if (comp20) comp20.addEventListener('change', function () {
            var lb = document.getElementById('comp20Label');
            if (lb) lb.textContent = comp20.options[comp20.selectedIndex].textContent;
            var card = document.querySelector('[data-widget="comp20"]');
            if (card) render(card, 'comp20');
        });
        document.addEventListener('click', function () {
            var p = document.getElementById('pivotPop');
            if (p) p.remove();
        });
        initTecModal();
    }

    function tecRow(t) {
        var pill = '<span class="tec-pill tp-' + t.estado + '">' + esc(t.estado_label || ESTADOS[t.estado] || t.estado) + '</span>';
        if (t.ans === 'vencido') pill += '<span class="tec-pill tp-vencido">Vencido</span>';
        return '<li class="tec-ticket">' +
            '<a class="tec-ticket-main" href="' + t.detalle_url + '">' +
            '<span class="tec-ticket-code">' + esc(t.codigo) + '</span>' +
            '<span class="tec-ticket-title">' + esc(t.titulo) + '</span>' +
            '<span class="tec-ticket-cat">' + esc(t.categoria) + '</span>' +
            '</a>' +
            '<div class="tec-ticket-meta">' +
            pill +
            '<span class="tec-pill tp-muted">' + esc(t.prioridad) + '</span>' +
            '<span class="tec-pill tp-muted">' + esc(t.solicitante) + '</span>' +
            '</div>' +
            '</li>';
    }

    function initTecModal() {
        var card = document.querySelector('.mesa-tec-card');
        if (!card) return;
        var modal = document.getElementById('modalTecTickets');
        if (!modal) return;
        var title = document.getElementById('tecModalTitle');
        var meta = document.getElementById('tecModalMeta');
        var list = document.getElementById('tecModalList');
        card.addEventListener('click', function (event) {
                var btn = event.target.closest('.tec-open');
                if (!btn || !card.contains(btn)) return;
                var pk = btn.dataset.pk;
                title.textContent = btn.dataset.nombre || 'Técnico';
                meta.textContent = 'Tiene ' + (btn.dataset.total || 0) + ' tickets a cargo.';
                list.innerHTML = '<li class="tec-modal-empty">Cargando tickets…</li>';
                modal.classList.add('open');
                document.body.style.overflow = 'hidden';
                fetch('/panel/api/tecnico/' + pk + '/tickets/')
                    .then(function (r) { return r.json(); })
                    .then(function (d) {
                        meta.textContent = 'Técnico ' + d.nombre + ' · ' + d.total + ' ticket' + (d.total === 1 ? '' : 's') + ' asignado' + (d.total === 1 ? '' : 's');
                        if (!d.tickets.length) {
                            list.innerHTML = '<li class="tec-modal-empty">Este técnico no tiene tickets asignados.</li>';
                            return;
                        }
                        list.innerHTML = d.tickets.map(tecRow).join('');
                    })
                    .catch(function () {
                        list.innerHTML = '<li class="tec-modal-empty">No se pudieron cargar los tickets.</li>';
                    });
        });
    }

    /* API pública mínima para que el panel admin cambie sus datos sin
       reconstruir la página. Chart.js interpola los nuevos datasets. */
    window.DoggerDashboardCharts = {
        update: function (nextData) {
            if (!nextData || typeof nextData !== 'object') return;
            D = nextData;
            SERIE = D.colores_serie || SERIE;
            var pivotSel = document.getElementById('pivotDim');
            if (pivotSel && D.pivot && D.pivot.dimensiones[pivotSel.value]) {
                renderPivot(pivotSel.value);
            }
            buildPieLegends();
            Array.prototype.forEach.call(document.querySelectorAll('.chart-modal'), function (card) {
                render(card, card.dataset.widget);
            });
        }
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
