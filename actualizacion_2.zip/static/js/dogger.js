/* Dogger HelpDesk — interacciones globales (sin dependencias) */
(function () {
    "use strict";

    /* ---- Toast de notificación: auto-cierre con pausa al hover ---- */
    document.querySelectorAll(".toast-stack .toast").forEach(function (el) {
        var close = el.querySelector(".toast-close");
        var delay = el.classList.contains("toast-error") ? 12000 : 6500;
        el.style.setProperty("--toast-delay", delay + "ms");
        var timer = null;
        function dismiss() {
            if (!el.isConnected) return;
            el.classList.add("toast-out");
            setTimeout(function () { el.remove(); }, 340);
        }
        if (close) close.addEventListener("click", dismiss);
        /* El CSS pausa la barra de progreso en hover; aquí retomamos el cierre
           contando el tiempo transcurrido para no disparar inmediatamente. */
        var started = Date.now();
        var remaining = delay;
        function schedule() {
            if (timer) { clearTimeout(timer); timer = null; }
            timer = setTimeout(function () {
                el.classList.add("toast-out");
                setTimeout(function () { el.remove(); }, 340);
            }, remaining);
        }
        el.addEventListener("mouseenter", function () {
            remaining -= Date.now() - started;
            if (timer) { clearTimeout(timer); timer = null; }
        });
        el.addEventListener("mouseleave", function () {
            if (remaining <= 0) return;
            started = Date.now();
            schedule();
        });
        schedule();
    });

    /* ---- Modal de confirmación personalizado (reemplaza confirm nativo) ---- */
    var confirmOverlay = document.getElementById("confirm-overlay");
    var confirmMsgEl = document.getElementById("confirm-msg");
    var confirmOkBtn = document.getElementById("confirm-ok");
    var confirmCancelBtn = document.getElementById("confirm-cancel");
    var confirmCallback = null;
    var confirmMotivoWrap = document.getElementById("confirm-motivo-wrap");
    var confirmMotivo = document.getElementById("confirm-motivo");

    function cerrarConfirm() {
        if (!confirmOverlay) return;
        confirmOverlay.classList.remove("open");
        confirmCallback = null;
    }
    var confirmTitleEl = document.getElementById("confirm-title");
    var confirmNoteEl = document.getElementById("confirm-note");
    var confirmIconUse = document.getElementById("confirm-icon-use");

    /* opciones: { titulo, icono, nota } para que cada confirmación se vea
       como la que le corresponde (papelera, cierre,Combination, etc.). */
    function confirmarAction(mensaje, onOk, textoOk, opciones) {
        if (!confirmOverlay || !confirmMsgEl) return;
        var op = opciones || {};
        var textoAccion = (mensaje || "") + " " + (textoOk || "") + " " + (op.titulo || "");
        var accion = /eliminar|borrar|purgar|mover.+papelera/iu.test(textoAccion) ? { titulo:"Confirmar eliminación", icono:"#i-trash", boton:"Eliminar" } :
            /restaurar|recuperar/iu.test(textoAccion) ? { titulo:"Confirmar restauración", icono:"#i-refresh", boton:"Restaurar" } :
            /cerrar|cancelar ticket|cancelar solicitud/iu.test(textoAccion) ? { titulo:"Confirmar cierre", icono:"#i-lock", boton:"Cerrar" } :
            /asignar|tomar/iu.test(textoAccion) ? { titulo:"Confirmar asignación", icono:"#i-user-round-check", boton:"Confirmar" } :
            { titulo:"Confirmar acción", icono:"#i-circle-alert", boton:"Continuar" };
        confirmMsgEl.textContent = mensaje;
        if (confirmMotivoWrap) confirmMotivoWrap.hidden = !op.solicitarMotivo;
        if (confirmMotivo) confirmMotivo.value = "";
        confirmCallback = onOk;
        if (confirmTitleEl) confirmTitleEl.textContent = op.titulo || accion.titulo;
        if (confirmIconUse) confirmIconUse.setAttribute("href", op.icono || accion.icono);
        if (confirmNoteEl) {
            var nota = op.nota || "";
            confirmNoteEl.textContent = nota;
            confirmNoteEl.hidden = !nota;
        }
        if (confirmOkBtn) {
            var peligro = /eliminar|borra|quedar/iu.test(mensaje || "");
            var textoBtn = textoOk || accion.boton;
            confirmOkBtn.textContent = textoBtn;
            confirmOkBtn.classList.toggle("btn-danger", peligro);
        }
        confirmOverlay.classList.add("open");
        if (confirmOkBtn) confirmOkBtn.focus();
    }
    if (confirmOkBtn) confirmOkBtn.addEventListener("click", function () {
        var cb = confirmCallback;
        cerrarConfirm();
        if (cb) {
            if (confirmMotivo && confirmMotivoWrap && !confirmMotivoWrap.hidden) cb(confirmMotivo.value);
            else cb();
        }
    });
    if (confirmCancelBtn) confirmCancelBtn.addEventListener("click", cerrarConfirm);
    if (confirmOverlay) confirmOverlay.addEventListener("click", function (e) {
        if (e.target === confirmOverlay) cerrarConfirm();
    });
    document.addEventListener("keydown", function (e) {
        if (e.key === "Escape" && confirmOverlay && confirmOverlay.classList.contains("open")) cerrarConfirm();
    });
    window.DoggerConfirma = confirmarAction;

    /* Intercepta <form onsubmit="return confirm('...')"> (fase captura) */
    document.addEventListener("submit", function (e) {
        var f = e.target;
        if (!f || f.tagName !== "FORM") return;
        var os = f.getAttribute("onsubmit") || "";
        var mm = os.match(/confirm\(\s*'([^']*)'\s*\)|confirm\(\s*"([^"]*)"\s*\)/);
        if (!mm) return;
        e.preventDefault();
        e.stopImmediatePropagation();
        var motivoPapelera = f.hasAttribute("data-motivo-papelera");
        confirmarAction(mm[1] || mm[2], function (motivo) {
            if (motivoPapelera) {
                var campo = f.querySelector('input[name="motivo_eliminacion"]');
                if (!campo) { campo = document.createElement("input"); campo.type = "hidden"; campo.name = "motivo_eliminacion"; f.appendChild(campo); }
                campo.value = motivo;
            }
            f.removeAttribute("onsubmit");
            try { f.submit(); } catch (err) { location.reload(); }
        }, motivoPapelera ? "Enviar a papelera" : undefined, motivoPapelera ? {titulo:"Enviar a la papelera", icono:"#i-trash", solicitarMotivo:true} : undefined);
    }, true);

    /* ---- Buscadores con resultado automático ----
       Todo input[type="search"] con data-autosubmit envía su formulario al
       dejar de escribir o al pegar (600 ms), sin pulsar Buscar. Funciona
       igual al escribir letra por letra que al pegar el nombre completo. */
    var _buscaTimer = null;
    document.addEventListener("input", function (e) {
        var inp = e.target && e.target.closest
            ? e.target.closest('input[type="search"][data-autosubmit]')
            : null;
        if (!inp || !inp.form) { return; }
        clearTimeout(_buscaTimer);
        _buscaTimer = setTimeout(function () {
            if (inp.form.requestSubmit) { inp.form.requestSubmit(); }
            else { inp.form.submit(); }
        }, 600);
    });
    document.addEventListener("keydown", function (e) {
        if (e.key === "Enter"
            && e.target.matches
            && e.target.matches('input[type="search"][data-autosubmit]')) {
            clearTimeout(_buscaTimer);
        }
    });

    /* ---- Búsqueda en vivo sin recargar ----
       input[type="search"][data-vivo] filtra al escribir o pegar: pide la
       misma URL al servidor y cambia solo las filas, el conteo y los
       enlaces de paginación. Sin recarga, sin perder el foco ni lo escrito.
       Con Enter o sin JS, el formulario se envía normal. */
    (function () {
        var temporizadores = new WeakMap();
        var controles = new WeakMap();
        function ambitoDe(input) {
            var form = input.form;
            if (!form) { return document; }
            return form.closest(".table-card, .chart-card, .corp-table-card, section, main") || document;
        }
        function sel(input, attr, defecto) {
            return input.getAttribute(attr) || defecto;
        }
        function pintaBuscando(input, on) {
            input.classList.toggle("is-buscando", !!on);
        }
        function refrescarPaginacion(ambito, input) {
            var nombre = input.getAttribute("name");
            if (!nombre) { return; }
            ambito.querySelectorAll(".pagination-links a[href]").forEach(function (a) {
                try {
                    var u = new URL(a.getAttribute("href"), window.location.origin);
                    if (input.value) { u.searchParams.set(nombre, input.value); }
                    else { u.searchParams.delete(nombre); }
                    a.setAttribute("href", u.pathname + u.search + u.hash);
                } catch (e) { }
            });
        }
        function buscar(input) {
            var form = input.form;
            if (!form) { return; }
            var ambito = ambitoDe(input);
            var cont = ambito.querySelector(sel(input, "data-vivo-contenedor", "tbody"));
            if (!cont) { return; }
            var anterior = controles.get(input);
            if (anterior) { try { anterior.abort(); } catch (e) { } }
            var control = ("AbortController" in window) ? new AbortController() : null;
            controles.set(input, control);
            var params = new URLSearchParams(new FormData(form));
            var url = form.getAttribute("action") || window.location.pathname;
            url += (url.indexOf("?") === -1 ? "?" : "&") + params.toString();
            pintaBuscando(input, true);
            fetch(url, {
                headers: { "X-Requested-With": "XMLHttpRequest" },
                credentials: "same-origin",
                signal: control ? control.signal : undefined
            }).then(function (r) {
                if (!r.ok) { throw new Error("http " + r.status); }
                return r.text();
            }).then(function (html) {
                var doc = new DOMParser().parseFromString(html, "text/html");
                var contNuevo = doc.querySelector(sel(input, "data-vivo-contenedor", "tbody"));
                if (!contNuevo) { return; }
                cont.innerHTML = contNuevo.innerHTML;
                var selConteo = sel(input, "data-vivo-conteo", ".toolbar-count");
                if (selConteo) {
                    var cViejo = ambito.querySelector(selConteo);
                    var cNuevo = doc.querySelector(selConteo);
                    if (cViejo && cNuevo) { cViejo.textContent = cNuevo.textContent; }
                }
                refrescarPaginacion(ambito, input);
                try {
                    window.history.replaceState(null, "", url);
                } catch (e) { }
            }).catch(function () { }).then(function () {
                pintaBuscando(input, false);
            });
        }
        document.addEventListener("input", function (e) {
            var inp = e.target && e.target.closest
                ? e.target.closest('input[type="search"][data-vivo]')
                : null;
            if (!inp || !inp.form) { return; }
            clearTimeout(temporizadores.get(inp));
            temporizadores.set(inp, setTimeout(function () { buscar(inp); }, 350));
        });
    })();

    /* ---- Modales ---- */
    function openModal(sel) {
        var m = document.querySelector(sel);
        if (m) { m.classList.add("open"); document.body.style.overflow = "hidden"; }
    }
    function closeModal(m) {
        m.classList.remove("open");
        if (!document.querySelector(".modal-overlay.open")) document.body.style.overflow = "";
    }
    /* Delegado en document: tambien abre los botones que llegan por AJAX
       (como "Asignar tarea" dentro de la ficha expandida de usuarios). */
    document.addEventListener("click", function (e) {
        var passwordToggle = e.target.closest("[data-password-toggle]");
        if (passwordToggle) {
            var passwordInput = document.getElementById(
                passwordToggle.getAttribute("data-password-toggle")
            );
            if (passwordInput) {
                var mostrar = passwordInput.type === "password";
                passwordInput.type = mostrar ? "text" : "password";
                passwordToggle.textContent = mostrar ? "Ocultar" : "Mostrar";
                passwordToggle.setAttribute("aria-pressed", String(mostrar));
            }
            return;
        }
        var btn = e.target.closest("[data-open-modal]");
        if (!btn) return;
        e.preventDefault();
        openModal(btn.getAttribute("data-open-modal"));
    });
    document.querySelectorAll(".modal-overlay").forEach(function (m) {
        m.addEventListener("click", function (e) {
            if (e.target === m || e.target.closest(".modal-close")) closeModal(m);
        });
    });
    document.addEventListener("keydown", function (e) {
        if (e.key === "Escape") {
            document.querySelectorAll(".modal-overlay.open").forEach(closeModal);
        }
    });

    /* ---- Grupos de categorías: colapsar/expandir (cerrados por defecto) ---- */
    document.querySelectorAll(".cat-group-head").forEach(function (head) {
        head.addEventListener("click", function () {
            var card = head.closest(".cat-group-card");
            var isCollapsed = card.classList.toggle("collapsed");
            head.querySelectorAll(".cat-toggle").forEach(function (b) {
                b.setAttribute("aria-expanded", isCollapsed ? "false" : "true");
            });
        });
    });

    /* ---- Edición en línea ---- */
    document.querySelectorAll("[data-inline-toggle]").forEach(function (btn) {
        btn.addEventListener("click", function (e) {
            e.preventDefault();
            e.stopPropagation();
            var target = document.getElementById(btn.getAttribute("data-inline-toggle"));
            if (target) {
                target.classList.toggle("open");
                var first = target.querySelector("input, select");
                if (first && target.classList.contains("open")) first.focus();
            }
        });
    });

    /* ---- Filtro rápido de tabla (client-side) ---- */
    document.querySelectorAll("[data-table-filter]").forEach(function (input) {
        var table = document.getElementById(input.getAttribute("data-table-filter"));
        if (!table) return;
        input.addEventListener("input", function () {
            var q = input.value.trim().toLowerCase();
            table.querySelectorAll("tbody tr").forEach(function (row) {
                row.style.display = row.textContent.toLowerCase().indexOf(q) !== -1 ? "" : "none";
            });
        });
    });

    /* ---- Selects que envían su formulario al cambiar ---- */
    document.querySelectorAll("select[data-autosubmit]").forEach(function (sel) {
        sel.addEventListener("change", function () { sel.form.submit(); });
    });

    /* ---- Selector "Filas por página": recarga con el nuevo tamaño ---- */
    /* ---- Selects visuales para barras de filtros ---- */
    document.querySelectorAll("select[data-custom-dropdown]").forEach(function (sel) {
        if (sel.dataset.dropdownReady === "1") return;
        sel.dataset.dropdownReady = "1";
        var dropdown = document.createElement("details");
        dropdown.className = "custom-dropdown";
        dropdown.dataset.filterKind = sel.name || "";
        var summary = document.createElement("summary");
        var label = document.createElement("span");
        var arrow = document.createElementNS("http://www.w3.org/2000/svg", "svg");
        arrow.setAttribute("class", "icon");
        arrow.setAttribute("aria-hidden", "true");
        arrow.setAttribute("viewBox", "0 0 24 24");
        arrow.innerHTML = '<path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>';
        summary.appendChild(label);
        summary.appendChild(arrow);
        var options = document.createElement("div");
        options.className = "custom-dropdown-options";
        options.setAttribute("role", "listbox");
        options.setAttribute("aria-label", sel.getAttribute("aria-label") || "Seleccionar opción");
        dropdown.appendChild(summary);
        dropdown.appendChild(options);
        sel.insertAdjacentElement("afterend", dropdown);
        sel.classList.add("custom-dropdown-native");

        function refrescar() {
            label.textContent = sel.options[sel.selectedIndex] ? sel.options[sel.selectedIndex].text : "Seleccionar";
            dropdown.dataset.selectedValue = sel.value || "todas";
            options.innerHTML = "";
            Array.prototype.forEach.call(sel.options, function (option) {
                var button = document.createElement("button");
                button.type = "button";
                button.dataset.optionValue = option.value;
                if (sel.name === "categoria" && option.text.indexOf("›") !== -1) {
                    var parts = option.text.split("›");
                    var group = document.createElement("span");
                    group.className = "custom-dropdown-category-group";
                    group.textContent = parts.shift().trim();
                    var category = document.createElement("span");
                    category.className = "custom-dropdown-category-name";
                    category.textContent = parts.join("›").trim();
                    button.appendChild(group);
                    button.appendChild(category);
                } else {
                    button.textContent = option.text;
                }
                button.disabled = option.disabled;
                if (option.selected) button.setAttribute("aria-selected", "true");
                button.addEventListener("click", function () {
                    if (option.disabled) return;
                    sel.value = option.value;
                    sel.dispatchEvent(new Event("change", { bubbles:true }));
                    dropdown.removeAttribute("open");
                });
                options.appendChild(button);
            });
        }
        refrescar();
        sel.addEventListener("change", refrescar);
        dropdown.addEventListener("toggle", function () {
            if (!dropdown.open) return;
            document.querySelectorAll(".custom-dropdown[open]").forEach(function (other) {
                if (other !== dropdown) other.removeAttribute("open");
            });
        });
    });
    document.addEventListener("click", function (event) {
        if (event.target.closest && event.target.closest(".custom-dropdown")) return;
        document.querySelectorAll(".custom-dropdown[open]").forEach(function (dropdown) { dropdown.removeAttribute("open"); });
    });
    document.addEventListener("keydown", function (event) {
        if (event.key !== "Escape") return;
        document.querySelectorAll(".custom-dropdown[open]").forEach(function (dropdown) { dropdown.removeAttribute("open"); });
    });

    /* ---- Paginación sin salto de contexto ----
       Las tablas del sistema se renderizan en servidor, pero al cambiar de
       página no debemos llevar al usuario al inicio. Se memoriza la posición
       exacta para la URL destino y se restaura cuando termina de pintar. Así
       cada paginador conserva al usuario junto a la tabla que estaba usando. */
    var DoggerPaginacion = (function () {
        var PREFIJO = "dogger:paginacion:scroll:";

        function clave(url) {
            return PREFIJO + url.pathname + url.search;
        }
        function guardar(url) {
            try {
                sessionStorage.setItem(clave(url), JSON.stringify({
                    x: window.scrollX || window.pageXOffset || 0,
                    y: window.scrollY || window.pageYOffset || 0
                }));
            } catch (err) { /* almacenamiento no disponible: navegación normal */ }
        }
        function guardarEnlace(enlace) {
            try {
                var url = new URL(enlace.href, window.location.href);
                if (url.origin === window.location.origin) { guardar(url); }
            } catch (err) { }
        }
        function guardarFormulario(formulario) {
            try {
                var url = new URL(formulario.getAttribute("action") || window.location.href, window.location.href);
                if ((formulario.getAttribute("method") || "get").toLowerCase() === "get") {
                    new FormData(formulario).forEach(function (valor, nombre) {
                        url.searchParams.set(nombre, valor);
                    });
                }
                if (url.origin === window.location.origin) { guardar(url); }
            } catch (err) { }
        }
        function restaurar() {
            var raw;
            try {
                raw = sessionStorage.getItem(clave(new URL(window.location.href)));
                if (raw) { sessionStorage.removeItem(clave(new URL(window.location.href))); }
            } catch (err) { return; }
            if (!raw) { return; }
            try {
                var punto = JSON.parse(raw);
                window.requestAnimationFrame(function () {
                    window.requestAnimationFrame(function () {
                        window.scrollTo({ left: Number(punto.x) || 0, top: Number(punto.y) || 0, behavior: "auto" });
                    });
                });
            } catch (err) { }
        }

        document.addEventListener("click", function (evento) {
            if (evento.defaultPrevented || evento.button !== 0 || evento.metaKey || evento.ctrlKey || evento.shiftKey || evento.altKey) { return; }
            var enlace = evento.target && evento.target.closest
                ? evento.target.closest(".pagination-links a[href], .pagination-bar a.page-pill[href]")
                : null;
            if (enlace && (!enlace.target || enlace.target === "_self")) { guardarEnlace(enlace); }
        }, true);
        window.addEventListener("pageshow", restaurar);

        return { guardarEnlace: guardarEnlace, guardarFormulario: guardarFormulario };
    })();
    window.DoggerPaginacion = DoggerPaginacion;

    var PAGE_PARAMS = ["page", "page_sol", "page_recientes", "page_glpi"];
    document.querySelectorAll("select[data-per-page-param]").forEach(function (sel) {
        sel.addEventListener("change", function () {
            var url = new URL(window.location.href);
            url.searchParams.set(sel.getAttribute("data-per-page-param"), sel.value);
            PAGE_PARAMS.forEach(function (p) { url.searchParams.delete(p); });
            DoggerPaginacion.guardarEnlace({ href: url.toString() });
            window.location.href = url.toString();
        });
    });

    /* ---- Mapa del footer: cambiar punto ---- */
    document.querySelectorAll("[data-maps-src]").forEach(function (btn) {
        btn.addEventListener("click", function () {
            var frame = document.getElementById("doggerMap");
            if (!frame) return;
            frame.src = btn.getAttribute("data-maps-src");
            document.querySelectorAll(".maps-tab.active").forEach(function (t) {
                t.classList.remove("active");
            });
            btn.classList.add("active");
        });
    });

    /* ---- Símbolo del título: el texto que la vista tenía debajo ---- */
    (function () {
        var hint = document.querySelector(".title-hint");
        if (!hint) return;
        var bubble = hint.querySelector(".title-hint-bubble");
        var txt = bubble ? (bubble.textContent || "").replace(/\s+/g, " ").trim() : "";
        /* Sin texto que explicar, el símbolo no se muestra. */
        if (!txt) { hint.remove(); return; }
    })();

    /* ---- Sidebar lateral: pestaña al borde en escritorio,
       hamburguesa en móvil ----
       La pestaña pliega a iconos; la hamburguesa abre el cajón. */
    (function () {
        var side = document.getElementById("sidebar");
        if (!side) return;
        var borde = document.getElementById("sidebarEdge");
        var burger = document.getElementById("sidebarBurger");
        var backdrop = document.getElementById("sidebarBackdrop");
        var expansionTemporal = false;
        var cierreTemporal = null;
        var ratonEscritorio = window.matchMedia("(min-width: 1081px) and (hover: hover) and (pointer: fine)");

        function abrirAlPasar() {
            clearTimeout(cierreTemporal);
            if (!ratonEscritorio.matches || document.documentElement.getAttribute("data-navcompact") !== "1") return;
            expansionTemporal = true;
            document.documentElement.setAttribute("data-navcompact", "0");
            ocultarTip();
            actualizarBorde();
        }
        function cerrarAlSalir() {
            clearTimeout(cierreTemporal);
            cierreTemporal = setTimeout(function () {
                if (!expansionTemporal) return;
                expansionTemporal = false;
                document.documentElement.setAttribute("data-navcompact", "1");
                actualizarBorde();
            }, 180);
        }
        side.addEventListener("mouseenter", abrirAlPasar);
        side.addEventListener("mouseleave", cerrarAlSalir);
        if (borde) {
            borde.addEventListener("mouseenter", abrirAlPasar);
            borde.addEventListener("mouseleave", cerrarAlSalir);
        }

        /* Plegado: se guarda igual que la preferencia de "navegación compacta"
           de Ajustes, así que los dos sitios controlan lo mismo. */
        function plegarA(mini) {
            document.documentElement.setAttribute("data-navcompact", mini ? "1" : "0");
            try { localStorage.setItem("dogger:pv:navcompact" + (document.documentElement.getAttribute("data-preference-suffix") || ":guest"), mini ? "1" : "0"); } catch (e) {}
            actualizarBorde();
        }
        /* La flecha mira hacia donde va el borde: a la derecha para
           desplegar, a la izquierda para plegar. */
        function actualizarBorde() {
            if (!borde) return;
            var mini = document.documentElement.getAttribute("data-navcompact") === "1";
            var uso = borde.querySelector("use");
            if (uso) uso.setAttribute("href", mini ? "#i-arrow-right" : "#i-arrow-left");
            var etiqueta = mini ? "Expandir el menú" : "Contraer el menú";
            borde.setAttribute("aria-label", etiqueta);
            borde.title = etiqueta;
            borde.setAttribute("aria-expanded", String(!mini));
        }
        if (borde) {
            borde.addEventListener("click", function () {
                ocultarTip();
                if (expansionTemporal) {
                    expansionTemporal = false;
                    clearTimeout(cierreTemporal);
                    plegarA(false);
                } else {
                    plegarA(document.documentElement.getAttribute("data-navcompact") !== "1");
                }
            });
        }
        actualizarBorde();

        function abrir(abrir) {
            side.classList.toggle("is-open", abrir);
            if (burger) {
                burger.classList.toggle("is-active", abrir);
                burger.setAttribute("aria-expanded", String(abrir));
            }
            if (backdrop) backdrop.hidden = !abrir;
            document.body.classList.toggle("sidebar-abierto", abrir);
        }
        if (burger) {
            burger.addEventListener("click", function () {
                abrir(!side.classList.contains("is-open"));
            });
        }
        if (backdrop) backdrop.addEventListener("click", function () { abrir(false); });
        document.addEventListener("keydown", function (ev) {
            if (ev.key === "Escape") abrir(false);
        });
        // Al navegar dentro del cajón se cierra, para no tapar la página nueva.
        side.querySelectorAll(".sidebar-link").forEach(function (link) {
            link.addEventListener("click", function () { abrir(false); });
        });
        // Si la ventana crece y deja de ser móvil, el cajón se olvida.
        // Al cambiar de modo se repinta la flecha de la pestaña.
        window.addEventListener("resize", function () {
            if (!ratonEscritorio.matches && expansionTemporal) {
                expansionTemporal = false;
                clearTimeout(cierreTemporal);
                document.documentElement.setAttribute("data-navcompact", "1");
            }
            if (window.innerWidth > 1080) abrir(false);
            else actualizarBorde();
        });

        /* Aviso con el nombre del enlace al pasar el ratón por un icono.
           Va pegado al body y posicionado con fixed porque el menú es la
           zona desplazable: dentro de él el rótulo se recortaba. */
        var tip = document.createElement("div");
        tip.className = "sidebar-tip";
        tip.setAttribute("role", "tooltip");
        tip.hidden = true;
        document.body.appendChild(tip);

        function plegado() {
            return document.documentElement.getAttribute("data-navcompact") === "1"
                && window.innerWidth > 1080;
        }
        function mostrarTip(link) {
            var texto = link.getAttribute("data-title");
            if (!texto) return;
            tip.textContent = texto;
            tip.hidden = false;
            var r = link.getBoundingClientRect();
            var alto = tip.offsetHeight;
            var arriba = r.top + (r.height / 2) - (alto / 2);
            tip.style.left = (r.right + 10) + "px";
            tip.style.top = Math.max(8, Math.min(arriba, window.innerHeight - alto - 8)) + "px";
        }
        function ocultarTip() { tip.hidden = true; }

        side.querySelectorAll(".sidebar-link").forEach(function (link) {
            link.addEventListener("mouseenter", function () { if (plegado()) mostrarTip(link); });
            link.addEventListener("focus", function () { if (plegado()) mostrarTip(link); });
            link.addEventListener("mouseleave", ocultarTip);
            link.addEventListener("blur", ocultarTip);
        });
        side.addEventListener("scroll", ocultarTip, { passive: true });
        window.addEventListener("resize", ocultarTip);
        document.addEventListener("keydown", function (ev) {
            if (ev.key === "Escape") ocultarTip();
        });
    })();

    /* ---- Tooltips de ayuda globales (data-tip) ----
       Solo se muestran si el usuario tiene tooltips_habilitado activo.
       Se controla con data-tooltips="1" en <body>. */
    (function () {
        var body = document.body;
        if (body.getAttribute("data-tooltips") !== "1") return;
        /* El CSS también pinta un tooltip con ::after/::before para cada
           [data-tip]. Si ambos quedan activos salen dos globos con el mismo
           texto, así que aquí se apaga el del CSS. */
        document.documentElement.setAttribute("data-tipjs", "1");
        var tip = document.createElement("div");
        tip.className = "dogger-tooltip";
        tip.setAttribute("role", "tooltip");
        tip.hidden = true;
        document.body.appendChild(tip);
        var timer = null;

        function mostrar(el) {
            var texto = el.getAttribute("data-tip");
            if (!texto) return;
            tip.textContent = texto;
            tip.hidden = false;
            var r = el.getBoundingClientRect();
            var alto = tip.offsetHeight;
            var arriba = r.top + (r.height / 2) - (alto / 2);
            var izquierda = r.left + (r.width / 2);
            var ancho = tip.offsetWidth;
            izquierda = Math.max(8, Math.min(izquierda - ancho / 2, window.innerWidth - ancho - 8));
            tip.style.left = izquierda + "px";
            tip.style.top = Math.max(8, arriba) + "px";
            if (timer) { clearTimeout(timer); timer = null; }
        }
        function ocultar() {
            if (timer) { clearTimeout(timer); }
            timer = setTimeout(function () { tip.hidden = true; }, 150);
        }
        document.querySelectorAll("[data-tip]").forEach(function (el) {
            el.addEventListener("mouseenter", function () { mostrar(el); });
            el.addEventListener("focus", function () { mostrar(el); });
            el.addEventListener("mouseleave", ocultar);
            el.addEventListener("blur", ocultar);
        });
        document.addEventListener("scroll", ocultar, { passive: true });
        window.addEventListener("resize", ocultar);
    })();

    /* ---- Nombre de archivos seleccionados + preview de imagen ----
       Cada archivo elegido sale en un chip con su "×" para quitarlo. El
       contenedor se busca por id (<input>-preview) o dentro del form-group;
       si no existe, se crea debajo del campo, para que ningún formulario
       tenga que acordarse de declararlo. */
    document.querySelectorAll('input[type="file"][multiple], input[type="file"]').forEach(function (input) {
        /* El del chat está oculto y sube el archivo solo: ahí no pinta chips. */
        if (input.hidden) return;
        var esAdjuntoTicket = Boolean(input.closest(".ticket-file-control") && input.multiple);
        var seleccionAnterior = [];
        var actualizacionInterna = false;
        var vistasTemporales = [];
        function cajaPreview() {
            var box = document.getElementById(input.id + "-preview") ||
                      input.closest(".form-group")?.querySelector(".file-preview");
            if (!box) {
                box = document.createElement("div");
                box.className = "file-preview";
                if (input.id) box.id = input.id + "-preview";
                input.insertAdjacentElement("afterend", box);
            }
            return box;
        }
        input.addEventListener("change", function () {
            if (esAdjuntoTicket && !actualizacionInterna && typeof DataTransfer !== "undefined") {
                var unidos = new DataTransfer();
                var nuevos = Array.from(input.files);
                seleccionAnterior.concat(nuevos).forEach(function (archivo) {
                    var repetido = Array.from(unidos.files).some(function (existente) {
                        return existente.name === archivo.name && existente.size === archivo.size && existente.lastModified === archivo.lastModified;
                    });
                    if (!repetido) unidos.items.add(archivo);
                });
                input.files = unidos.files;
            }
            if (esAdjuntoTicket) seleccionAnterior = Array.from(input.files);
            vistasTemporales.forEach(function (url) { URL.revokeObjectURL(url); });
            vistasTemporales = [];
            var box = cajaPreview();
            box.innerHTML = "";
            Array.from(input.files).slice(0, 6).forEach(function (f, idx) {
                var item = document.createElement("span");
                item.className = "file-chip";
                if (esAdjuntoTicket && /^image\/(jpeg|png|gif|webp)$/i.test(f.type)) {
                    var miniatura = document.createElement("img");
                    var url = URL.createObjectURL(f);
                    vistasTemporales.push(url);
                    miniatura.src = url;
                    miniatura.alt = "Vista previa de " + f.name;
                    miniatura.className = "file-chip-preview";
                    item.appendChild(miniatura);
                }
                var nombre = document.createElement("span");
                nombre.className = "file-chip-name";
                nombre.textContent = f.name + " (" + Math.round(f.size / 1024) + " KB)";
                item.appendChild(nombre);
                var btn = document.createElement("button");
                btn.type = "button";
                btn.className = "file-chip-x";
                btn.title = "Quitar archivo";
                btn.setAttribute("aria-label", "Quitar " + f.name);
                btn.textContent = "×";
                btn.addEventListener("click", function () {
                    var dt = new DataTransfer();
                    Array.from(input.files).forEach(function (file, i) {
                        if (i !== idx) dt.items.add(file);
                    });
                    input.files = dt.files;
                    actualizacionInterna = true;
                    input.dispatchEvent(new Event("change", { bubbles: true }));
                    actualizacionInterna = false;
                });
                item.appendChild(btn);
                box.appendChild(item);
            });
            if (input.files.length > 6) {
                var more = document.createElement("span");
                more.className = "file-chip";
                more.textContent = "+" + (input.files.length - 6) + " más…";
                box.appendChild(more);
            }
        });
    });

    /* ---- Donut de reportes: conic-gradient desde la leyenda ---- */
    document.querySelectorAll(".donut-ring[data-donut]").forEach(function (ring) {
        var wrap = ring.closest(".donut-chart-wrap");
        var total = parseInt(ring.getAttribute("data-total") || "0", 10);
        if (!wrap || !total) return;
        var grad = [];
        var acc = 0;
        wrap.querySelectorAll(".donut-legend li").forEach(function (li) {
            var dot = li.querySelector(".donut-dot");
            var countEl = li.querySelector(".donut-legend-count");
            var count = parseInt((countEl ? countEl.textContent : "") || "0", 10);
            var pct = count ? Math.round(count / total * 100) : 0;
            var color = dot ? getComputedStyle(dot).backgroundColor : "#eee";
            grad.push(color + " " + acc + "% " + (acc + pct) + "%");
            acc += pct;
        });
        if (acc < 100) grad.push("#eee " + acc + "% 100%");
        ring.style.background = "conic-gradient(" + grad.join(", ") + ")";
    });

    /* ---- Selector de rol y modal de usuario (usuarios.html) ---- */
    var selectorRolUsuario = document.getElementById("u-rol");
    function sincronizarSelectorRolUsuario() {
        if (!selectorRolUsuario) return;
        var picker = document.querySelector("[data-role-picker]");
        if (!picker) return;
        picker.dataset.selectedRole = selectorRolUsuario.value;
        var opcion = selectorRolUsuario.options[selectorRolUsuario.selectedIndex];
        var etiqueta = picker.querySelector("[data-role-label]");
        if (etiqueta) etiqueta.textContent = opcion ? opcion.textContent : "Seleccionar rol";
        picker.querySelectorAll("[data-role-option]").forEach(function (boton) {
            var seleccionado = boton.getAttribute("data-role-option") === selectorRolUsuario.value;
            boton.setAttribute("aria-selected", String(seleccionado));
            if (seleccionado) {
                var contenedorIcono = picker.querySelector("[data-role-icon]"), iconoRol = boton.querySelector(".role-icon");
                if (contenedorIcono && iconoRol) contenedorIcono.replaceChildren(iconoRol.cloneNode(true));
            }
        });
    }
    if (selectorRolUsuario) {
        selectorRolUsuario.addEventListener("change", sincronizarSelectorRolUsuario);
        document.querySelectorAll("[data-role-option]").forEach(function (boton) {
            boton.addEventListener("click", function () {
                selectorRolUsuario.value = boton.getAttribute("data-role-option");
                selectorRolUsuario.dispatchEvent(new Event("change", { bubbles: true }));
                var picker = boton.closest("[data-role-picker]");
                if (picker) picker.removeAttribute("open");
            });
        });
        sincronizarSelectorRolUsuario();
    }

    document.addEventListener("click", function (evento) {
        var btn = evento.target.closest("[data-fill-pk]");
        if (btn) {
            [
                ["pk", "value", "data-fill-pk", ""],
                ["nombre", "value", "data-fill-nombre", ""],
                ["email", "value", "data-fill-email", ""],
                ["rol", "value", "data-fill-rol", "usuario"],
                ["glpi", "value", "data-fill-glpi", ""],
                ["activo", "checked", "data-fill-activo", null],
                ["cambio-rol", "checked", "data-fill-cambio-rol", null],
                ["telefono", "value", "data-fill-telefono", ""],
                ["ubicacion", "value", "data-fill-ubicacion", ""],
                ["pass", "value", "", ""]
            ].forEach(function (spec) {
                var el = document.getElementById("u-" + spec[0]);
                if (!el) return;
                if (spec[2]) {
                    if (spec[1] === "checked") el.checked = btn.getAttribute(spec[2]) === "1";
                    else el.value = btn.getAttribute(spec[2]) || spec[3];
                } else {
                    el.value = spec[3];
                }
            });
            if (selectorRolUsuario) selectorRolUsuario.dispatchEvent(new Event("change", { bubbles: true }));
            var pass = document.getElementById("u-pass");
            if (pass) pass.placeholder = "Dejar vacía = sin cambios";
        }
    });
    document.querySelectorAll("[data-new-user]").forEach(function (btn) {
        btn.addEventListener("click", function () {
            ["pk", "nombre", "email", "glpi"].forEach(function (f) {
                var el = document.getElementById("u-" + f);
                if (el) el.value = "";
            });
            var rol = document.getElementById("u-rol");
            if (rol) rol.value = btn.getAttribute("data-default-rol") === "tecnico" ? "tecnico" : "usuario";
            if (rol) rol.dispatchEvent(new Event("change", { bubbles: true }));
            var activo = document.getElementById("u-activo");
            if (activo) activo.checked = true;
            var cambioRol = document.getElementById("u-cambio-rol");
            if (cambioRol) cambioRol.checked = false;
            var pass = document.getElementById("u-pass");
            if (pass) { pass.value = ""; pass.placeholder = "Obligatoria para cuentas nuevas"; }
        });
    });

    /* ---- Ajustes de cuenta: tabs + preview de avatar ---- */
    var TITULOS_AJUSTES = {
        perfil: "Mi perfil", password: "Contraseña", ayuda: "Ayuda y tour",
        notificaciones: "Notificaciones", glpi: "GLPI", pagina: "Página",
        atajos: "Atajos"
    };
    function tituloAjustes(name) {
        if (TITULOS_AJUSTES[name]) { document.title = "Dogger · " + TITULOS_AJUSTES[name]; }
    }
    document.querySelectorAll("[data-settings-tab]").forEach(function (tab) {
        tab.addEventListener("click", function (e) {
            e.preventDefault();
            document.querySelectorAll("[data-settings-tab]").forEach(function (t) { t.classList.remove("active"); });
            document.querySelectorAll("[data-settings-panel]").forEach(function (p) { p.classList.remove("active"); });
            tab.classList.add("active");
            var name = tab.getAttribute("data-settings-tab");
            var target = document.querySelector('[data-settings-panel="' + name + '"]');
            if (target) target.classList.add("active");
            tituloAjustes(name);
        });
    });
    function openSettingsPanel(name) {
        var destinosInternos = {"ajustes-horario-atencion": "horario-editor", "ajustes-limites-inactividad": "inactividad-editor", "ajustes-escalamiento-inactividad": "escalamiento-editor"};
        var interno = destinosInternos[name];
        if (interno) name = "pagina";
        var tab = document.querySelector('[data-settings-tab="' + name + '"]');
        var panel = document.querySelector('[data-settings-panel="' + name + '"]');
        if (!tab || !panel) return;
        document.querySelectorAll("[data-settings-tab]").forEach(function (t) { t.classList.remove("active"); });
        document.querySelectorAll("[data-settings-panel]").forEach(function (p) { p.classList.remove("active"); });
        tab.classList.add("active");
        panel.classList.add("active");
        tituloAjustes(name);
        setTimeout(function () {
            var destino = interno && document.getElementById(interno);
            if (destino) destino.scrollIntoView({ behavior: "smooth", block: "start" });
            else if (panel.getBoundingClientRect().top < 0) panel.scrollIntoView({ behavior: "smooth", block: "start" });
        }, 50);
    }
    if (location.hash && location.hash.length > 1) {
        openSettingsPanel(location.hash.slice(1));
    }
    window.addEventListener("hashchange", function () {
        if (location.hash && location.hash.length > 1) openSettingsPanel(location.hash.slice(1));
    });
    var avatarInput = document.getElementById("id_avatar");
    var avatarPreview = document.getElementById("avatar-preview");
    if (avatarInput && avatarPreview && !avatarInput.hasAttribute("data-avatar-editor")) {
        var avatarOriginal = avatarPreview.cloneNode(true);
        var avatarLectura = 0;
        avatarInput.addEventListener("change", function () {
            var file = avatarInput.files[0];
            if (!file) return;
            var lecturaActual = ++avatarLectura;
            var reader = new FileReader();
            reader.onload = function (e) {
                if (lecturaActual !== avatarLectura) return;
                if (avatarPreview.tagName === "IMG") {
                    avatarPreview.src = e.target.result;
                } else {
                    var img = document.createElement("img");
                    img.src = e.target.result;
                    img.alt = "";
                    img.className = "settings-avatar-img";
                    img.id = "avatar-preview";
                    avatarPreview.parentNode.replaceChild(img, avatarPreview);
                    avatarPreview = img;
                }
            };
            reader.readAsDataURL(file);
        });
        if (avatarInput.form) avatarInput.form.addEventListener("reset", function () {
            avatarLectura++;
            var restaurado = avatarOriginal.cloneNode(true);
            if (avatarPreview.parentNode) avatarPreview.parentNode.replaceChild(restaurado, avatarPreview);
            avatarPreview = restaurado;
        });
    }

    /* ---- Categoría inteligente: se mueve sola mientras se escribe ----
       Los pesos vienen en el JSON desde apps/tickets/sugerencia_categoria.py:
       el mismo puntaje corre en el servidor (si el usuario no elige nada) y
       aquí, para que la categoría cambie sin recargar la página. */
    var catKeywordsEl = document.getElementById("dogger-cat-keywords");
    var tituloEl = document.getElementById("id_titulo");
    var descEl = document.getElementById("id_descripcion");
    var catSelEl = document.getElementById("id_categoria");
    var suggestChip = document.getElementById("cat-suggest");
    var autoHintEl = document.getElementById("cat-auto-hint");
    var analysisPendingEl = document.getElementById("cat-analysis-pending");
    var techsEl = document.getElementById("dogger-tecnicos-disponibles");
    var autoTechsEl = document.getElementById("cat-auto-techs");
    if (catKeywordsEl && tituloEl && catSelEl && suggestChip) {
        var CAT_JSON = JSON.parse(catKeywordsEl.textContent);
        /* El último objeto trae los pesos y los umbrales; los demás son las
           categorías con sus claves. */
        var PESOS = { frase: 6, palabra: 3, suelta: 1, nombre: 3, grupo: 1, titulo: 2, excluye: 8 };
        var MED_THRESHOLD = 3, AUTO_THRESHOLD = 6, MIN_CARACTERES = 8;
        var MAX_EXCLUSIONES = 2;
        var HUECO_FRASE = 9;   // margen entre palabras de una misma frase
        CAT_JSON.forEach(function (item) {
            if (item.pesos) {
                PESOS = item.pesos;
                MED_THRESHOLD = item.umbral;
                AUTO_THRESHOLD = item.auto;
                if (item.min_caracteres) MIN_CARACTERES = item.min_caracteres;
                if (item.hueco_frase) HUECO_FRASE = item.hueco_frase;
                if (item.maximo_exclusiones) MAX_EXCLUSIONES = item.maximo_exclusiones;
            }
        });
        var CATS = CAT_JSON.filter(function (item) { return !item.pesos; });
        var URGENCIA = { urgente: 0, alta: 1, media: 2, baja: 3 };
        var autoName = document.getElementById("cat-auto-name");
        var autoMeta = document.getElementById("cat-auto-meta");
        var autoPriority = document.getElementById("cat-auto-priority");
        var autoAns = document.getElementById("cat-auto-ans");
        var autoTechName = document.getElementById("cat-auto-tech-name");
        var TECHS = techsEl ? JSON.parse(techsEl.textContent) : [];
        var autoAppliedId = "";     // categoría que puso el automatismo
        var applyingAuto = false;

        function normText(s) {
            return (s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
                .replace(/[^\w\s]+/g, " ").replace(/\s+/g, " ").trim();
        }
        /* Las categorias "Otros ..." son el ultimo recurso: no compiten con
           una categoria concreta ni ganan puntos por llamarse como el
           dominio. */
        function esComodin(cat) {
            return normText(cat.nombre).indexOf("otros ") === 0;
        }
        function escapeRx(s) {
            return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        }
        /* Una palabra suelta también encuentra plurales y terminaciones
           ("impresora" encuentra "impresoras"). Una frase admite terminaciones
           y palabras de por medio, como en el servidor, para que
           "impresora de la oficina" encuentre "impresoras de la oficina". */
        function frase(texto, k) {
            var palabras = k.split(" "), pos = 0, i, re, slice, m;
            for (i = 0; i < palabras.length; i++) {
                re = new RegExp("\\b" + escapeRx(palabras[i]) + "\\w*");
                slice = texto.slice(pos);
                m = re.exec(slice);
                if (!m) return false;
                if (pos && m.index > HUECO_FRASE) return false;
                pos += m.index + m[0].length;
            }
            return true;
        }
        function puntajeTexto(texto, cat, conNombreGrupo) {
            if (!texto) return 0;
            var score = 0, claves = cat.claves || [], i, k, j, ex;
            for (i = 0; i < claves.length; i++) {
                k = normText(claves[i]);
                if (!k) continue;
                if (k.indexOf(" ") > -1) {
                    if (frase(texto, k)) score += PESOS.frase;
                } else if (new RegExp("\\b" + escapeRx(k) + "\\w*").test(texto)) {
                    score += PESOS.palabra;
                } else if (texto.indexOf(k) > -1) {
                    score += PESOS.suelta;
                }
            }
            /* El comodin no suma por su nombre ni por su grupo: su nombre es
               el dominio entero, y decir "siesa" en el texto no dice en que
               modulo esta el problema. */
            if (conNombreGrupo === false) return score;
            var n = normText(cat.nombre), g = normText(cat.grupo);
            if (n && new RegExp("\\b" + escapeRx(n) + "\\w*").test(texto)) score += PESOS.nombre;
            if (g && new RegExp("\\b" + escapeRx(g) + "\\w*").test(texto)) score += PESOS.grupo;
            return score;
        }
        /* Contexto que descarta la categoria (por ejemplo "oficina" para las
           impresoras del POS). Cada palabra resta PESOS.excluye y el total se
           limita a MAX_EXCLUSIONES: mencionar dos modulos concretos ("pos" +
           "inventario") dice mas que mencionar uno. Se mira el texto completo,
           no campo por campo, para que el titulo no tape a la descripcion. */
        function penalizacion(texto, cat) {
            var ex = cat.excluye || [], total = 0, i, k;
            for (i = 0; i < ex.length; i++) {
                k = normText(ex[i]);
                if (k && new RegExp("\\b" + escapeRx(k) + "\\w*").test(texto)) {
                    total += PESOS.excluye;
                    if (total >= PESOS.excluye * MAX_EXCLUSIONES) {
                        return PESOS.excluye * MAX_EXCLUSIONES;
                    }
                }
            }
            return total;
        }
        function puntaje(cat) {
            var t = normText(tituloEl.value), d = normText(descEl ? descEl.value : "");
            var completo = (t + " " + d).trim();
            var conNg = !esComodin(cat);
            var score = puntajeTexto(completo, cat, conNg);
            if (t) score += PESOS.titulo * puntajeTexto(t, cat, conNg);
            return score - penalizacion(completo, cat);
        }
        /* A igual puntaje gana la más urgente y luego la de menor ANS, igual
           que en el servidor: la sugerición no baila con el orden de la base. */
        function mejorDe(candidatos) {
            var best = null, i;
            /* A igualdad de puntaje gana la categoria que nombra algo
               concreto, nunca el comodin. */
            for (i = 0; i < candidatos.length; i++) {
                var c = candidatos[i];
                if (!best || c.score > best.score) { best = c; continue; }
                if (c.score < best.score) continue;
                if (esComodin(c.cat) !== esComodin(best.cat)) {
                    if (esComodin(c.cat)) continue;
                    best = c; continue;
                }
                var cu = URGENCIA[c.cat.prioridad], bu = URGENCIA[best.cat.prioridad];
                if (cu === undefined) cu = 9;
                if (bu === undefined) bu = 9;
                if (cu < bu) { best = c; continue; }
                if (cu > bu) continue;
                var ca = c.cat.ans || 9999, ba = best.cat.ans || 9999;
                if (ca < ba) { best = c; continue; }
                if (ca === ba && c.cat.nombre < best.cat.nombre) best = c;
            }
            return best;
        }
        function hideAll() {
            suggestChip.hidden = true;
            if (autoHintEl) autoHintEl.hidden = true;
            if (autoMeta) autoMeta.hidden = true;
            if (autoTechsEl) autoTechsEl.hidden = true;
            if (analysisPendingEl) analysisPendingEl.hidden = false;
        }
        function limpiarCategoriaAutomatica() {
            /* El selector del solicitante no admite elecciones manuales. Al
               borrar el texto se elimina también el resultado anterior para
               que pegar una incidencia distinta arranque desde cero. */
            if (!catSelEl.disabled || !catSelEl.value) return;
            applyingAuto = true;
            catSelEl.value = "";
            catSelEl.classList.remove("suggest-applied");
            catSelEl.dispatchEvent(new Event("change", { bubbles: true }));
            applyingAuto = false;
            autoAppliedId = "";
        }
        function pintarAuto(cat) {
            if (autoHintEl && autoName) {
                autoName.textContent = cat.nombre + " (" + cat.grupo + ")";
                autoHintEl.hidden = false;
            }
            if (autoMeta && autoPriority && autoAns) {
                autoPriority.textContent = ({ urgente: "Urgente", alta: "Alta", media: "Media", baja: "Baja" })[cat.prioridad] || "Por definir";
                autoAns.textContent = (cat.ans || "—") + " h";
                autoMeta.classList.toggle("is-urgent", cat.prioridad === "urgente");
                autoMeta.hidden = false;
            }
            if (autoTechsEl) {
                var elegido = null;
                if (TECHS.length) {
                    var porDefecto = TECHS.filter(function (t) { return String(t.id) === String(cat.tecnico_default_id || ""); })[0];
                    if (cat.prioridad === "urgente" || cat.prioridad === "alta") {
                        var menorCarga = Math.min.apply(null, TECHS.map(function (t) { return t.carga; }));
                        var empate = TECHS.filter(function (t) { return t.carga === menorCarga; });
                        elegido = empate.filter(function (t) { return porDefecto && t.id === porDefecto.id; })[0] || empate[0];
                    } else {
                        elegido = porDefecto || TECHS[0];
                    }
                }
                document.querySelectorAll("[data-auto-tech]").forEach(function (perfil) {
                    perfil.classList.toggle("is-recommended", !!(elegido && String(perfil.getAttribute("data-auto-tech")) === String(elegido.id)));
                });
                if (autoTechName) autoTechName.textContent = elegido ? elegido.nombre : "Buscando técnico";
                autoTechsEl.hidden = false;
            }
            if (analysisPendingEl) analysisPendingEl.hidden = true;
            suggestChip.hidden = true;
        }
        function applyToSelect(pk) {
            applyingAuto = true;
            catSelEl.value = pk;
            catSelEl.classList.remove("suggest-applied");
            void catSelEl.offsetWidth;
            catSelEl.classList.add("suggest-applied");
            /* El evento change también repinta el ANS y la nota de prioridad. */
            catSelEl.dispatchEvent(new Event("change", { bubbles: true }));
            applyingAuto = false;
        }
        function evaluar() {
            var titulo = tituloEl.value, descripcion = descEl ? descEl.value : "";
            var texto = (normText(titulo) + " " + normText(descripcion)).trim();
            if (texto.length < MIN_CARACTERES) {
                limpiarCategoriaAutomatica();
                hideAll();
                return;
            }
            var candidatos = [], i;
            for (i = 0; i < CATS.length; i++) {
                var score = puntaje(CATS[i]);
                if (score > 0) candidatos.push({ cat: CATS[i], score: score });
            }
            if (!candidatos.length) {
                limpiarCategoriaAutomatica();
                hideAll();
                return;
            }
            /* El comodin es el ultimo recurso: no tapa a una categoria
               concreta que ya explica el problema (para eso la concreta tiene
               que llegar al umbral de auto). Si nada concreto puntua fuerte,
               gana la de mas puntos de todas. Espejo de
               sugerir_categoria() en apps/tickets/sugerencia_categoria.py. */
            var concretos = candidatos.filter(function (c) { return !esComodin(c.cat); });
            var mejorConcreto = 0;
            for (i = 0; i < concretos.length; i++) {
                if (concretos[i].score > mejorConcreto) mejorConcreto = concretos[i].score;
            }
            var base = mejorConcreto >= AUTO_THRESHOLD ? concretos : candidatos;
            var best = mejorDe(base);
            var actual = catSelEl.value;

            var libre = !actual || String(actual) === String(autoAppliedId);
            if (best.score >= AUTO_THRESHOLD && libre) {
                /* Coincidencia clara y el usuario no ha elegido a mano: se
                   aplica sola. Asi la categoria se corrige segun crece la
                   descripcion, sin recargar ni tocar el navegador. */
                if (String(actual) !== String(best.cat.id)) applyToSelect(best.cat.id);
                autoAppliedId = String(best.cat.id);
                pintarAuto(best.cat);
                return;
            }
            if (best.score >= MED_THRESHOLD && String(actual) !== String(best.cat.id)) {
                /* Aún no hay suficiente evidencia para asignarla. La cuenta
                   solo ve que Dogger sigue analizando; no puede modificarla. */
                if (autoHintEl) autoHintEl.hidden = true;
                if (analysisPendingEl) analysisPendingEl.hidden = true;
                suggestChip.hidden = false;
                return;
            }
            hideAll();
        }
        var suggestTimer = null;
        function evaluarPronto() {
            clearTimeout(suggestTimer);
            /* Da respuesta visual inmediata al borrar, escribir o pegar. */
            if (analysisPendingEl && (!autoHintEl || !autoHintEl.hidden)) analysisPendingEl.hidden = false;
            suggestTimer = setTimeout(evaluar, 220);
        }
        /* input cubre teclear y pegar; change/paste/drop son la red de
           seguridad para cuando el texto entra pegado o arrastrado. */
        tituloEl.addEventListener("input", evaluarPronto);
        tituloEl.addEventListener("change", evaluarPronto);
        tituloEl.addEventListener("paste", function () { setTimeout(evaluar, 40); });
        tituloEl.addEventListener("drop", function () { setTimeout(evaluar, 40); });
        tituloEl.addEventListener("blur", evaluar);
        if (descEl) {
            descEl.addEventListener("input", evaluarPronto);
            descEl.addEventListener("change", evaluarPronto);
            descEl.addEventListener("paste", function () { setTimeout(evaluar, 40); });
            descEl.addEventListener("drop", function () { setTimeout(evaluar, 40); });
            descEl.addEventListener("blur", evaluar);
        }
        catSelEl.addEventListener("change", function () {
            if (applyingAuto) return;
            /* El select está deshabilitado para solicitantes. Si el valor
               cambia por código, se vuelve a evaluar desde el texto. */
            evaluar();
        });
        evaluar();
    }

    /* ---- Resaltado ANS según la categoría seleccionada ---- */
    var ansCatsEl = document.getElementById("dogger-ans-cats");
    var ansScaleEl = document.getElementById("ans-scale");
    var ansActiveEl = document.getElementById("ans-por-categoria");
    if (ansCatsEl && ansScaleEl && catSelEl) {
        var ANS_CATS = JSON.parse(ansCatsEl.textContent);
        var ansItems = Array.prototype.slice.call(ansScaleEl.children);
        var ansPrioridadEl = document.getElementById("ans-active-prioridad");
        var ansHorasEl = document.getElementById("ans-active-horas");
        function prioridadTexto(p) {
            return { urgente: "Urgente", alta: "Alta", media: "Media", baja: "Baja" }[p] || "";
        }
        function marcarAns(pk) {
            var match = null;
            for (var i = 0; i < ANS_CATS.length; i++) {
                if (String(ANS_CATS[i].id) === String(pk)) { match = ANS_CATS[i]; break; }
            }
            for (var j = 0; j < ansItems.length; j++) {
                ansItems[j].classList.toggle("is-active", !!(match && ansItems[j].getAttribute("data-prioridad") === match.prioridad));
                ansItems[j].classList.toggle("not-active", !!(match && ansItems[j].getAttribute("data-prioridad") !== match.prioridad));
            }
            if (!match) {
                if (ansActiveEl) ansActiveEl.hidden = true;
                return;
            }
            if (ansActiveEl && ansPrioridadEl && ansHorasEl) {
                ansPrioridadEl.textContent = prioridadTexto(match.prioridad);
                ansHorasEl.textContent = (match.ans || "—") + " horas";
                ansActiveEl.hidden = false;
            }
        }
        catSelEl.addEventListener("change", function () { marcarAns(catSelEl.value); });
        if (catSelEl.value) marcarAns(catSelEl.value);
    }

    /* ---- Submenú "qué cubre cada categoría" ---- */
    function escCubre(t) {
        return String(t == null ? "" : t)
            .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
    }

    var catCubreEl = document.getElementById("cat-cubre");
    var catCubreToggle = document.getElementById("cat-cubre-toggle");
    var catCubrePanel = document.getElementById("cat-cubre-panel");
    var catCubreLista = document.getElementById("cat-cubre-lista");
    var catCubreActual = document.getElementById("cat-cubre-actual");
    var catCubreConteo = document.getElementById("cat-cubre-conteo");
    if (catCubreEl && catCubreToggle && catCubrePanel && catCubreLista && catSelEl) {
        var CAT_ITEMS = CAT_JSON.filter(function (c) { return typeof c.nombre === "string"; });

        function catPorId(pk) {
            for (var i = 0; i < CAT_ITEMS.length; i++) {
                if (String(CAT_ITEMS[i].id) === String(pk)) return CAT_ITEMS[i];
            }
            return null;
        }

        function pintarCubre() {
            var grupos = [];
            var mapa = {};
            CAT_ITEMS.forEach(function (c) {
                var g = c.grupo || "Otros";
                if (!mapa[g]) { mapa[g] = []; grupos.push(g); }
                mapa[g].push(c);
            });
            catCubreLista.innerHTML = grupos.map(function (g) {
                var items = mapa[g].map(function (c) {
                    var linea = c.cubre
                        ? '<span class="cat-cubre-linea">' + escCubre(c.cubre) + "</span>"
                        : "";
                    return '<button type="button" class="cat-cubre-item" data-cat-pick="' + escCubre(c.id) + '">' +
                        '<span class="cat-cubre-nombre">' + escCubre(c.nombre) + "</span>" + linea +
                        '<span class="cat-cubre-claves">Palabras que la detectan: ' + escCubre((c.claves || []).slice(0, 8).join(", ")) + "</span>" +
                        "</button>";
                }).join("");
                return '<div class="cat-cubre-grupo"><p class="cat-cubre-grupo-nom">' + escCubre(g) + "</p>" + items + "</div>";
            }).join("");
            marcarElegida();
        }

        function marcarElegida() {
            var elegida = catPorId(catSelEl.value);
            var items = catCubreLista.querySelectorAll(".cat-cubre-item");
            for (var i = 0; i < items.length; i++) {
                var on = elegida && items[i].getAttribute("data-cat-pick") === String(elegida.id);
                items[i].classList.toggle("is-elegida", !!on);
                items[i].setAttribute("aria-pressed", on ? "true" : "false");
            }
            if (catCubreActual) {
                if (elegida && elegida.cubre) {
                    catCubreActual.innerHTML = "<span>Elegida:</span> <strong>" + escCubre(elegida.nombre) +
                        "</strong> — " + escCubre(elegida.cubre);
                    catCubreActual.hidden = false;
                } else {
                    catCubreActual.hidden = true;
                }
            }
        }

        function abrirCubre(abrir) {
            catCubrePanel.hidden = !abrir;
            catCubreToggle.setAttribute("aria-expanded", abrir ? "true" : "false");
            catCubreEl.classList.toggle("is-abierto", abrir);
            if (abrir) marcarElegida();
        }

        pintarCubre();
        if (catCubreConteo) {
            catCubreConteo.textContent = "(" + CAT_ITEMS.length + ")";
        }
        catCubreToggle.addEventListener("click", function () {
            abrirCubre(catCubrePanel.hidden);
        });
        // El desplegable nativo se abre sobre la página, así que al enfocarlo
        // se muestra el submenú para que quede a la mano al terminar de elegir.
        catSelEl.addEventListener("focus", function () { abrirCubre(true); });
        catSelEl.addEventListener("change", function () { marcarElegida(); });
        document.addEventListener("click", function (ev) {
            if (catCubrePanel.hidden || catCubreEl.contains(ev.target)) return;
            abrirCubre(false);
        });
        document.addEventListener("keydown", function (ev) {
            if (ev.key === "Escape" && !catCubrePanel.hidden) {
                abrirCubre(false);
                catCubreToggle.focus();
            }
        });
        catCubreLista.addEventListener("click", function (ev) {
            var btn = ev.target.closest ? ev.target.closest(".cat-cubre-item") : null;
            if (!btn) return;
            catSelEl.value = btn.getAttribute("data-cat-pick");
            catSelEl.dispatchEvent(new Event("change", { bubbles: true }));
            marcarElegida();
            abrirCubre(false);
        });
    }

    /* ---- Menú de la portada (móvil): el nav de la landing se pliega ---- */
    (function () {
        var toggle = document.getElementById("ln-toggle");
        var links = document.getElementById("ln-links");
        if (!toggle || !links) return;

        function abrir(abrir) {
            links.classList.toggle("is-open", abrir);
            toggle.setAttribute("aria-expanded", abrir ? "true" : "false");
            toggle.setAttribute("aria-label", abrir ? "Ocultar el menú de la página" : "Ver el menú de la página");
        }
        function estaAbierto() { return links.classList.contains("is-open"); }
        abrir(window.matchMedia("(min-width: 981px)").matches);

        toggle.addEventListener("click", function () {
            abrir(!estaAbierto());
        });
        links.addEventListener("click", function (ev) {
            if (ev.target.closest("a")) abrir(false);
        });
        document.addEventListener("keydown", function (ev) {
            if (ev.key === "Escape" && estaAbierto()) { abrir(false); toggle.focus(); }
        });
        document.addEventListener("click", function (ev) {
            if (!estaAbierto()) return;
            if (!ev.target.closest(".landing-nav")) abrir(false);
        });
    })();

    /* ---- Preguntas frecuentes: "ver todas" despliega en la misma página ---- */
    var faqBoton = document.getElementById("faq-ver-mas");
    var faqExtra = document.getElementById("faq-extra");
    var faqTexto = document.getElementById("faq-ver-mas-txt");
    if (faqBoton && faqExtra) {
        faqBoton.addEventListener("click", function () {
            var abierto = faqExtra.hasAttribute("hidden");
            if (abierto) {
                faqExtra.removeAttribute("hidden");
            } else {
                faqExtra.setAttribute("hidden", "");
            }
            faqBoton.setAttribute("aria-expanded", abierto ? "true" : "false");
            if (faqTexto) faqTexto.textContent = abierto ? "Ocultar las demás preguntas" : "Ver todas las preguntas frecuentes";
            if (abierto) {
                faqExtra.scrollIntoView({ behavior: "smooth", block: "nearest" });
            }
        });
    }

    /* ---- Espacio para escribir una pregunta: se envía por correo ---- */
    var formPregunta = document.getElementById("lp-pregunta-form");
    if (formPregunta) {
        var aviso = document.getElementById("lp-pregunta-aviso");
        formPregunta.addEventListener("submit", function (ev) {
            ev.preventDefault();
            var nombre = document.getElementById("pq-nombre");
            var correo = document.getElementById("pq-correo");
            var texto = document.getElementById("pq-texto");
            if (!texto.value.trim() || !nombre.value.trim()) {
                if (aviso) aviso.textContent = "Escribe tu nombre y tu pregunta para poder enviar el mensaje.";
                (!texto.value.trim() ? texto : nombre).focus();
                return;
            }
            if (aviso) aviso.textContent = "";
            var cuerpo = "Pregunta enviada desde el portal\n\n" +
                "Nombre: " + nombre.value.trim() + "\n" +
                "Correo: " + (correo && correo.value.trim() ? correo.value.trim() : "no informado") + "\n\n" +
                texto.value.trim();
            var correoSoporte = formPregunta.getAttribute("data-correo") || "";
            window.location.href = "mailto:" + correoSoporte +
                "?subject=" + encodeURIComponent("Pregunta desde el portal - " + nombre.value.trim()) +
                "&body=" + encodeURIComponent(cuerpo);
            texto.value = "";
            if (aviso) aviso.textContent = "Abrimos tu programa de correo con la pregunta lista para enviar.";
        });
    }
})();

/* =====================================================================
   Campana de notificaciones: abrir la lista, marcar leídas, quitar con la
   "x", refresco automático y ventanas emergentes encadenadas.
   ===================================================================== */
(function () {
    var wrap = document.getElementById("notifWrap");
    var bell = document.getElementById("notifBell");
    var panel = document.getElementById("notifPanel");
    var URL_API = (wrap && wrap.getAttribute("data-url-api")) || "";

    function csrf() {
        // El token llega en un <meta> en la cabecera y tambien en un input
        // oculto de cada formulario. Hay que mirar los dos: si se busca solo
        // por atributo, el <meta> gana y .value viene vacio (403 en el POST).
        var meta = document.querySelector("meta[name=csrfmiddlewaretoken]");
        if (meta && meta.content) { return meta.content; }
        var input = document.querySelector("input[name=csrfmiddlewaretoken]");
        if (input && input.value) { return input.value; }
        var m = document.cookie.match(/(^|;\s*)csrftoken=([^;]+)/);
        return m ? m[2] : "";
    }

    function pedir(destino) {
        if (!destino) { return; }
        try {
            fetch(destino, {
                method: "POST",
                headers: {
                    "X-CSRFToken": csrf(),
                    "X-Requested-With": "XMLHttpRequest"
                },
                credentials: "same-origin",
                keepalive: true
            }).then(function (r) {
                return r.ok ? r.json() : null;
            }).then(function (data) {
                if (data && typeof data.pendientes === "number") {
                    pintarContador(data.pendientes);
                }
            }).catch(function () { });
        } catch (e) { }
    }

    function pintarContador(pendientes) {
        var badge = document.getElementById("notifBadge");
        if (!badge || typeof pendientes !== "number") { return; }
        badge.textContent = pendientes > 99 ? "99+" : pendientes;
        badge.classList.toggle("is-empty", pendientes === 0);
        if (bell) {
            var oculto = document.querySelector(".visually-hidden", bell);
            if (oculto) {
                oculto.textContent = pendientes
                    ? "Notificaciones: " + pendientes + " sin leer"
                    : "Notificaciones";
            }
        }
    }

    /* ---- Aviso breve en la esquina ----
       Sale cuando llega algo nuevo, sin bloquear y se va solo. Es el mismo
       sitio donde aparecen los mensajes del sistema. */
    function toastAviso(n) {
        var pila = document.querySelector(".toast-stack");
        if (!pila) { return; }
        var url = n.url || "#";
        var el = document.createElement("div");
        el.className = "toast toast-notif";
        el.innerHTML =
            '<span class="notif-icon notif-icon-' + esc(n.tipo) + '" aria-hidden="true">' +
            '<svg class="icon icon-sm"><use href="#' + esc(n.icono || "i-bell") + '"/></svg></span>' +
            '<div class="toast-body">' +
            '<strong>' + esc(n.titulo) + '</strong>' +
            '<span>' + esc(n.mensaje || "") + '</span>' +
            (n.actor ? '<small class="toast-actor">por ' + esc(n.actor) +
                (n.actor_rol ? " · " + esc(n.actor_rol) : "") + "</small>" : "") +
            '<a href="' + esc(url) + '">Ver</a>' +
            '</div>' +
            '<button type="button" class="toast-close" aria-label="Cerrar">&times;</button>';
        pila.appendChild(el);

        // Al hacer clic en "Ver" se marca como mostrada, como la emergente.
        el.querySelector("a").addEventListener("click", function () {
            pedir(baseDe("data-url-leer", n.id));
        });
        // Mismo auto-cierre con pausa al pasar el mouse que los toasts del servidor.
        var delay = 7000;
        el.style.setProperty("--toast-delay", delay + "ms");
        var timer = null, started = Date.now(), remaining = delay;
        function dismiss() {
            if (!el.isConnected) { return; }
            el.classList.add("toast-out");
            setTimeout(function () { el.remove(); }, 340);
        }
        function schedule() {
            if (timer) { clearTimeout(timer); timer = null; }
            timer = setTimeout(dismiss, remaining);
        }
        var btn = el.querySelector(".toast-close");
        if (btn) { btn.addEventListener("click", dismiss); }
        el.addEventListener("mouseenter", function () {
            remaining -= Date.now() - started;
            if (timer) { clearTimeout(timer); timer = null; }
        });
        el.addEventListener("mouseleave", function () {
            if (remaining <= 0) { return; }
            started = Date.now();
            schedule();
        });
        schedule();
    }

    function vacioHTML() {
        return '<li class="notif-empty">' +
            '<span class="notif-empty-icon"><svg class="icon"><use href="#i-check-circle"/></svg></span>' +
            '<strong>No tienes avisos</strong>' +
            '<span>Aquí verás tus tickets activos, tareas y recordatorios.</span>' +
            '</li>';
    }

    function baseDe(atributo, id) {
        var base = wrap.getAttribute(atributo) || "";
        return id ? base.replace("/0/", "/" + id + "/") : base;
    }

    function esc(t) {
        return String(t == null ? "" : t)
            .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
    }

    /* ---- Ventanas emergentes: se acumulan y salen de una en una ---- */
    var colaEmergente = [];
    var emergenteViva = false;

    function filaHTML(n) {
        return '<li class="notif-row' + (n.nueva ? " is-new" : "") + '" data-id="' + esc(n.id) + '">' +
            '<span class="notif-icon notif-icon-' + esc(n.tipo) + '" aria-hidden="true">' +
            '<svg class="icon icon-sm"><use href="#' + esc(n.icono || "i-bell") + '"/></svg>' +
            '</span>' +
            '<span class="notif-text">' +
            '<a class="notif-link" href="' + esc(n.url || "#") + '">' + esc(n.titulo) + '</a>' +
            '<span class="notif-msg">' + esc(n.mensaje) + '</span>' +
            '<small class="notif-time">' +
            (n.actor ? "por " + esc(n.actor) +
                (n.actor_rol ? " · " + esc(n.actor_rol) : "") + " · " : "") +
            esc(n.fecha || "ahora mismo") + '</small>' +
            '</span>' +
            '<button type="button" class="notif-x" data-notif-quitar="' + esc(n.id) + '" ' +
            'aria-label="Quitar notificación" title="Quitar">&times;</button>' +
            '</li>';
    }

    function mostrarEmergenteSiguiente() {
        if (emergenteViva || document.getElementById("notifPopup") || !colaEmergente.length) { return; }
        var n = colaEmergente.shift();
        emergenteViva = true;
        var dlg = document.createElement("dialog");
        dlg.className = "notif-popup notif-popup-viva notif-popup-" + esc(n.tipo);
        dlg.setAttribute("data-id", n.id);
        dlg.setAttribute("aria-labelledby", "notifPopVivaTitulo");
        dlg.innerHTML =
            '<form method="dialog" class="notif-popup-form">' +
            '<button type="submit" class="notif-popup-x" aria-label="Cerrar">&times;</button>' +
            '<span class="notif-popup-head">' +
            '<span class="notif-popup-icon" aria-hidden="true">' +
            '<svg class="icon"><use href="#' + esc(n.icono || "i-bell") + '"/></svg></span>' +
            '<span class="notif-popup-kicker">Notificación</span>' +
            '<h3 class="notif-popup-title" id="notifPopVivaTitulo">' + esc(n.titulo) + '</h3>' +
            '</span>' +
            '<p class="notif-popup-text">' + esc(n.mensaje) + '</p>' +
            (n.actor ? '<p class="notif-popup-actor">por ' + esc(n.actor) +
                (n.actor_rol ? " · " + esc(n.actor_rol) : "") + "</p>" : "") +
            '<div class="notif-popup-actions">' +
            (n.url
                ? '<a class="btn btn-accent notif-popup-ver" href="' + esc(n.url) + '" data-notif-cerrar>' +
                  'Ver <svg class="icon icon-sm"><use href="#i-arrow-right"/></svg></a>'
                : "") +
            '<button type="submit" class="btn notif-popup-ok" data-notif-cerrar>Cerrar</button>' +
            '</div>' +
            (colaEmergente.length
                ? '<small class="notif-popup-foot notif-popup-faltan">Quedan ' +
                  colaEmergente.length + ' aviso' + (colaEmergente.length === 1 ? "" : "s") +
                  ' más.</small>'
                : '<small class="notif-popup-foot">También lo verás en la campana de notificaciones.</small>') +
            '</form>';
        document.body.appendChild(dlg);
        dlg.showModal();
        /* Escape y el boton X cierran solos (form method="dialog"). Al dispararse
           el evento "close" se marca el aviso como visto y sigue la cola. */
        dlg.addEventListener("close", function () { cerrarEmergenteViva(dlg); });
        dlg.addEventListener("click", function (ev) {
            if (ev.target === dlg) { dlg.close(); }
        });
        dlg.querySelectorAll("a").forEach(function (a) {
            a.addEventListener("click", function () { pedir(baseDe("data-url-leer", n.id)); });
        });
    }

    function cerrarEmergenteViva(dlg) {
        var id = dlg.getAttribute("data-id");
        dlg.remove();
        emergenteViva = false;
        if (wrap) { pedir(baseDe("data-url-mostrada", id)); }
        // La siguiente emerge enseguida: así no se encadenan encima.
        setTimeout(mostrarEmergenteSiguiente, 450);
    }

    /* ---- Refresco automático: el estado se consulta solo ---- */
    function refrescar() {
        if (!URL_API || document.hidden) { return; }
        fetch(URL_API, {
            headers: { "X-Requested-With": "XMLHttpRequest" },
            credentials: "same-origin",
            cache: "no-store"
        }).then(function (r) { return r.ok ? r.json() : null; }).then(function (data) {
            if (!data || !data.ok) { return; }
            pintarContador(data.no_leidas);

            // 1) Los avisos nuevos se apilan en la lista de la campana.
            if (panel && Array.isArray(data.avisos)) {
                var lista = panel.querySelector(".notif-list");
                if (lista) {
                    lista.innerHTML = data.avisos.length ? data.avisos.map(filaHTML).join("") : vacioHTML();
                }
            }

            // 2) Las emergentes se acumulan y salen una detrás de otra.
            if (Array.isArray(data.emergentes) && data.emergentes.length) {
                var yaEnCola = {};
                colaEmergente.forEach(function (n) { yaEnCola[n.id] = true; });
                var actual = document.querySelector(".notif-popup-viva");
                if (actual) { yaEnCola[actual.getAttribute("data-id")] = true; }
                // La emergente inicial viene ya pintada por el servidor: si
                // sigue en pantalla no se vuelve a encolar la misma.
                var inicial = document.getElementById("notifPopup");
                if (inicial && inicial.getAttribute("data-id")) {
                    yaEnCola[inicial.getAttribute("data-id")] = true;
                }
                data.emergentes.forEach(function (n) {
                    if (!yaEnCola[n.id]) {
                        colaEmergente.push(n);
                        // Aviso breve en la esquina.
                        toastAviso(n);
                    }
                });
                mostrarEmergenteSiguiente();
            }
        }).catch(function () { });
    }

    /* ---- Latido: avisa que esta pestaña sigue viva ---- */
    function latido() {
        var url = document.body.getAttribute("data-url-latido");
        if (!url || document.hidden) { return; }
        fetch(url, {
            method: "POST",
            headers: { "X-CSRFToken": csrf(), "X-Requested-With": "XMLHttpRequest" },
            credentials: "same-origin",
            cache: "no-store"
        }).catch(function () { });
    }

    if (wrap && bell && panel) {
        function abrir() {
            panel.classList.add("open");
            bell.setAttribute("aria-expanded", "true");
            refrescar();
        }

        function cerrar() {
            panel.classList.remove("open");
            bell.setAttribute("aria-expanded", "false");
        }

        bell.addEventListener("click", function (ev) {
            ev.stopPropagation();
            if (panel.classList.contains("open")) { cerrar(); } else { abrir(); }
        });
        document.addEventListener("click", function (ev) {
            if (!wrap.contains(ev.target)) { cerrar(); }
        });
        document.addEventListener("keydown", function (ev) {
            if (ev.key === "Escape") { cerrar(); }
        });

        panel.addEventListener("click", function (ev) {
            var enlaceAviso = ev.target.closest(".notif-link");
            if (enlaceAviso) {
                var filaAviso = enlaceAviso.closest(".notif-row");
                if (filaAviso && enlaceAviso.getAttribute("href") !== "#") {
                    pedir(baseDe("data-url-leer", filaAviso.getAttribute("data-id")));
                }
                return;
            }
            var quitar = ev.target.closest("[data-notif-quitar]");
            if (quitar) {
                ev.preventDefault();
                ev.stopPropagation();
                var fila = quitar.closest(".notif-row");
                var id = quitar.getAttribute("data-notif-quitar");
                if (fila) { fila.remove(); }
                pedir(baseDe("data-url-descartar", id));
                if (!panel.querySelector(".notif-row")) {
                    var lista = panel.querySelector(".notif-list");
                    if (lista && !lista.querySelector(".notif-empty")) {
                        lista.innerHTML = vacioHTML();
                    }
                }
                refrescar();
                return;
            }
            var accion = ev.target.closest("[data-notif]");
            if (!accion) { return; }
            ev.stopPropagation();
            var tipo = accion.getAttribute("data-notif");
            if (tipo === "leer-todas") {
                colaEmergente = [];
                pedir(baseDe("data-url-todas"));
                Array.prototype.forEach.call(
                    panel.querySelectorAll(".notif-row"), function (f) { f.classList.remove("is-new"); }
                );
            } else if (tipo === "limpiar") {
                pedir(baseDe("data-url-limpiar"));
                var lista2 = panel.querySelector(".notif-list");
                if (lista2) { lista2.innerHTML = vacioHTML(); }
                colaEmergente = [];
            }
        });
    }

    /* ---- Ventana emergente inicial (la que trae la página) ---- */
    var popup = document.getElementById("notifPopup");
    if (popup) {
        /* Se abre con showModal() para que Escape y el boton X la cierren sin
           ayuda del JS. Si showModal no existiera, el <dialog> sigue cerrado
           y no se puede quedar bloqueando la pagina. */
        if (typeof popup.showModal === "function" && !popup.open) {
            try { popup.showModal(); } catch (e) { popup.setAttribute("open", ""); }
        }
        popup.addEventListener("close", function () {
            var id = popup.getAttribute("data-id");
            popup.remove();
            if (wrap) { pedir(baseDe("data-url-mostrada", id)); }
            setTimeout(mostrarEmergenteSiguiente, 450);
        });
        popup.addEventListener("click", function (ev) {
            if (ev.target === popup) { popup.close(); }
        });
        /* "Ver" y "OK" cierran al instante y marcan el aviso como visto, igual
           que la emergente viva: aunque la navegación tarde o vaya a la misma
           página, el aviso no se queda pegado ni vuelve a saltar. El enlace
           sigue navegando normal: aquí no se cancela el clic. */
        popup.querySelectorAll("[data-notif-cerrar]").forEach(function (el) {
            el.addEventListener("click", function () {
                var id = popup.getAttribute("data-id");
                if (wrap && el.tagName === "A") { pedir(baseDe("data-url-leer", id)); }
                try { popup.close(); } catch (e) { /* ya estaba cerrada */ }
            });
        });
    }


    /* ---- Tablas con scroll: exactamente N filas a la vista ----
       Cada tabla se ve densa, asi que una altura fija deja 4 filas en una y
       8 en otra. Se mide la fila real y se limita el alto a la del encabezado
       mas N filas: siempre se ven las mismas N, ni mas ni menos. */
    function ajustarFilas(wrap) {
        var tabla = wrap.querySelector("table");
        if (!tabla) return;
        var thead = wrap.querySelector("thead");
        var filas = wrap.querySelectorAll("tbody tr");
        if (!filas.length) { wrap.style.removeProperty("--alto-filas"); return; }
        var n = parseInt(wrap.getAttribute("data-filas"), 10) || 6;
        // Se promedian las primeras n filas para que una fila alta
        // no empuje la altura de toda la tabla.
        var muestra = Array.prototype.slice.call(filas, 0, n);
        var suma = 0;
        muestra.forEach(function (f) { suma += f.offsetHeight; });
        var alto = (suma / muestra.length) * n + (thead ? thead.offsetHeight : 0);
        wrap.style.setProperty("--alto-filas", Math.ceil(alto) + "px");
    }

    function ajustarTablas() {
        var wraps = document.querySelectorAll("[data-filas]");
        wraps.forEach(ajustarFilas);
        // Se vuelve a medir cuando cambian las filas: al abrir la ficha de un
        // usuario se inserta una fila y el alto volveria a quedar corto.
        wraps.forEach(function (wrap) {
            var cuerpo = wrap.querySelector("tbody");
            if (!cuerpo || cuerpo.dataset.observado) return;
            cuerpo.dataset.observado = "1";
            new MutationObserver(function () {
                clearTimeout(cuerpo._t);
                cuerpo._t = setTimeout(ajustarFilas, 80);
            }).observe(cuerpo, { childList: true });
        });
    }
    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", ajustarTablas);
    } else {
        ajustarTablas();
    }
    window.addEventListener("load", ajustarTablas);
    var pending;
    window.addEventListener("resize", function () {
        clearTimeout(pending);
        pending = setTimeout(ajustarTablas, 150);
    });

    /* ---- Arranque del refresco automático ---- */
    if (URL_API) {
        // Al entrar, lo que ya se está viendo pasa a leído: el contador se
        // queda en 0 en vez de quedar activo hasta que alguien abra la campana.
        // Los avisos siguen en la lista, solo dejan de contar como pendientes.
        pedir(baseDe("data-url-todas"));
        // El intervalo es corto para que el contador no se sienta viejo.
        setInterval(refrescar, 12000);
        // Al volver a la pestaña se consulta de inmediato.
        document.addEventListener("visibilitychange", function () {
            if (!document.hidden) { refrescar(); }
        });
    }
    if (document.body.getAttribute("data-url-latido")) {
        // Un latido al entrar para que el punto quede verde de inmediato, y
        // otro cada 2 minutos mientras la pestaña siga abierta.
        latido();
        setInterval(latido, 120000);
        document.addEventListener("visibilitychange", function () {
            if (!document.hidden) { latido(); }
        });
    }
})();


/* ---- Cronómetro del ANS, en vivo y en todas las vistas ----
   Cada etiqueta trae la hora de vencimiento y la de "por vencer" en segundos
   epoch (las puso el servidor con la misma regla para todos), así que aquí solo
   hay que restar. Al vencerse, la etiqueta cambia sola a rojo y avisa con el
   icono de alerta, sin recargar nada. */
(function () {
    "use strict";

    /* El cronómetro es el icono del ANS que corre: solo cambia a alerta cuando
       el ticket ya venció. */
    var ICONO = { ok: "#i-stopwatch", "por-vencer": "#i-stopwatch", vencido: "#i-alert" };
    /* Las vistas usan dos prefijos para el mismo color: la etiqueta general
       (ans-ok) y la tarjeta del técnico (tec-ans-ok). Se respeta el que ya
       traiga el elemento para no inventar una clase que no existe en el CSS. */
    var PREFIJOS = ["ans-", "tec-ans-"];

    /* Mismo formato que formatear_duracion() del servidor, para que el texto
       no cambie de forma al recargar: "1d 2h", "1h 30min", "45min". Bajo el
       minuto, donde el servidor solo dice "menos de 1min", se muestran los
       segundos: es justo cuando el reloj tiene sentido. */
    function duracion(seg) {
        var abs = Math.abs(seg);
        var d = Math.floor(abs / 86400);
        var h = Math.floor((abs % 86400) / 3600);
        var m = Math.floor((abs % 3600) / 60);
        var s = Math.floor(abs % 60);
        // La cuenta se actualiza cada segundo; mostrar segundos en todos los
        // rangos hace visible el tiempo exacto que falta antes del vencimiento.
        if (d > 0) return d + "d " + h + "h " + m + "min " + s + "s";
        if (h > 0) return h + "h " + m + "min " + s + "s";
        return m + "min " + s + "s";
    }

    /* El texto vive en un <span data-ans-txt>; si no lo hay (algunas vistas
       traen la etiqueta sin ese hijo) se escribe sobre el elemento completo. */
    function textoDe(el) {
        return el.querySelector("[data-ans-txt]") || el;
    }

    function pintar(el, ahora) {
        if (!el.isConnected) return false;
        var limite = parseInt(el.getAttribute("data-ans-limit"), 10);
        if (!limite) return false;
        var dif = Math.round(limite - ahora);
        var estado;
        if (dif <= 0) {
            estado = "vencido";
        } else {
            var aviso = parseInt(el.getAttribute("data-ans-aviso"), 10);
            estado = (aviso && ahora >= aviso) ? "por-vencer" : "ok";
        }
        var destino = textoDe(el);
        /* Al alcanzar el límite no se muestra tiempo transcurrido: el ANS ya
           venció y la etiqueta queda congelada en ese estado. */
        var nuevo = estado === "vencido" ? "Vencido" : "Faltan " + duracion(dif);
        if (destino.textContent !== nuevo) destino.textContent = nuevo;

        if (el.classList.contains("ans-ok") || el.classList.contains("ans-por-vencer")
            || el.classList.contains("ans-vencido") || el.classList.contains("tec-ans-ok")
            || el.classList.contains("tec-ans-por-vencer") || el.classList.contains("tec-ans-vencido")) {
            var base = "";
            PREFIJOS.forEach(function (p) {
                if (el.classList.contains(p + "ok") || el.classList.contains(p + "por-vencer")
                    || el.classList.contains(p + "vencido")) {
                    base = p;
                }
            });
            PREFIJOS.forEach(function (p) {
                el.classList.remove(p + "ok");
                el.classList.remove(p + "por-vencer");
                el.classList.remove(p + "vencido");
            });
            el.classList.add(base + estado);
        }
        var use = el.querySelector("use");
        var icono = ICONO[estado];
        if (use && icono && use.getAttribute("href") !== icono) {
            use.setAttribute("href", icono);
        }
        if (estado === "vencido") {
            /* No vuelve a entrar al intervalo global ni continúa contando. */
            el.removeAttribute("data-ans-live");
        }
        return true;
    }

    function correr() {
        var ahora = Date.now() / 1000;
        var els = document.querySelectorAll("[data-ans-live][data-ans-limit]");
        for (var i = 0; i < els.length; i++) {
            pintar(els[i], ahora);
        }
    }

    function iniciar() {
        if (!document.querySelector("[data-ans-live][data-ans-limit]")) return;
        correr();
        setInterval(correr, 1000);
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", iniciar);
    } else {
        iniciar();
    }
    /* Las listas que se refrescan solas meten filas nuevas con el reloj ya
       corriendo: como cada tick vuelve a buscar en el documento, las cuenta
       sin necesidad de que nadie avise. Al volver a la pestaña se repinta. */
    window.addEventListener("focus", correr);
})();

/* ------------------------------------------------------------------
   Ventana del ANS
   La etiqueta del cronómetro se puede pulsar para que explique qué
   significa: qué es el ANS, qué plazo le corre a ese ticket, quién
   responde y qué significa cada color.

   Solo actúa en las páginas que incluyen `_ans_modal.html`: donde no
   está, las etiquetas siguen siendo texto y este código no hace nada.
   El texto del reloj se copia de la etiqueta, que es la que sigue
   corriendo de verdad, así la ventana nunca se contradice con la fila.
   ------------------------------------------------------------------ */
(function () {
    "use strict";
    var modal = document.getElementById("ansModal");
    if (!modal) return;
    var ESTADOS = ["ans-ok", "ans-por-vencer", "ans-vencido"];
    var abierto = null;

    function escribe(id, valor) {
        var el = document.getElementById(id);
        if (el) el.textContent = (valor && valor !== "") ? valor : "—";
    }

    function estadoDe(etiqueta) {
        for (var i = 0; i < ESTADOS.length; i++) {
            if (etiqueta.classList.contains(ESTADOS[i])) return ESTADOS[i];
        }
        return "ans-ok";
    }

    function abre(etiqueta) {
        var reloj = document.getElementById("ansModalReloj");
        var estado = estadoDe(etiqueta);
        if (reloj) {
            ESTADOS.forEach(function (c) { reloj.classList.remove(c); });
            reloj.classList.add(estado);
        }
        var use = modal.querySelector(".ans-modal-reloj-ico use");
        if (use) {
            use.setAttribute("href", estado === "ans-vencido" ? "#i-alert" : "#i-stopwatch");
        }

        var horas = etiqueta.getAttribute("data-ans-horas");
        var limite = etiqueta.getAttribute("title") || "";

        escribe("ansModalCodigo", etiqueta.getAttribute("data-ans-codigo"));
        escribe("ansModalAsunto", etiqueta.getAttribute("data-ans-titulo"));
        escribe("ansModalDatoTicket", etiqueta.getAttribute("data-ans-codigo"));
        escribe("ansModalDatoPrioridad", etiqueta.getAttribute("data-ans-prioridad"));
        escribe("ansModalDatoHoras", horas ? horas + " horas" : "—");
        escribe("ansModalDatoTecnico", etiqueta.getAttribute("data-ans-tecnico"));
        /* El detalle que pintaba el servidor tiene la forma
           "Límite 12/05 09:30 · ANS 2h · Urgente": solo se muestra la primera
           pieza, el resto ya está en la tabla. */
        escribe("ansModalDatoLimite", limite.split(" · ")[0].replace("Límite ", ""));

        var hijo = etiqueta.querySelector("[data-ans-txt]");
        escribe("ansModalRelojTxt", hijo ? hijo.textContent : etiqueta.textContent);

        var enlace = document.getElementById("ansModalEnlace");
        var url = etiqueta.getAttribute("data-ans-url") || "";
        if (enlace) {
            enlace.setAttribute("href", url || "#");
            enlace.hidden = !url;
        }

        abierto = etiqueta;
        modal.hidden = false;
        var boton = modal.querySelector("[data-ans-cerrar]");
        if (boton) boton.focus();
    }

    function cierra() {
        modal.hidden = true;
        if (abierto && abierto.focus) abierto.focus();
        abierto = null;
    }

    document.addEventListener("click", function (ev) {
        var origen = ev.target;
        if (!origen || !origen.closest) return;
        var etiqueta = origen.closest("[data-ans-info]");
        if (etiqueta) {
            ev.preventDefault();
            abre(etiqueta);
            return;
        }
        if (origen.closest("[data-ans-cerrar]")) {
            ev.preventDefault();
            cierra();
            return;
        }
        if (!modal.hidden && origen === modal) cierra();
    });

    document.addEventListener("keydown", function (ev) {
        if (modal.hidden) return;
        if (ev.key === "Escape") {
            ev.preventDefault();
            cierra();
            return;
        }
        if (ev.key !== "Enter" && ev.key !== " ") return;
        var foco = document.activeElement;
        if (foco && foco.hasAttribute && foco.hasAttribute("data-ans-info")) {
            ev.preventDefault();
            abre(foco);
        }
    });
})();

/* =====================================================================
   DOGGER HELPDESK — PALETA DE COLOR DE LAS CARPETAS DEL OBSERVADOR
   =====================================================================
   Cada tarjeta de zona (Mi lista, Monitoreo y Zonas) lleva una gota en su
   esquina inferior derecha: al pulsarla se despliega la paleta con los
   diez colores cerrados del servidor más «sin color». Elegir uno manda el
   formulario y se vuelve a la misma página con la carpeta pintada. Se
   cierra sola al pulsar fuera o con Esc.
   ===================================================================== */
(function () {
    "use strict";

    function cerrarPaletas(excepto) {
        var abiertas = document.querySelectorAll(".obs-paleta:not([hidden])");
        Array.prototype.forEach.call(abiertas, function (caja) {
            if (excepto && caja.id === excepto) return;
            caja.hidden = true;
            var btn = document.querySelector('[data-paleta="' + caja.id + '"]');
            if (btn) btn.setAttribute("aria-expanded", "false");
        });
    }

    document.addEventListener("click", function (ev) {
        var origen = ev.target;
        if (!origen || !origen.closest) return;
        var dentro = origen.closest(".obs-paleta");
        if (dentro) return;          /* un color: se manda su formulario */
        var btn = origen.closest("[data-paleta]");
        if (!btn) { cerrarPaletas(); return; }
        var caja = document.getElementById(btn.getAttribute("data-paleta"));
        if (!caja) return;
        var abrir = caja.hidden;
        cerrarPaletas(abrir ? caja.id : null);
        caja.hidden = !abrir;
        btn.setAttribute("aria-expanded", String(abrir));
    });

    document.addEventListener("keydown", function (ev) {
        if (ev.key === "Escape") cerrarPaletas();
    });

    /* ---- Precargador de página completa ----
       Al navegar a otra página (enlace interno o envío de formulario) se
       tapa la pantalla con un giro hasta que la nueva página pinta. Nunca
       deja la interfaz bloqueada: se oculta al cargar y, por si acaso, con
       un tope de tiempo. */
    (function () {
        var loader = document.getElementById("pageLoader");
        if (!loader) { return; }
        var loaderTitle = document.getElementById("pageLoaderTitle");
        var loaderText = document.getElementById("pageLoaderText");
        var loaderIconUse = document.getElementById("pageLoaderIconUse");
        var mostrarTimer = null;
        var ocultarTimer = null;
        var estadoTimer = null;
        var mostrando = false;
        var proximoEstado = {
            titulo: "Cargando información",
            texto: "Preparando la información solicitada…",
            lento: "Seguimos preparando la información…",
            icono: "refresh",
            tono: "default"
        };

        function definirEstado(titulo, texto, opciones) {
            opciones = opciones || {};
            proximoEstado = {
                titulo: titulo || "Cargando información",
                texto: texto || "Preparando la información solicitada…",
                lento: opciones.lento || "Seguimos preparando la información…",
                icono: opciones.icono || "refresh",
                tono: opciones.tono || "default"
            };
        }

        function mostrar() {
            if (mostrando) { return; }
            mostrando = true;
            if (loaderTitle) { loaderTitle.textContent = proximoEstado.titulo; }
            if (loaderText) { loaderText.textContent = proximoEstado.texto; }
            if (loaderIconUse) { loaderIconUse.setAttribute("href", "#i-" + proximoEstado.icono); }
            loader.setAttribute("data-loader-tone", proximoEstado.tono);
            loader.hidden = false;
            clearTimeout(estadoTimer);
            estadoTimer = setTimeout(function () {
                if (mostrando && loaderText) {
                    loaderText.textContent = proximoEstado.lento;
                }
            }, 2200);
            /* Red de seguridad: aunque la navegación no llegue a completarse
               (descarga abortada, etc.), el precargador no se queda pegado. */
            clearTimeout(ocultarTimer);
            ocultarTimer = setTimeout(ocultar, 6000);
        }
        function ocultar() {
            mostrando = false;
            loader.hidden = true;
            clearTimeout(mostrarTimer);
            clearTimeout(ocultarTimer);
            clearTimeout(estadoTimer);
        }
        /* Se espera un pelín antes de mostrarlo para no parpadear cuando la
           navegación es instantánea. */
        function programar(titulo, texto, opciones) {
            clearTimeout(mostrarTimer);
            definirEstado(titulo, texto, opciones);
            mostrarTimer = setTimeout(mostrar, 140);
        }
        function cancelarProgramado() { clearTimeout(mostrarTimer); }

        function estadoPorRuta(pathname, etiqueta) {
            var ruta = (pathname || "").toLowerCase();
            if (/reportes/.test(ruta)) return { titulo: "Cargando reportes", texto: "Actualizando indicadores y gráficos con datos reales…", icono: "chart", tono: "reports", lento: "Los indicadores siguen actualizándose…" };
            if (/programador|calendario/.test(ruta)) return { titulo: "Abriendo programador", texto: "Preparando el calendario y tus eventos…", icono: "calendar", lento: "El calendario sigue sincronizándose…" };
            if (/categor/.test(ruta)) return { titulo: "Cargando categorías", texto: "Preparando las opciones para tu solicitud…", icono: "folder", lento: "Las categorías siguen cargándose…" };
            if (/mi-panel/.test(ruta)) return { titulo: "Cargando mi panel", texto: "Actualizando tus solicitudes y actividad reciente…", icono: "layers", lento: "Tu panel sigue actualizándose…" };
            if (/panel.*tecnico|tecnico/.test(ruta)) return { titulo: "Cargando panel técnico", texto: "Actualizando los tickets asignados…", icono: "wrench", lento: "El panel técnico sigue actualizándose…" };
            if (/tickets/.test(ruta)) return { titulo: "Cargando tickets", texto: "Preparando las solicitudes registradas…", icono: "ticket", lento: "Los tickets siguen cargándose…" };
            return { titulo: "Cargando información", texto: etiqueta ? "Abriendo “" + etiqueta.slice(0, 54) + "”…" : "Preparando la información solicitada…", icono: "refresh", lento: "Seguimos preparando la información…" };
        }

        function estadoFormulario(formulario, esReporte) {
            if (formulario.dataset.loadingTitle) {
                return {
                    titulo: formulario.dataset.loadingTitle,
                    texto: formulario.dataset.loadingText || "Guardando la información…",
                    icono: formulario.dataset.loadingIcon || "refresh",
                    tono: formulario.dataset.loadingTone || "default",
                    lento: formulario.dataset.loadingSlowText || "Seguimos procesando tu solicitud…"
                };
            }
            if (esReporte) return { titulo: "Actualizando reportes", texto: "Aplicando filtros y calculando las métricas…", icono: "chart", tono: "reports", lento: "Los reportes siguen actualizándose…" };
            var etiqueta = ((formulario.querySelector('button[type="submit"]') || {}).textContent || "").replace(/\s+/g, " ").trim();
            if (/buscar|filtrar|aplicar/i.test(etiqueta)) return { titulo: "Aplicando filtros", texto: "Actualizando los resultados…", icono: "filter", lento: "Los resultados siguen actualizándose…" };
            if (/eliminar|borrar/i.test(etiqueta)) return { titulo: "Eliminando registro", texto: "Aplicando el cambio solicitado…", icono: "trash", lento: "La eliminación sigue procesándose…" };
            if (/tomar|asignar/i.test(etiqueta)) return { titulo: "Asignando ticket", texto: "Actualizando la responsabilidad del ticket…", icono: "user", lento: "La asignación sigue procesándose…" };
            if (/guardar|actualizar|editar/i.test(etiqueta)) return { titulo: "Guardando cambios", texto: "Actualizando la información…", icono: "check", lento: "Los cambios siguen guardándose…" };
            return { titulo: "Procesando solicitud", texto: etiqueta ? "Procesando “" + etiqueta.slice(0, 54) + "”…" : "Guardando y preparando la información…", icono: "refresh", lento: "Seguimos procesando tu solicitud…" };
        }

        /* Al terminar de cargar esta página, el precargador ya no hace falta. */
        window.addEventListener("pageshow", ocultar);
        window.addEventListener("load", function () {
            clearTimeout(mostrarTimer);
            ocultar();
        });

        /* Un enlace interno que se va a abrir en la misma pestaña. */
        document.addEventListener("click", function (e) {
            if (e.defaultPrevented || e.button !== 0) { return; }
            if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) { return; }
            if (e.target.closest && e.target.closest('.modal-close, .modal-close-cancel, .btn-close, [data-modal-close], [data-close-modal], #axModalCerrar')) { return; }
            var a = e.target.closest ? e.target.closest("a[href]") : null;
            if (!a) { return; }
            if (a.hasAttribute("data-ticket-ficha")) { return; }
            /* La paginación mantiene la tabla visible y no necesita tapar
               toda la vista con el precargador global. */
            if (a.closest && a.closest(".pagination-links, .pagination-bar")) { return; }
            if (a.target && a.target !== "" && a.target !== "_self") { return; }
            if (a.hasAttribute("download")) { return; }
            var href = a.getAttribute("href") || "";
            if (!href || href.charAt(0) === "#" || /^(mailto:|tel:|javascript:)/i.test(href)) { return; }
            /* Solo navegaciones del propio sitio. */
            try {
                var url = new URL(a.href, location.href);
                if (url.origin !== location.origin) { return; }
                if (url.pathname === location.pathname && url.search === location.search) { return; }
            } catch (err) { return; }
            var label = (a.dataset.loadingLabel || a.textContent || "").replace(/\s+/g, " ").trim();
            var estadoLink = estadoPorRuta(url.pathname, label);
            setTimeout(function () {
                if (!e.defaultPrevented) programar(estadoLink.titulo, estadoLink.texto, estadoLink);
            }, 0);
        }, true);

        /* Un formulario que se envía en la misma pestaña. */
        document.addEventListener("submit", function (e) {
            var f = e.target;
            if (!f || f.tagName !== "FORM") { return; }
            // Los formularios de un <dialog> solo cierran la ventana; no navegan.
            if ((f.getAttribute("method") || "").toLowerCase() === "dialog" ||
                (e.submitter && (e.submitter.getAttribute("formmethod") || "").toLowerCase() === "dialog")) { return; }
            if (e.submitter && e.submitter.closest('.modal-close, .modal-close-cancel, .btn-close, [data-modal-close], [data-close-modal]')) { return; }
            if (f.hasAttribute("data-no-page-loader")) { return; }
            if (e.defaultPrevented) { return; }
            if (f.target && f.target !== "" && f.target !== "_self") { return; }
            if (f.closest && f.closest(".pagination-bar")) {
                DoggerPaginacion.guardarFormulario(f);
                return;
            }
            setTimeout(function () {
                if (e.defaultPrevented) { return; }
                var esReporte = f.id === "rptFiltros" || /reportes/i.test(f.action || "");
                var estadoForm = estadoFormulario(f, esReporte);
                programar(estadoForm.titulo, estadoForm.texto, estadoForm);
                if (f.dataset.loadingSubmit === "1") {
                    var boton = f.querySelector('button[type="submit"]');
                    if (boton) {
                        boton.disabled = true;
                        boton.setAttribute("aria-disabled", "true");
                    }
                }
            }, 0);
        }, true);

        document.addEventListener("click", function (e) {
            if (e.target.closest && e.target.closest(".modal-close, .modal-close-cancel, .btn-close, [data-modal-close], [data-close-modal], #axModalCerrar")) {
                cancelarProgramado();
                if (mostrando) ocultar();
            }
        }, true);

        /* Si el navegador cancela la página (el usuario se queda o vuelve
           atrás) se quita el precargador. */
        window.addEventListener("pagehide", ocultar);
        window.addEventListener("beforeunload", cancelarProgramado);
    })();
})();
